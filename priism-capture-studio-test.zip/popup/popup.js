// Desktop app: its preload provides storage as window.wickedStore (Electron already owns window.chrome).
if (window.wickedStore && !(window.chrome && window.chrome.storage)) {
  try { window.chrome = window.chrome || {}; window.chrome.storage = window.wickedStore.storage; }
  catch { window.chrome = { storage: window.wickedStore.storage }; }
}
const $ = (id) => document.getElementById(id);
// your plan: "pro" | "free" | "none" (see the plans section further down, and src/pass.js)
let PLAN = "none", planInfo = null;
const PP = window.PriismPass;
// Small inline icons (some system fonts lack ↖ ✕ etc.)
const ICON_X = '<svg viewBox="0 0 12 12" width="11" height="11" aria-hidden="true"><path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
const cornerIcon = (x, y) => `<svg viewBox="0 0 16 12" width="18" height="14" aria-hidden="true"><rect x="0.75" y="0.75" width="14.5" height="10.5" rx="2" fill="none" stroke="currentColor" stroke-opacity=".55"/><rect x="${x}" y="${y}" width="5" height="3" rx="1" fill="currentColor"/></svg>`;
const MAX_MB = 50;
const CHART_KEYS = ["pnStyle","pnRound","pnWindows","tpOn","tpColors","tpBuy","tpSell","tpShape","tpStyle","tpPanel","frameOn","framePattern","frameMode","frameColor","frameColor2","frameW","frameAlpha","frameSize","frameRound","frameEdge","frameMove","barPatOn","barPattern","barMode","barColor","barColor2","barAlpha","barSize","barWhere","indMode","indColor","markMode","markColor","indCustom","drawOn","zoneFill","zoneDim","zoneShape","zoneBorder","zoneStyle","zoneReact","indGrad","txtMode","txtColor","txtOutline","txtSize","tkOn","tkColor","tkSize","tkFont","tkGlow","tkOnly","lgOn","lgColor","lgVals","lgBack","dlgMode","dlgColor","dlgAlpha","sbOn","sbColor","sbW","sbStyle","axOn","axColor","axW","axStyle","gridOn","gridColor","gridAlpha","gridW","gridStyle","chOn","chColor","chW","chStyle","chGlow","chGlowColor","chLabels","plOn","plColor","plW","plStyle","panelMode","panelColor"];
const LOOK_KEYS = [...CHART_KEYS, "atmoFx","atmoTrail","atmoAura","atmoColor","atmoCustom","atmoOpacity","atmoLen","atmoFade","zoneFx","smartDim","vignetteAt","opacity","overOpacity","dim","blur","vividness","tint","speed","fps","res","fit","posX","posY","powerSaver","paused","bw","layer","candleOn","candleUp","candleDown","candleGlow","candlePreset","candleLook","candleClosedLook","shiftSpeed","candleWick","candleWickUp","candleWickDown","candleBorder","candleBorderUp","candleBorderDown","candleBorderW","candleHollow","candleWickW","candleBodyW","candleFxCore","candleFxEdge","candleFxAmt","lineGlow","scaleText","scaleGlow","scaleBold","scaleBg","scaleBgColor","scaleLabels","scaleSize","scaleFont","react","reactStrength","moodLook","moodRange","moodPulse","musicParts","musicFeel","musicSens","vignette","calm","sessionOn","sessionSkins","multi","chartSkins","chartColors","chartStyle","bracketOn","bracketSize","bracketBack","bracketFill","bracketText","bracketProfit","bracketLoss","bracketBorderColor","bracketBorderW","bracketLineColor","bracketLineW","bracketQty","pnlShow","pnlStyle","pnlPos","pnlSize","pnlBack","pnlUp","pnlDown","wallOpts"];
const DEFAULTS = {
  enabled: true, skin: "aurora", mediaId: null, media: [], loadouts: [],
  opacity: 1, overOpacity: 0.35, dim: 0.3, blur: 0, vividness: 1, tint: 0, speed: 1,
  fps: "auto", fit: "cover", posX: 50, posY: 50, res: "standard",
  powerSaver: false, paused: false, bw: false, layer: "behind",
  candleOn: false, candleUp: "#00ffa3", candleDown: "#ff2e97", candleGlow: 0, candlePreset: "neon",
  lensKey: "Alt+Shift+KeyZ", lensZoom: 2.5, lensSize: "m", zoneReact: "off", pnStyle: "flat", pnRound: false, pnWindows: true, tpOn: false, tpColors: "candles", tpBuy: "#2962ff", tpSell: "#f23645", tpShape: "rounded", tpStyle: "solid", tpPanel: "keep", react: "off", reactStrength: 0.6, moodLook: "glow", moodRange: 1, moodPulse: "soft", musicParts: "gwfi", musicFeel: "punchy", musicSens: "normal",
  frameOn: false, framePattern: "carbon", frameMode: "accent", frameColor: "#7c6cff", frameColor2: "#ff4df0", frameW: 8, frameAlpha: 0.5, frameSize: 1, frameRound: true, frameEdge: true, frameMove: false,
  barPatOn: false, barPattern: "zebra", barMode: "rainbow", barColor: "#7c6cff", barColor2: "#ff4df0", barAlpha: 0.25, barSize: 1, barWhere: "tlrb",
  wmOn: false, wmPos: "br", wmText: "", wmStyle: "corner", wmOpacity: 0.85, wmDrift: false, clipEdit: true, clipQuality: "balanced", clipAudio: "none", clipLen: 10, privacy: false, privacyPeek: false, privacyKey: "Alt+Shift+KeyP", privacyAcct: true, privacyOrder: false, privacyPnl: "hide", bracketQty: "", goalSound: "off", sessionSound: "off", tkOn: false, tkColor: "", tkSize: 1, tkFont: "default", tkGlow: false, tkOnly: false, lgOn: false, lgColor: "", lgVals: "own", lgBack: "none", tradeClipOn: false, tradeClipLen: 30, toggleKey: "Alt+Shift+KeyW", focusKey: "Alt+Shift+KeyF", recordKey: "Alt+Shift+KeyV", snapKey: "Alt+Shift+KeyS", focus: false, focusHides: "wallpaper", timerOn: false, timerMarket: "auto", timerPos: "bc", timerShow: "full", timerFormat: "in", timerClosed: "show", timerStyle: "pill", sides: "off", leftBar: "off", panelMode: "off", panelColor: "#10131c", dlgMode: "off", dlgColor: "#12151f", dlgAlpha: 0.78, uiFont: "default", uiSize: 0, uiAccent: "", vignette: 0, calm: false,
  sessionOn: false, sessionSkins: { asia: "galaxy", london: "rain", ny: "cybergrid", off: "ocean" },
  symbolOn: false, symbolSkins: {}, autoQuality: true, autoMatch: false, matchOnPick: false,
  candleLook: "solid", candleClosedLook: "", shiftSpeed: 10,
  candleWick: "same", candleWickUp: "#9aa4b8", candleWickDown: "#9aa4b8", candleBorder: "none", candleBorderUp: "#ffffff", candleBorderDown: "#ffffff", candleBorderW: 1, candleHollow: "none", candleWickW: 0, candleBodyW: 1, candleFxCore: "off", candleFxEdge: "off", candleFxAmt: 0.65, atmoFx: "off", atmoTrail: false, atmoAura: false, atmoColor: "candle", atmoCustom: "#7df9ff", atmoOpacity: 0.15, atmoLen: 4, atmoFade: 450, zoneFx: [], smartDim: "off", vignetteAt: "screen", skinOpts: {}, myCandles: [], chartColors: "auto", chartStyle: {}, zoneShape: "square", zoneBorder: "line", zoneStyle: "flat",
  indMode: "own", indColor: "", indCustom: {}, markMode: "own", markColor: "#ffd166", drawOn: false, zoneFill: 0.12, zoneDim: false, indGrad: [], wallMatch: null, txtMode: "own", txtColor: "", txtOutline: 0, txtSize: 0,
  gridOn: false, gridColor: "", gridAlpha: 0.35, gridW: 0, gridStyle: "dotted",
  chOn: false, chColor: "", chW: 0, chStyle: "dashed", chGlow: false, chGlowColor: "", chLabels: false,
  plOn: false, plColor: "", plW: 0, plStyle: "dotted",
  sbOn: false, sbColor: "", sbW: 0, sbStyle: "dashed", axOn: false, axColor: "", axW: 0, axStyle: "solid",
  lineGlow: 0, scaleText: "", scaleGlow: 0, scaleBold: false, scaleBg: "auto", scaleBgColor: "#0b1320", scaleLabels: true,
  scaleSize: 0, scaleFont: "default",
  multi: "span", chartSkins: {}, pnlShow: false, pnlStyle: "color", pnlPos: "tc", pnlSize: 1, pnlBack: "glass", pnlUp: "", pnlDown: "",
  bracketOn: false, bracketSize: 1, bracketBack: "keep",
  bracketFill: "", bracketText: "", bracketProfit: "", bracketLoss: "",
  bracketBorderColor: "", bracketBorderW: 0, bracketLineColor: "", bracketLineW: 0,
  goalOn: false, goalGuard: false, goalTarget: 500, goalLimit: 300, goalPos: "bl", journalOn: false, clipMode: "chart", clipFps: 30,
};
let cfg = { ...DEFAULTS };
// lastPick: you used THIS copy's panel just now, so if two copies of Priism are installed, this one draws the page
// a built-in wallpaper with YOUR settings for it (its own options + Recolour), for every preview in the panel
const makeSkin = (id, ctx, look) => window.PriismMakeSkin(id, ctx, look && "wallOpts" in look ? look.wallOpts : (cfg.skinOpts || {})[id]);   // a look's own wallpaper settings win
// ---------- fonts (price scale, ticker, TradingView's panels): each choice shown in its own font ----------
(function loadPanelFonts() {
  const st = document.createElement("style");
  st.textContent = (window.PriismFonts || []).filter((f) => f[2]).map((f) => `@font-face{font-family:"Priism ${f[2]}";src:url("../src/fonts/${f[2]}.woff2") format("woff2");font-weight:100 900;font-display:swap}`).join("");
  document.head.appendChild(st);
})();
function fontPicker(boxId, key) {
  const box = $(boxId); if (!box) return;
  box.className = "fontgrid"; box.innerHTML = "";
  for (const [id, label, , famCss] of window.PriismFonts || []) {
    const b = document.createElement("button"); b.type = "button"; b.className = "fontchip" + ((cfg[key] || "default") === id ? " on" : "");
    b.innerHTML = `<b>${esc(label)}</b><small>1,234.50</small>`; if (famCss) b.style.fontFamily = famCss;
    b.onclick = () => { set({ [key]: id }); fontPicker(boxId, key); };
    box.appendChild(b);
  }
}
// ---------- Style each chart: while you style chart 2, 3... the Style tab's changes are saved for that chart only ----------
// (TradingView's panels, the ticker, the legend and dialogs are one per page, so they stay shared.)
const PER_CHART_KEYS = new Set(["candleOn","candleUp","candleDown","candleGlow","candlePreset","candleLook","candleClosedLook","candleWick","candleWickUp","candleWickDown","candleBorder","candleBorderUp","candleBorderDown","candleBorderW","candleHollow","candleWickW","candleBodyW","candleFxCore","candleFxEdge","candleFxAmt",
  "lineGlow","scaleText","scaleGlow","scaleBold","scaleBg","scaleBgColor","scaleLabels","scaleSize","scaleFont","bracketOn","bracketSize","bracketBack","bracketFill","bracketText","bracketProfit","bracketLoss","bracketBorderColor","bracketBorderW","bracketLineColor","bracketLineW",
  "indMode","indColor","markMode","markColor","indCustom","drawOn","zoneFill","zoneDim","zoneShape","zoneBorder","zoneStyle","indGrad","txtMode","txtColor","txtOutline","txtSize","sbOn","sbColor","sbW","sbStyle","axOn","axColor","axW","axStyle","gridOn","gridColor","gridAlpha","gridW","gridStyle","chOn","chColor","chW","chStyle","chGlow","chGlowColor","chLabels","plOn","plColor","plW","plStyle"]);
let styleChart = 1, baseStyle = null;
function routeChartStyle(obj) {
  if (styleChart < 2 || !baseStyle) return obj;
  const mine = {}, rest = {};
  for (const [k, v] of Object.entries(obj)) (PER_CHART_KEYS.has(k) ? mine : rest)[k] = v;
  if (!Object.keys(mine).length) return obj;
  Object.assign(cfg, mine);
  const all = { ...(cfg.chartStyle || {}) }; all[styleChart] = { ...(all[styleChart] || {}), ...mine };
  rest.chartStyle = all; return rest;
}
const set = (obj) => { obj = routeChartStyle(obj); Object.assign(cfg, obj); chrome.storage.local.set({ ...obj, lastPick: Date.now() }); };
const uid = () => Math.random().toString(36).slice(2, 10);
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ---------- tabs ----------
document.querySelectorAll("#nav button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll("#nav button").forEach((x) => x.classList.toggle("on", x === b));
    document.querySelectorAll("main section").forEach((s) => (s.hidden = s.id !== "tab-" + b.dataset.tab));
  };
});

// ---------- skins (live previews share one loop) ----------
let previews = [], quickPreviews = [], activeCat = "All";
function renderSkins() {
  const cats = ["All", "Wow", "OLED", ...new Set(Object.values(WickedSkins).map((s) => s.cat))];
  $("chips").innerHTML = "";
  cats.forEach((c) => {
    const b = document.createElement("button");
    b.className = "chip" + (c === activeCat ? " on" : "");
    b.textContent = c;
    b.onclick = () => { activeCat = c; renderSkins(); };
    $("chips").appendChild(b);
  });
  $("skinCards").innerHTML = "";
  previews = [];
  let shown = 0;
  const big = document.body.classList.contains("desk");
  // in the app, "All" is shown as sections (the showpieces first), like a gallery
  let list = Object.entries(WickedSkins);
  const grouped = big && activeCat === "All" && !skinQuery();
  if (grouped) {
    const cats = [...new Set(list.map(([, s]) => s.cat))];
    list = [["__h", "\u2726 Wow \u00B7 showpieces"], ...list.filter(([, s]) => s.wow), ...cats.flatMap((c) => [["__h", c], ...list.filter(([, s]) => !s.wow && s.cat === c)])];
  }
  for (const [id, s] of list) {
    if (id === "__h") { const h = document.createElement("h5"); h.className = "grp-h"; h.textContent = s; $("skinCards").appendChild(h); continue; }
    if (!grouped && (activeCat === "Wow" ? !s.wow : activeCat === "OLED" ? !s.oled : activeCat !== "All" && s.cat !== activeCat)) continue;
    if (!matchQ(s.name, s.cat, (s.wow ? "wow " : "") + (s.oled ? "oled" : ""))) continue;
    shown++;
    const card = document.createElement("button"), pro = PLAN === "free" && !PP.isFreeSkin(id);
    card.className = "card" + (currentSrc() === id ? " on" : "") + (pro ? " pro" : ""); card.dataset.skin = id;
    const cv = document.createElement("canvas");
    const CW = big ? 260 : 160, CH = big ? 128 : 76;
    cv.width = CW; cv.height = CH;
    const skin = makeSkin(id, cv.getContext("2d")); skin.resize(CW, CH);
    previews.push(watchPreview({ skin, t: 0, id, cv }, cv));
    card.append(cv);
    card.insertAdjacentHTML("beforeend", `<span class="live">● LIVE</span>${pro ? '<span class="wtag pro">PRO</span>' : ""}${s.oled ? '<span class="wtag oled" title="Mostly true black and no bright part that stays still: easy on OLED screens">OLED</span>' : ""}<div class="label">${esc(s.name)}</div>`);
    card.onclick = () => pickSource(id);
    $("skinCards").appendChild(card);
  }
  updateEmpty(shown);
  renderHero();
}
// Only animate previews that are actually on screen (dozens of live canvases would load the computer for nothing).
// Each preview draws one still frame straight away, so off-screen cards still show a picture.
const previewIO = typeof IntersectionObserver !== "undefined" ? new IntersectionObserver((es) => { for (const e of es) if (e.target.__bdP) e.target.__bdP.vis = e.isIntersecting; }) : null;
function watchPreview(p, cv) {
  p.vis = !previewIO; try { p.skin.frame(2, 0.016); } catch {}
  if (previewIO) { cv.__bdP = p; previewIO.observe(cv); }
  return p;
}
let last = 0;
(function loop(now) {
  requestAnimationFrame(loop);
  if (now - last < 66) return; // ~15fps previews
  const dt = (now - last) / 1000; last = now;
  if (document.hidden) return;
  if (wallPrev && wallPrev.cv.offsetParent) { try { stepWallPrev(Math.min(dt, 0.1)); } catch {} }
  for (const p of [...previews, ...quickPreviews, ...lookPreviews]) if (p.vis !== false) p.skin.frame((p.t += Math.min(dt, 0.1)), Math.min(dt, 0.1));
})(0);

// ---------- desktop app: a full-window layout of its own (the extension keeps its compact panel) ----------
// Same controls and settings as the extension (nothing duplicated): the app just lays them out for a big window:
// a sidebar, a top bar with live stats, a big live preview of your look, a gallery of wallpapers, two-column settings.
const heroP = { p: null, key: "" };
function renderHero() {
  if (!document.body.classList.contains("desk")) return;
  const bg = $("dhBg"), fg = $("dhFg"); if (!bg || !fg) return;
  const r = bg.getBoundingClientRect(); if (r.width < 50) return;
  const W = Math.round(r.width * 0.8), H = Math.round(r.height * 0.8);
  const src = cfg.skin, sk = WickedSkins[src], key = src + "|" + W + "x" + H + "|" + JSON.stringify((cfg.skinOpts || {})[src] || null);
  if (heroP.key !== key) {
    heroP.key = key; bg.width = W; bg.height = H; heroP.p = null;
    if (sk) { const s = makeSkin(src, bg.getContext("2d")); s.resize(W, H); heroP.p = { skin: s, t: 3 }; s.frame(3, 0.016); }
    else { const g = bg.getContext("2d"); g.fillStyle = "#0b0d14"; g.fillRect(0, 0, W, H); }
  }
  const media = src === "media" && (cfg.media || []).find((m) => m.id === cfg.mediaId);
  $("dhName").textContent = sk ? sk.name : media ? media.name || "Your upload" : "Your wallpaper";
  const tags = [cfg.enabled ? "\u25CF LIVE" : "\u25CB OFF", sk ? sk.cat : "My upload", sk && sk.wow ? "\u2726 Wow" : ""].filter(Boolean);
  $("dhTags").innerHTML = tags.map((t, i) => `<i class="${i === 0 ? (cfg.enabled ? "on" : "") : ""}">${esc(t)}</i>`).join("");
  // candles across the stage, in your colours and look
  const dpr = Math.min(2, devicePixelRatio || 1), fr = fg.getBoundingClientRect();
  fg.width = Math.round(fr.width * dpr); fg.height = Math.round(fr.height * dpr);
  const g = fg.getContext("2d"), CL = window.__bdCandleLooks, look0 = cfg.candleOn ? cfg.candleLook || "solid" : "solid", look = look0;
  const up = cfg.candleOn && /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#26a69a", dn = cfg.candleOn && /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ef5350";
  let seed = 7, p = 50; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const n = Math.max(30, Math.round(fr.width / 16)), bars = [];
  for (let i = 0; i < n; i++) { const o = p; p += (rnd() - 0.47) * 6; bars.push([o, p, Math.min(o, p) - rnd() * 3, Math.max(o, p) + rnd() * 3]); }
  let lo = Infinity, hi = -Infinity; for (const b of bars) { lo = Math.min(lo, b[2]); hi = Math.max(hi, b[3]); }
  const top = fg.height * 0.12, bot = fg.height * 0.62, Y = (v) => bot - ((v - lo) / (hi - lo || 1)) * (bot - top), slot = fg.width / (n + 1), bw = Math.max(2 * dpr, slot * 0.56);
  const k = { fill: (a, b, c, d) => g.fillRect(a, b, c, d), style: (v) => { g.fillStyle = v; }, stroke: (v) => { g.strokeStyle = v; }, strokeRect: (a, b, c, d) => g.strokeRect(a, b, c, d), fillPath: () => g.fill(), clear: (a, b, c, d) => g.clearRect(a, b, c, d), px: dpr, yfrac: 0 };
  const closed = cfg.candleOn && cfg.candleClosedLook && look !== "shift" && CL && CL.META[cfg.candleClosedLook] ? cfg.candleClosedLook : "";
  bars.forEach(([o, c, l, h], i) => {
    const look = closed && i < n - 1 ? closed : look0, glow = Math.max(+cfg.candleGlow || 0, CL && CL.META[look] ? CL.META[look].minGlow : 0);   // the last bar is the live one
    const isUp = c >= o, col = isUp ? up : dn, cx = slot * (i + 1), t0 = Y(Math.max(o, c)), t1 = Y(Math.min(o, c)); k.yfrac = t0 / fg.height;
    g.save(); if (glow > 0) { g.shadowColor = col; g.shadowBlur = (4 + glow * 18) * dpr * 0.7; }
    const P = CL && cfg.candleOn && CL.parts ? CL.parts(partsCfg()) : null, [wx, ww] = P ? CL.wickRect(cx - dpr / 2, dpr, k, P) : [Math.round(cx - dpr / 2), dpr];
    g.fillStyle = CL ? (P ? CL.wickOf(look, col, isUp, k, P) : CL.wick(look, col, k)) : col; g.fillRect(wx, Y(h), ww, Y(l) - Y(h));
    k.xfrac = cx / fg.width; if (CL) CL.candle(g, look, Math.round(cx - bw / 2), t0, Math.round(bw), Math.max(dpr, t1 - t0), col, isUp, k, P, CL.fx && cfg.candleOn ? CL.fx(fxCfg()) : null); else { g.fillStyle = col; g.fillRect(cx - bw / 2, t0, bw, t1 - t0); }
    g.restore();
  });
  // your look, at a glance
  const lm = CL && CL.META[look];
  $("dhLook").innerHTML = `<div class="dl-row"><span>Candles</span><b>${esc(cfg.candleOn ? (lm ? lm.name : "Solid") + (closed ? " · closed " + CL.META[closed].name : "") : "TradingView's own")}</b></div>
    <div class="dl-row"><span>Colours</span><b><i class="sw" style="background:${up}"></i><i class="sw" style="background:${dn}"></i></b></div>
    <div class="dl-row"><span>Chart lines</span><b>${[cfg.gridOn && "grid", cfg.chOn && "crosshair", cfg.plOn && "price line"].filter(Boolean).join(", ") || "TradingView's own"}</b></div>
    <div class="dl-row"><span>TradingView</span><b>${cfg.panelMode && cfg.panelMode !== "off" ? "styled panels" : "TradingView's own"}</b></div>`;
}
(function heroLoop() {                                              // the big preview runs smoother than the small cards
  let last = 0;
  (function f(now) {
    requestAnimationFrame(f);
    if (!heroP.p || document.hidden || now - last < 33 || $("tab-skins").hidden) return;
    const dt = Math.min(0.1, (now - last) / 1000); last = now; heroP.p.skin.frame((heroP.p.t += dt), dt);
  })(0);
})();
function setupDesk() {
  if (!DESK || IS_TAB) return;
  const B = document.body; B.classList.add("desk");
  const nav = $("nav"), main = document.querySelector("main");
  nav.querySelector(".brand").innerHTML = '<img src="../icons/icon-128.png" alt="" /><div><b>Priism Skins</b><small>for TradingView</small></div>';
  // sidebar foot: the chart card + the on/off switch
  const foot = document.createElement("div"); foot.className = "desk-foot";
  foot.append($("deskCard"), main.querySelector(".top"));
  nav.appendChild(foot);
  // top bar: page title, search, live stats
  const bar = document.createElement("header"); bar.className = "desk-bar";
  bar.innerHTML = '<div class="desk-title"><h1 id="deskPage">Skins</h1><p id="deskSub"></p></div><div class="desk-stats" id="deskStats"></div>';
  bar.insertBefore(main.querySelector(".finder"), $("deskStats"));
  main.insertBefore(bar, main.firstChild);
  const SUB = { skins: "Wallpapers and one-tap looks for your chart", candles: "Candles, chart lines and the price scale", interface: "TradingView's own panels, toolbars and windows",
    trading: "Brackets, P&L, daily goal, session timer and trade clips", capture: "Snapshots, clips, streamer mode and watermark", workshop: "Community looks and wallpapers",
    loadouts: "Your saved looks and share links", tune: "Picture, motion, shortcuts and advanced" };
  const setPage = (b) => { if (!b) return; $("deskPage").textContent = b.querySelector("span").textContent; $("deskSub").textContent = SUB[b.dataset.tab] || "";
    main.scrollTop = 0; if (b.dataset.tab === "skins") setTimeout(renderHero, 0); };
  document.querySelectorAll("#nav button[data-tab]").forEach((b) => b.addEventListener("click", () => setPage(b)));
  setPage(document.querySelector("#nav button.on"));
  // the big live preview on Skins
  const hero = document.createElement("div"); hero.id = "deskHero";
  hero.innerHTML = '<div class="dh-stage"><canvas id="dhBg"></canvas><div class="dh-dim"></div><canvas id="dhFg"></canvas><div class="dh-text"><div id="dhTags"></div><h2 id="dhName"></h2></div></div>' +
    '<div class="dh-side"><b class="dh-h">Your look</b><div id="dhLook"></div><div class="dh-btns"><button class="primary" id="dhShare">Copy share link</button><button id="dhSave">Save this look</button></div></div>';
  $("tab-skins").insertBefore(hero, $("tab-skins").firstChild);
  $("dhShare").onclick = () => { $("codeCopy").click(); toast("Share link copied. Paste it anywhere."); };
  $("dhSave").onclick = () => { document.querySelector('#nav [data-tab="loadouts"]').click(); $("loName").focus(); };
  addEventListener("resize", () => { clearTimeout(setupDesk.rt); setupDesk.rt = setTimeout(renderHero, 120); });
  // live stats: chart FPS (from the chart window) and what the app is using
  const stat = (k, v, cls) => `<span class="${cls || ""}"><small>${k}</small>${v}</span>`;
  const tick = async () => {
    let s = null; try { s = await DESK.stats(); } catch {}
    if (!s) return;
    $("deskStats").innerHTML = stat("CHART", s.open ? "Open" : "Closed", s.open ? "ok" : "") + stat("FPS", s.open && s.fps ? s.fps : "\u2013") + stat("CPU", s.cpu + "%") + stat("RAM", s.mem + " MB");
  };
  tick(); setInterval(() => { if (!document.hidden) tick(); }, 2000);
}


// ---------- candles ----------
// [id, name, up, down, group]. Ids are stored in settings; keep them stable.
const CANDLE_GROUPS = ["Candle FX", "Clean", "Neon", "Synth", "Pastel", "Luxe", "Warm", "Cool", "Rich", "Easy to read"];
const CANDLE_PRESETS = [
  ["mono", "Mono", "#ffffff", "#2f2f35", "Clean"],
  ["ghost", "Ghost", "#f5f5f5", "#5c5c5c", "Clean"],
  ["arctic", "Arctic", "#e0f7fa", "#0288d1", "Clean"],
  ["neon", "Neon Pulse", "#00ffa3", "#ff2e97", "Neon"],
  ["cyberpunk", "Cyberpunk", "#fcee0a", "#00f0ff", "Neon"],
  ["matrix", "Terminal", "#00ff41", "#0b6623", "Neon"],
  ["acid", "Acid", "#c6ff00", "#7c4dff", "Neon"],
  ["bubblegum", "Bubblegum", "#7cf7d4", "#ff8fd8", "Neon"],
  ["lava", "Magma", "#ffb300", "#ff3d00", "Warm"],
  ["gold", "Aurum", "#ffd36b", "#a67c1a", "Warm"],
  ["sunrise", "Sunrise", "#ffe082", "#ff6e40", "Warm"],
  ["dusk", "Dusk", "#ffb74d", "#ec407a", "Warm"],
  ["crimson", "Crimson", "#ff5252", "#8a0f2e", "Warm"],
  ["ice", "Glacier", "#8be9ff", "#3d5afe", "Cool"],
  ["deepsea", "Deepsea", "#4dd0e1", "#5c6bc0", "Cool"],
  ["amethyst", "Amethyst", "#b388ff", "#4a5a6a", "Cool"],
  ["forest", "Forest", "#9ccc65", "#6d4c41", "Rich"],
  ["royal", "Royal", "#ffd700", "#6a1b9a", "Rich"],
  // more (every pair is two clearly different colours that both stand out on a dark chart)
  ["slate", "Slate", "#cfd8e3", "#6b7a90", "Clean"],
  ["paper", "Ink & Paper", "#f4efe6", "#c8463d", "Clean"],
  ["laser", "Laser", "#39ff14", "#ff073a", "Neon"],
  ["plasma", "Plasma", "#00e5ff", "#ff00e5", "Neon"],
  ["volt", "Volt", "#e6ff00", "#ff3d8b", "Neon"],
  ["vapor", "Vaporwave", "#01cdfe", "#ff71ce", "Synth"],
  ["outrun", "Outrun", "#fdff6a", "#ff2a6d", "Synth"],
  ["miami", "Miami", "#05d9e8", "#ff6ec7", "Synth"],
  ["arcade", "Arcade", "#00ff9f", "#bd00ff", "Synth"],
  ["sunset", "Night Drive", "#ffb86b", "#7c4dff", "Synth"],
  ["sorbet", "Sorbet", "#b5ead7", "#ffb7b2", "Pastel"],
  ["cotton", "Cotton Candy", "#a0e7e5", "#ffaebc", "Pastel"],
  ["peach", "Mint & Peach", "#98f5c1", "#ffc09f", "Pastel"],
  ["lavender", "Lavender", "#cdb4ff", "#ff9fb2", "Pastel"],
  ["lemon", "Lemonade", "#fff59d", "#90caf9", "Pastel"],
  ["champagne", "Champagne", "#f7e7ce", "#b08d57", "Luxe"],
  ["rosegold", "Rose Gold", "#f6d1c1", "#b76e79", "Luxe"],
  ["platinum", "Platinum", "#eef1f5", "#8a94a6", "Luxe"],
  ["jewel", "Emerald & Ruby", "#2ee59d", "#e0115f", "Luxe"],
  ["sapphire", "Sapphire", "#7fb8ff", "#c9a227", "Luxe"],
  ["inferno", "Inferno", "#ffea00", "#ff1744", "Warm"],
  ["desert", "Desert", "#f2cc8f", "#e07a5f", "Warm"],
  ["northern", "Northern", "#7cffcb", "#7b61ff", "Cool"],
  ["galaxy", "Galaxy", "#22d3ee", "#a78bfa", "Cool"],
  ["coral", "Reef", "#48cae4", "#ff7f50", "Cool"],
  ["jungle", "Jungle", "#7bd389", "#f4a259", "Rich"],
  ["wine", "Vintage", "#e9c46a", "#9b2242", "Rich"],
  // easy to tell apart for everyone, also with red-green colour blindness (blue / orange, light / dark)
  ["clear", "Clear View", "#4c9aff", "#ff9f1c", "Easy to read"],
  ["contrast", "High Contrast", "#ffffff", "#ff8a00", "Easy to read"],
  ["calm", "Calm Blue", "#5ab0ff", "#f06292", "Easy to read"],
];
let candleGroup = "All";
const bars = (up, down) => {
  // 8 tiny candles: [open, close, low, high] in a 0-30 box
  const d = [[20,16,22,12],[16,18,19,13],[18,12,20,10],[12,14,16,9],[14,9,15,6],[9,10,12,5],[10,5,11,2],[5,6,8,1]];
  return `<svg viewBox="0 0 80 30" preserveAspectRatio="none">${d.map(([o, c, lo, hi], i) => {
    const col = c <= o ? up : down; // lower y = higher price
    const x = 5 + i * 10, top = Math.min(o, c), ht = Math.max(2, Math.abs(o - c));
    return `<line x1="${x}" x2="${x}" y1="${hi}" y2="${lo}" stroke="${col}"/><rect x="${x - 3}" y="${top}" width="6" height="${ht}" fill="${col}"/>`;
  }).join("")}</svg>`;
};
const LOOK_HINT = {
  solid: "Solid bodies in your colours.",
  neon: "Tube: glowing outlines with a faint fill.",
  prism: "Rainbow: colours fan out across the chart, left to right.",
  shift: "Cycle: colours keep flowing over time. Indicator lines on the chart cycle too.",
};
// Candle look cards: every look, each with a small preview drawn in YOUR current candle colours (same drawing code
// the chart uses, so the preview is what you get). Redrawn when colours or glow change.
function renderLookGrid() {
  setTimeout(renderHero, 0);
  const CL = window.__bdCandleLooks; if (!$("candleLook") || !CL) return;
  const live = cfg.candleLook || "solid";
  // every look in one grid: the classic looks, then the Candle FX materials under their own label
  fillLookGrid($("candleLook"), CL.LOOKS.map((l) => l[0]), live, null,
    (id) => { set({ candleLook: id, candleOn: true, ...(id === "shift" || id === cfg.candleClosedLook ? { candleClosedLook: "" } : {}) }); $("candleOn").checked = true; renderCandles(); });
  renderFx();
  // Closed candles: a look of their own (Cycle moves the whole chart's colours, so it isn't one of them)
  const own = !!cfg.candleClosedLook && live !== "shift";
  $("closedRow").hidden = live === "shift";
  $("closedBox").hidden = !own;
  if (own) fillLookGrid($("closedLook"), CL.LOOKS.map((l) => l[0]).filter((id) => id !== "shift" && id !== live), cfg.candleClosedLook, live,
    (id) => { set({ candleClosedLook: id, candleOn: true }); $("candleOn").checked = true; renderCandles(); });
}
// One grid of look cards, each with a small preview drawn in YOUR colours on YOUR wallpaper. liveLook: draw the
// last candle of each preview in that look (the Closed look grid, so you see the live candle stand out).
function fillLookGrid(box, ids, cur, liveLook, pick) {
  const CL = window.__bdCandleLooks;
  const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#00ffa3", down = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ff2e97";
  const sig = up + down + (+cfg.candleGlow || 0) + "|" + (cfg.skin || "") + "|" + JSON.stringify(partsCfg()) + JSON.stringify(fxCfg()) + "|" + JSON.stringify((cfg.skinOpts || {})[cfg.skin] || {}) + "|" + (liveLook || "") + "|" + ids.join(",");
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig; box.textContent = "";
    // one still frame of YOUR current wallpaper, used behind every look preview
    let bgc = null;
    try { const sk = WickedSkins[cfg.skin]; if (sk) { bgc = document.createElement("canvas"); bgc.width = 200; bgc.height = 104; const s0 = makeSkin(cfg.skin, bgc.getContext("2d")); s0.resize(200, 104); s0.frame(3, 0.016); } } catch { bgc = null; }
    let fxLabel = false;
    for (const id of ids) {
      if (CL.META[id].fx && !fxLabel && ids.some((x) => !CL.META[x].fx)) { fxLabel = true; const h = document.createElement("div"); h.className = "grp-label lookgrp"; h.textContent = "Materials"; box.appendChild(h); }
      const b = document.createElement("button"); b.className = "lookcard"; b.dataset.look = id; b.title = CL.META[id].hint;
      const cv = document.createElement("canvas"); cv.width = 200; cv.height = 104;
      const lab = document.createElement("span"); lab.textContent = CL.META[id].name;
      b.append(cv, lab); box.appendChild(b);
      b.onclick = () => pick(id);
      requestAnimationFrame(() => { try { CL.preview(cv, id, up, down, +cfg.candleGlow || 0, bgc, partsCfg(), liveLook || undefined, fxCfg()); } catch {} });
    }
  }
  for (const b of box.children) if (b.dataset.look) b.classList.toggle("on", b.dataset.look === cur);
}
// ---------- Candle FX (Chart › Candle FX): materials + core light + edge light, drawn by candlelooks.js ----------
const FX_CORE_OPTS = [["off", "Off"], ["soft", "Soft"], ["plasma", "Plasma"], ["beam", "Beam"]];
const FX_EDGE_OPTS = [["off", "Off"], ["rim", "Rim"], ["glint", "Glint"]];
// quick mixes: a material, its lights and colours that suit it
const FX_PRESETS = [
  ["aurora", "Aurora Flow", { candleLook: "hologram", candleFxCore: "soft", candleFxEdge: "off", candleBorder: "light", candleFxAmt: 0.6, candleUp: "#34f5c5", candleDown: "#a46bff", candleGlow: 0.2, atmoFx: "mist", atmoTrail: false, atmoAura: true }],
  ["void", "Void Chrome", { candleLook: "liquid", candleFxCore: "off", candleFxEdge: "rim", candleBorder: "none", candleFxAmt: 0.7, candleUp: "#d6f7ff", candleDown: "#8f7bff", candleGlow: 0.1, atmoFx: "off", atmoTrail: true, atmoAura: false }],
  ["icevapor", "Ice Vapor", { candleLook: "crystal", candleFxCore: "beam", candleFxEdge: "glint", candleBorder: "none", candleFxAmt: 0.55, candleUp: "#9fe8ff", candleDown: "#c3a6ff", candleGlow: 0.15, atmoFx: "vapor", atmoTrail: false, atmoAura: false }],
  ["synth", "Synth Pulse", { candleLook: "plasma", candleFxCore: "plasma", candleFxEdge: "off", candleBorder: "light", candleFxAmt: 0.65, candleUp: "#ff5fd2", candleDown: "#5b8cff", candleGlow: 0.25, atmoFx: "smoke", atmoTrail: false, atmoAura: true }],
];
const FX_DEF = { candleFxCore: "off", candleFxEdge: "off", candleFxAmt: 0.65, atmoFx: "off", atmoTrail: false, atmoAura: false, atmoColor: "candle", atmoOpacity: 0.15, atmoLen: 4, atmoFade: 450 };
// one still frame of your wallpaper at a size (behind the previews)
function wallStill(w, h) {
  try { const sk = WickedSkins[cfg.skin]; if (!sk) return null; const c = document.createElement("canvas"); c.width = w; c.height = h; const s0 = makeSkin(cfg.skin, c.getContext("2d")); s0.resize(w, h); s0.frame(3, 0.016); return c; } catch { return null; }
}
const setFx = (o) => { set({ ...o, ...(cfg.candleOn ? {} : { candleOn: true }) }); $("candleOn").checked = true; renderCandles(); };
function renderFx() {
  const CL = window.__bdCandleLooks; if (!$("fxCore") || !CL) return;
  seg("fxCore", FX_CORE_OPTS, () => cfg.candleFxCore || "off", (v) => setFx({ candleFxCore: v }));
  seg("fxEdge", FX_EDGE_OPTS, () => (cfg.candleFxEdge === "laser" ? "off" : cfg.candleFxEdge || "off"), (v) => setFx({ candleFxEdge: v }));
  const amt = +cfg.candleFxAmt >= 0 ? +cfg.candleFxAmt : 0.65, lit = (cfg.candleFxCore || "off") !== "off" || !["off", "laser", undefined].includes(cfg.candleFxEdge) || cfg.candleBorder === "light";
  $("fxAmt").value = amt; $("fxAmtOut").textContent = Math.round(amt * 100) + "%"; $("cfxAmtRow").hidden = !lit;
  { const m = CL.META[cfg.candleLook] || CL.META.solid, name = (o, v) => (o.find((x) => x[0] === v) || [, ""])[1];
    const bits = [m.name + (m.fx ? "" : " look")];
    if ((cfg.candleFxCore || "off") !== "off") bits.push(name(FX_CORE_OPTS, cfg.candleFxCore) + " core");
    if (!["off", "laser", undefined].includes(cfg.candleFxEdge)) bits.push(name(FX_EDGE_OPTS, cfg.candleFxEdge) + " edge");
    if (cfg.candleBorder === "light") bits.push("lit border");
    $("fxHint").textContent = !cfg.candleOn ? "Candles are off. Picking anything here turns them on."
      : bits.join(" + ") + ". Core and edge light work with every look, Closed candles and Candle parts. For a lit outline, use Candle parts \u203a Borders \u203a Light."; }
  drawFxPreview(); syncAtmo();
}
// ---------- Live candle atmosphere (Candle FX): drawn on the chart page behind the chart, by PriismAtmo (skins.js) ----------
const ATMO_FX = [["off", "Off"], ["smoke", "Phantom Smoke"], ["vapor", "Liquid Vapor"], ["mist", "Spectral Mist"]];
const atmoAny = () => (cfg.atmoFx || "off") !== "off" || !!cfg.atmoTrail || !!cfg.atmoAura;
// any atmosphere turns Priism candles on (it follows your candles on the chart)
const setAtmo = (o) => { set({ ...o, ...(cfg.candleOn ? {} : { candleOn: true }) }); $("candleOn").checked = true; syncAtmo(); };
function syncAtmo() {
  if (!$("atmoFx")) return;
  seg("atmoFx", ATMO_FX, () => cfg.atmoFx || "off", (v) => setAtmo({ atmoFx: v }));
  seg("atmoTrail", [[false, "Off"], [true, "Afterimage"]], () => !!cfg.atmoTrail, (v) => setAtmo({ atmoTrail: v }));
  seg("atmoAura", [[false, "Off"], [true, "On"]], () => !!cfg.atmoAura, (v) => setAtmo({ atmoAura: v }));
  seg("atmoColor", [["candle", "Candle"], ["wallpaper", "Wallpaper"], ["custom", "Custom"]], () => cfg.atmoColor || "candle", (v) => setAtmo({ atmoColor: v }));
  $("atmoCustom").value = /^#[0-9a-f]{6}$/i.test(cfg.atmoCustom || "") ? cfg.atmoCustom : "#7df9ff"; $("atmoCustom").hidden = cfg.atmoColor !== "custom";
  $("atmoBox").hidden = !atmoAny();
  const op = +cfg.atmoOpacity || 0.15, len = +cfg.atmoLen || 4, fade = +cfg.atmoFade || 450;
  $("atmoOpacity").value = op; $("atmoOpacityOut").textContent = Math.round(op * 100) + "%";
  $("atmoLen").value = len; $("atmoLenOut").textContent = len + " candles";
  $("atmoFade").value = fade; $("atmoFadeOut").textContent = fade + " ms";
  $("atmoHint").textContent = cfg.layer === "over" ? "The atmosphere needs the wallpaper under the chart (Wallpaper › Adjust › Layer › Under chart)."
    : cfg.powerSaver ? "Power saver is on, so the atmosphere is paused." : !atmoAny() ? "Smoke, a light trail or a soft glow at the live candle. It stays behind the candles and price labels, and only shows while the newest candle is on screen."
    : "Follows the live candle on every chart. It stays behind the candles, wicks and price labels, and fades out when you scroll back in history." + (cfg.atmoFx === "mist" && cfg.atmoColor === "candle" ? " Spectral Mist uses cyan and violet unless you pick a colour." : "");
  atmoPrevStart();
}
if ($("atmoOpacity")) {
  for (const [id, fmt] of [["atmoOpacity", (v) => Math.round(v * 100) + "%"], ["atmoLen", (v) => v + " candles"], ["atmoFade", (v) => v + " ms"]]) {
    $(id).oninput = (e) => { set({ [id]: +e.target.value }); $(id + "Out").textContent = fmt(+e.target.value); };
    $(id).ondblclick = () => { $(id).value = DEFAULTS[id]; $(id).oninput({ target: $(id) }); };
  }
  $("atmoCustom").oninput = (e) => set({ atmoCustom: e.target.value });
}
// the preview: a small chart with a live candle that ticks, your atmosphere drawn behind it (the same code as the chart)
const atmoPrev = { raf: 0, eng: null, t0: 0, last: 0, bg: null, key: "" };
function atmoPrevStart() { if (!atmoPrev.raf && $("atmoPrev")) atmoPrev.raf = requestAnimationFrame(atmoPrevFrame); }
function atmoPrevFrame(now) {
  atmoPrev.raf = 0;
  const cv = $("atmoPrev"), A = window.PriismAtmo, CL = window.__bdCandleLooks; if (!cv || !A || !CL) return;
  const vis = !document.hidden && !$("tab-candles").hidden && cv.getBoundingClientRect().height > 0 && cv.closest("details").open;
  const moving = atmoAny() || (cfg.zoneFx || []).length > 0;
  if (!vis) { if (moving) setTimeout(atmoPrevStart, 500); return; }
  if (now - atmoPrev.last < 33) { atmoPrevStart(); return; }
  const dt = atmoPrev.last ? (now - atmoPrev.last) / 1000 : 0.016; atmoPrev.last = now;
  const g = cv.getContext("2d"), W = cv.width, H = cv.height;
  const key = cfg.skin + "|" + W; if (atmoPrev.key !== key) { atmoPrev.bg = wallStill(W, H); atmoPrev.key = key; }
  g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
  if (atmoPrev.bg) { g.drawImage(atmoPrev.bg, 0, 0); g.fillStyle = "rgba(0,0,0,0.45)"; g.fillRect(0, 0, W, H); } else { g.fillStyle = "#07080d"; g.fillRect(0, 0, W, H); }
  const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#00ffa3", down = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ff2e97";
  // 14 candles; the live one's close wanders, so the effects have something to follow
  const n = 14, sp = W / (n + 2.5), bw = sp * 0.6, T = now / 1000, seq = [50, 54, 48, 57, 61, 55, 63, 66, 60, 68, 72, 67, 74];
  const live = 74 + Math.sin(T * 0.9) * 5 + Math.sin(T * 2.3) * 2, vals = [...seq, live], Y = (v) => H * 0.9 - ((v - 40) / 45) * H * 0.8;
  const zone = [Y(71), Y(66)];   // a zone near the live price
  const o = { fx: cfg.atmoFx || "off", trail: !!cfg.atmoTrail, aura: !!cfg.atmoAura, color: cfg.atmoColor === "custom" ? cfg.atmoCustom : cfg.atmoColor === "wallpaper" ? (wallAccentPrev() || null) : null,
    op: +cfg.atmoOpacity || 0.15, len: +cfg.atmoLen || 4, fade: +cfg.atmoFade || 450,
    zfx: Object.fromEntries(["near", "ripple", "flow", "dir", "fusion"].map((k) => [k, (cfg.zoneFx || []).includes(k)])), reduce: matchMedia("(prefers-reduced-motion: reduce)").matches, lite: false };
  const lx = sp * (n - 0.5), o0 = vals[n - 2], c0 = live, isUp = c0 >= o0, top = Y(Math.max(o0, c0)), bot = Y(Math.min(o0, c0));
  const pane = { l: 0, t: 0, w: W, h: H, zones: (cfg.zoneFx || []).length ? [[sp * 2, zone[0], W - sp * 2, zone[1] - zone[0], "164,107,255"]] : [],
    live: { x: lx, bw, sp, y0: top, y1: bot, hi: top - 6, lo: bot + 6, c: isUp ? up : down, up: isUp } };
  if (!atmoPrev.eng) atmoPrev.eng = A.engine();
  try { atmoPrev.eng.frame(g, [pane], o, now, dt); } catch {}
  if (pane.zones.length) { g.fillStyle = "rgba(164,107,255,0.12)"; g.fillRect(sp * 2, zone[0], W - sp * 2, zone[1] - zone[0]); g.strokeStyle = "rgba(164,107,255,0.8)"; g.lineWidth = 1; g.strokeRect(sp * 2 + 0.5, zone[0] + 0.5, W - sp * 2 - 1, zone[1] - zone[0] - 1); }
  // the candles on top, in your look and Candle FX
  const k = { fill: (a, b, c, d) => g.fillRect(a, b, c, d), style: (v) => { g.fillStyle = v; }, stroke: (v) => { g.strokeStyle = v; }, strokeRect: (a, b, c, d) => g.strokeRect(a, b, c, d), fillPath: () => g.fill(), px: 1, yfrac: 0 };
  const look = cfg.candleOn ? cfg.candleLook || "solid" : "solid", F = CL.fx ? CL.fx(fxCfg()) : null;
  for (let i = 0; i < n; i++) {
    const op_ = i ? vals[i - 1] : vals[0] - 3, cl = vals[i], u = cl >= op_, col = u ? up : down, cx = sp * (i + 0.5);
    const x = i === n - 1 ? lx : cx, t0 = Y(Math.max(op_, cl)), t1 = Y(Math.min(op_, cl));
    g.fillStyle = col; g.fillRect(Math.round(x - 0.5), t0 - 6, 1, t1 - t0 + 12); k.xfrac = x / W;
    CL.candle(g, look, Math.round(x - bw / 2), t0, Math.round(bw), Math.max(1, t1 - t0), col, u, k, null, F);
  }
  if (moving) atmoPrevStart();
}
const wallAccentPrev = () => { try { const p = window.PriismPalette && atmoPrev.bg ? window.PriismPalette.fromData(atmoPrev.bg.getContext("2d").getImageData(0, 0, atmoPrev.bg.width, atmoPrev.bg.height).data) : null; return p && p.accent; } catch { return null; } };
// ---------- Zone lights (Lines, zones & labels): pick any of them ----------
const ZONE_FX = [["near", "Proximity glow"], ["ripple", "Contact ripple"], ["flow", "Liquid border"], ["dir", "Directional light"], ["fusion", "Zone fusion"]];
function syncZoneFx() {
  const box = $("zoneFx"); if (!box) return;
  const cur = Array.isArray(cfg.zoneFx) ? cfg.zoneFx : [];
  box.innerHTML = "";
  for (const [id, label] of ZONE_FX) {
    const b = document.createElement("button"); b.textContent = label; b.dataset.z = id; b.className = cur.includes(id) ? "on" : "";
    b.setAttribute("aria-pressed", String(cur.includes(id)));
    b.onclick = () => { const now = Array.isArray(cfg.zoneFx) ? cfg.zoneFx : [], next = now.includes(id) ? now.filter((x) => x !== id) : [...now, id];
      set({ zoneFx: next, ...(cfg.candleOn ? {} : { candleOn: true }) }); $("candleOn").checked = true; syncZoneFx(); atmoPrevStart(); };
    box.appendChild(b);
  }
}
// ---------- Picture: Smart dim and Vignette centre (extend Dim and Vignette) ----------
function syncClarity() {
  if (!$("smartDim")) return;
  seg("smartDim", [["off", "Off"], ["soft", "Soft"], ["strong", "Strong"]], () => cfg.smartDim || "off", (v) => set({ smartDim: v }));
  seg("vignetteAt", [["screen", "Screen"], ["live", "Live price"]], () => cfg.vignetteAt || "screen", (v) => set({ vignetteAt: v }));
}
// the big Candle FX preview: your mix on your wallpaper (with Closed candles, the last candle is your live one)
function drawFxPreview() {
  const cv = $("fxPreview"), CL = window.__bdCandleLooks; if (!cv || !CL) return;
  const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#00ffa3", down = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ff2e97";
  const live = cfg.candleLook || "solid", closed = cfg.candleClosedLook && live !== "shift" && CL.META[cfg.candleClosedLook] ? cfg.candleClosedLook : "";
  const key = cfg.skin + "|" + cv.width; if (!drawFxPreview.bg || drawFxPreview.key !== key) { drawFxPreview.bg = wallStill(cv.width, cv.height); drawFxPreview.key = key; }
  try { CL.preview(cv, closed || live, up, down, +cfg.candleGlow || 0, drawFxPreview.bg, partsCfg(), closed ? live : undefined, fxCfg()); } catch {}
}
if ($("fxAmt")) {
  $("fxAmt").oninput = (e) => { set({ candleFxAmt: +e.target.value }); $("fxAmtOut").textContent = Math.round(+e.target.value * 100) + "%"; drawFxPreview(); };
  $("fxAmt").onchange = () => renderLookGrid();
}
if ($("fxReset")) $("fxReset").onclick = () => applyWithUndo({ ...FX_DEF, ...(cfg.candleBorder === "light" ? { candleBorder: "none" } : {}), ...(lookIsFx() ? { candleLook: "solid" } : {}) }, "Candle FX reset.");
function lookIsFx() { const CL = window.__bdCandleLooks, m = CL && CL.META[cfg.candleLook]; return !!(m && m.fx); }
// a calm closed look that lets the live candle stand out
const closedSuggest = (live) => (live === "matte" ? "outline" : "matte");
function renderCandles() {
  $("candleOn").checked = cfg.candleOn;
  seg("autoMatch", [[false, "Off"], [true, "On"]], () => !!cfg.autoMatch, (v) => { set({ autoMatch: v, ...(v ? { candleOn: true } : {}) }); if (v) $("candleOn").checked = true; });
  // Match-wallpaper only makes sense on your own uploaded wallpaper.
  const onMedia = cfg.skin === "media";
  // (older candles-only switch: Auto-match replaces it; kept only for people who already have it on)
  $("autoMatchRow").hidden = !onMedia || !cfg.autoMatch;
  $("autoMatchHint").hidden = !onMedia || !cfg.autoMatch;
  syncMatchOnPick();
  renderLookGrid();
  seg("closedMode", [["same", "Same as live"], ["own", "Own look"]], () => (cfg.candleClosedLook ? "own" : "same"),
    (v) => { set({ candleClosedLook: v === "own" ? (cfg.candleClosedLook || closedSuggest(cfg.candleLook || "solid")) : "", ...(v === "own" ? { candleOn: true } : {}) });
      if (v === "own") $("candleOn").checked = true; renderCandles(); });
  { const CL = window.__bdCandleLooks, m = CL && CL.META[cfg.candleClosedLook];
    $("closedHint").textContent = cfg.candleLook === "shift" ? "" : m
      ? `Closed candles: ${m.name}. The live candle (still forming) keeps your ${(CL.META[cfg.candleLook] || CL.META.solid).name} look, so it stands out. Scrolled back in history, every candle on screen is closed.`
      : "Give closed candles a calmer look of their own, so the live candle (still forming) stands out."; }
  $("shiftRow").hidden = cfg.candleLook !== "shift";
  $("shiftSpeed").value = cfg.shiftSpeed; $("shiftSpeedOut").textContent = cfg.shiftSpeed + "s";
  { const CL = window.__bdCandleLooks, m = CL && CL.META[cfg.candleLook];
    $("lookHint").textContent = m ? m.name + ": " + m.hint : (LOOK_HINT[cfg.candleLook] || ""); }
  $("lineGlow").value = cfg.lineGlow; $("lineGlowOut").textContent = Math.round(cfg.lineGlow * 100) + "%"; syncIndicators();
  seg("scaleTextMode", [["auto", "Auto"], ["custom", "Custom"]], () => (cfg.scaleText ? "custom" : "auto"),
    (v) => { set({ scaleText: v === "custom" ? $("scaleText").value : "" }); renderCandles(); });
  $("scaleText").value = cfg.scaleText || "#e9ebf2"; $("scaleText").hidden = !cfg.scaleText;
  seg("scaleSize", [[0, "Normal"], [1, "Large"], [2, "XL"]], () => cfg.scaleSize, (v) => set({ scaleSize: v }));
  fontPicker("scaleFont", "scaleFont");
  $("scaleBgColor").value = cfg.scaleBgColor || "#0b1320"; $("scaleBgColor").hidden = cfg.scaleBg !== "color";
  $("scaleGlow").value = cfg.scaleGlow; $("scaleGlowOut").textContent = Math.round(cfg.scaleGlow * 100) + "%";
  seg("scaleBold", [[false, "Regular"], [true, "Bold"]], () => cfg.scaleBold, (v) => set({ scaleBold: v }));
  seg("scaleBg", [["auto", "Auto"], ["glass", "Glass"], ["color", "Colour"]], () => (cfg.scaleBg === "clear" ? "auto" : cfg.scaleBg === "default" ? "glass" : cfg.scaleBg), (v) => { set({ scaleBg: v }); renderCandles(); });
  seg("scaleLabels", [[true, "Candle colours"], [false, "Original"]], () => cfg.scaleLabels, (v) => set({ scaleLabels: v }));
  $("candleGlow").value = cfg.candleGlow; $("candleGlowOut").textContent = Math.round(cfg.candleGlow * 100) + "%";
  $("candleUp").value = cfg.candleUp; $("candleDown").value = cfg.candleDown;
  syncParts();
  // filter chips + grouped grid
  const chips = $("candleChips"); chips.innerHTML = "";
  for (const g of ["All", ...CANDLE_GROUPS]) {
    const c = document.createElement("button");
    c.className = "chip" + (g === candleGroup ? " on" : ""); c.textContent = g;
    c.onclick = () => { candleGroup = g; renderCandles(); };
    chips.appendChild(c);
  }
  const box = $("candleCards"); box.innerHTML = "";
  // Yours: candle styles you saved (colours, look, glow and candle parts), first in the same grid as the built-in ones
  const mine = Array.isArray(cfg.myCandles) ? cfg.myCandles : [], cur = candleStyleNow(), curSig = JSON.stringify(cur);
  const saved = mine.some((m) => JSON.stringify(candleStyleOf(m)) === curSig);
  const custom = cfg.candleOn && !saved && !CANDLE_PRESETS.some(([, , u, d]) => u === cfg.candleUp && d === cfg.candleDown);
  if (mine.length || cfg.candleOn) box.insertAdjacentHTML("beforeend", `<div class="grp-label">Yours</div>`);
  for (const m of mine) {
    const b = document.createElement("button"), on = cfg.candleOn && JSON.stringify(candleStyleOf(m)) === curSig;
    b.className = "card preset mine" + (on ? " on" : "");
    b.innerHTML = bars(m.candleUp, m.candleDown) + `<div class="label">${esc(m.name)}</div><span class="x" title="Delete">\u2715</span><span class="ren" title="Rename">\u270E</span>`;
    b.onclick = (e) => {
      if (e.target.classList.contains("ren")) {               // rename in place (no pop-up: works in the app too)
        const lab = b.querySelector(".label"), inp = document.createElement("input"); inp.className = "renin"; inp.maxLength = 24; inp.value = m.name;
        lab.replaceWith(inp); inp.focus(); inp.select(); inp.onclick = (ev) => ev.stopPropagation();
        const done = (keep) => { const v = inp.value.trim().slice(0, 24); if (keep && v && v !== m.name) set({ myCandles: mine.map((x) => (x.id === m.id ? { ...x, name: v } : x)) }); renderCandles(); };
        inp.onkeydown = (ev) => { ev.stopPropagation(); if (ev.key === "Enter") done(true); if (ev.key === "Escape") done(false); }; inp.onblur = () => done(true);
        return;
      }
      if (e.target.classList.contains("x")) { const before = cfg.myCandles; set({ myCandles: mine.filter((x) => x.id !== m.id) }); renderCandles();
        return toast(`Deleted \u201c${m.name}\u201d.`, () => { set({ myCandles: before }); renderCandles(); }); }
      applyWithUndo({ candleOn: true, candlePreset: "custom", ...candleStyleOf(m) }, `Candles: ${m.name}.`);
    };
    box.appendChild(b);
  }
  if (cfg.candleOn && !saved) {
    const b = document.createElement("button"); b.className = "card preset save" + (custom ? " on" : "");
    b.innerHTML = bars(cfg.candleUp, cfg.candleDown) + `<div class="label">+ Save these</div>`;
    b.title = "Save your current candles (colours, look, glow and parts) here";
    b.onclick = () => { let n = mine.length + 1; while (mine.some((x) => x.name === `My candles ${n}`)) n++; const name = `My candles ${n}`;
      set({ myCandles: [...mine, { id: uid(), name, ...cur }].slice(-24) }); renderCandles(); toast(`Saved \u201c${name}\u201d under Yours. Tap \u270E to rename it.`); };
    box.appendChild(b);
  }
  // Candle FX mixes: a material, its lights, an atmosphere and colours, in the same grid as the colour presets
  if (candleGroup === "All" || candleGroup === "Candle FX") {
    if (candleGroup === "All") box.insertAdjacentHTML("beforeend", `<div class="grp-label">Candle FX</div>`);
    for (const [id, name, o] of FX_PRESETS) {
      const b = document.createElement("button"); b.dataset.mix = id;
      b.className = "card preset fxmixcard" + (cfg.candleOn && Object.keys(o).every((k) => k === "candleGlow" || cfg[k] === o[k]) ? " on" : "");
      b.innerHTML = bars(o.candleUp, o.candleDown) + `<div class="label">${esc(name)}</div>`; b.title = (window.__bdCandleLooks && window.__bdCandleLooks.META[o.candleLook] || {}).name || "";
      b.onclick = () => applyWithUndo({ candleOn: true, candlePreset: "custom", ...o, ...(cfg.candleClosedLook === o.candleLook ? { candleClosedLook: "" } : {}) }, `Candles: ${name}.`);
      box.appendChild(b);
    }
  }
  let lastGroup = null;
  CANDLE_PRESETS.filter((p) => candleGroup === "All" || p[4] === candleGroup).forEach(([id, name, up, down, group]) => {
    if (candleGroup === "All" && group !== lastGroup) { box.insertAdjacentHTML("beforeend", `<div class="grp-label">${group}</div>`); lastGroup = group; }
    const b = document.createElement("button");
    b.className = "card preset" + (cfg.candleOn && cfg.candleUp === up && cfg.candleDown === down ? " on" : "");
    b.innerHTML = bars(up, down) + `<div class="label">${esc(name)}</div>`;
    b.onclick = () => applyWithUndo({ candleOn: true, candleUp: up, candleDown: down, candlePreset: id }, `Candles: ${name}.`);
    box.appendChild(b);
  });
}
$("candleOn").onchange = (e) => set({ candleOn: e.target.checked });
// ---------- Candle parts: wick / border colours, hollow bodies, widths (drawn by candlelooks.js on every platform) ----------
// a candle style = colours + look + glow + parts (what a saved "Yours" preset keeps)
const CANDLE_STYLE_KEYS = ["candleUp", "candleDown", "candleLook","candleClosedLook", "candleGlow", "candleWick", "candleWickUp", "candleWickDown", "candleBorder", "candleBorderUp", "candleBorderDown", "candleBorderW", "candleHollow", "candleWickW", "candleBodyW", "candleFxCore", "candleFxEdge", "candleFxAmt"];
const candleStyleNow = () => Object.fromEntries(CANDLE_STYLE_KEYS.map((k) => [k, cfg[k]]));
const candleStyleOf = (m) => Object.fromEntries(CANDLE_STYLE_KEYS.map((k) => [k, k in m ? m[k] : DEFAULTS[k]]));
const PARTS_DEF = { candleWick: "same", candleWickUp: "#9aa4b8", candleWickDown: "#9aa4b8", candleBorder: "none", candleBorderUp: "#ffffff", candleBorderDown: "#ffffff", candleBorderW: 1, candleHollow: "none", candleWickW: 0, candleBodyW: 1 };
// Candle FX light layers (Chart › Candle FX), as candlelooks.js reads them
const fxCfg = () => ({ core: cfg.candleFxCore, edge: cfg.candleFxEdge, amt: cfg.candleFxAmt });
const partsCfg = () => ({ wick: cfg.candleWick, wickUp: cfg.candleWickUp, wickDown: cfg.candleWickDown, border: cfg.candleBorder, borderUp: cfg.candleBorderUp,
  borderDown: cfg.candleBorderDown, borderW: cfg.candleBorderW, hollow: cfg.candleHollow, wickW: cfg.candleWickW, bodyW: cfg.candleBodyW });
// any part changed turns candles on (parts are part of Priism's candles)
const setPart = (o) => { set({ ...o, ...(cfg.candleOn ? {} : { candleOn: true }) }); $("candleOn").checked = true; syncParts(); renderLookGrid(); };
function syncParts() {
  if (!$("candleWick")) return;
  seg("candleWick", [["same", "Same"], ["soft", "Soft"], ["custom", "Colour"]], () => cfg.candleWick || "same", (v) => setPart({ candleWick: v }));
  $("wickColRow").hidden = cfg.candleWick !== "custom";
  $("candleWickUp").value = cfg.candleWickUp; $("candleWickDown").value = cfg.candleWickDown;
  seg("candleWickW", [[0, "Auto"], [1, "1"], [2, "2"], [3, "3"], [4, "4"]], () => +cfg.candleWickW || 0, (v) => setPart({ candleWickW: v }));
  seg("candleBorder", [["none", "Off"], ["custom", "Colour"], ["light", "Light"]], () => (cfg.candleBorder === "light" || (cfg.candleFxEdge === "laser" && (cfg.candleBorder || "none") === "none") ? "light" : cfg.candleBorder || "none"), (v) => setPart({ candleBorder: v, ...(cfg.candleFxEdge === "laser" ? { candleFxEdge: "off" } : {}) }));
  $("borderColRow").hidden = cfg.candleBorder !== "custom";
  $("candleBorderUp").value = cfg.candleBorderUp; $("candleBorderDown").value = cfg.candleBorderDown;
  $("borderWRow").hidden = cfg.candleBorder !== "custom" && (cfg.candleHollow || "none") === "none";
  seg("candleBorderW", [[1, "1"], [2, "2"], [3, "3"]], () => +cfg.candleBorderW || 1, (v) => setPart({ candleBorderW: v }));
  seg("candleHollow", [["none", "Off"], ["up", "Up"], ["down", "Down"], ["both", "Both"]], () => cfg.candleHollow || "none", (v) => setPart({ candleHollow: v }));
  $("candleBodyW").value = +cfg.candleBodyW || 1; $("candleBodyWOut").textContent = Math.round((+cfg.candleBodyW || 1) * 100) + "%";
  drawPartsPreview();
}
for (const id of ["candleWickUp", "candleWickDown", "candleBorderUp", "candleBorderDown"]) if ($(id)) $(id).oninput = (e) => setPart({ [id]: e.target.value });
if ($("candleBodyW")) { $("candleBodyW").oninput = (e) => setPart({ candleBodyW: +e.target.value }); $("candleBodyW").ondblclick = () => setPart({ candleBodyW: 1 }); }
if ($("partsReset")) $("partsReset").onclick = () => applyWithUndo({ ...PARTS_DEF }, "Candle parts reset.");
// a bigger preview of your candles with their parts, on your wallpaper
function drawPartsPreview() {
  const cv = $("partsPreview"), CL = window.__bdCandleLooks; if (!cv || !CL || cv.hidden) return;
  const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#00ffa3", down = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ff2e97";
  let bgc = null; try { const sk = WickedSkins[cfg.skin]; if (sk) { bgc = document.createElement("canvas"); bgc.width = cv.width; bgc.height = cv.height; const s0 = makeSkin(cfg.skin, bgc.getContext("2d")); s0.resize(cv.width, cv.height); s0.frame(3, 0.016); } } catch { bgc = null; }
  try { CL.preview(cv, cfg.candleLook || "solid", up, down, +cfg.candleGlow || 0, bgc, partsCfg(), undefined, fxCfg()); } catch {}
}
$("shiftSpeed").oninput = (e) => { set({ shiftSpeed: +e.target.value }); $("shiftSpeedOut").textContent = e.target.value + "s"; };
$("lineGlow").oninput = (e) => { set({ lineGlow: +e.target.value }); $("lineGlowOut").textContent = Math.round(+e.target.value * 100) + "%"; };
// a small preview of a zone in the chosen shape + border, on your wallpaper (drawn with the chart's own code)
function drawZonePreview() {
  const cv = $("zonePrev"), L = window.__bdCandleLooks; if (!cv || !L || !L.zoneBox) return;
  const g = cv.getContext("2d"), W = cv.width, H = cv.height;
  g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
  try { if (WickedSkins[cfg.skin]) { const s = makeSkin(cfg.skin, g); s.resize(W, H); s.frame(3, 0.016); g.fillStyle = "rgba(0,0,0,0.35)"; g.fillRect(0, 0, W, H); } else { g.fillStyle = "#0b0d12"; g.fillRect(0, 0, W, H); } } catch {}
  const col = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#ff3366", c2 = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#33ff99";
  const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)).join(",");
  const k = { begin: () => g.beginPath(), fill: () => g.fill(), stroke: () => g.stroke(), style: (v) => { g.fillStyle = v; }, strokeStyle: (v) => { g.strokeStyle = v; } };
  const st = { shape: cfg.zoneShape || "square", border: cfg.zoneBorder || "line", style: cfg.zoneStyle || "flat", px: 2 }, a = Math.max(0.08, Math.min(0.45, +cfg.zoneFill || 0.12)) + 0.08, glow = +cfg.lineGlow || 0;
  const box = (x, y, w, h, c) => { const z = { f: `rgba(${rgb(c)},${a})`, g: c, glow, e: `rgba(${rgb(c)},0.9)` };
    if (!L.zoneBox(g, k, x, y, w, h, z, st)) { g.fillStyle = z.f; g.fillRect(x, y, w, h); g.strokeStyle = z.e; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, w - 2, h - 2); } };
  box(30, 14, W * 0.62, 44, col); box(W * 0.3, 70, W * 0.62, 40, c2);
}
// Indicators: their colours (own / rainbow / your candle colours / your wallpaper's / any colour) + the glow above
function syncIndicators() {
  if (!$("indMode")) return;
  seg("indMode", [["own", "Own"], ["rainbow", "Rainbow"], ["gradient", "Gradient"], ["candles", "Candles"], ["wallpaper", "Wallpaper"], ["custom", "Custom"]], () => cfg.indMode || "own",
    (v) => { set(v === "custom" && !/^#/.test(cfg.indColor || "") ? { indMode: v, indColor: $("indColor").value || "#ffd166" } : { indMode: v }); syncIndicators(); });
  $("indColRow").hidden = cfg.indMode !== "custom";
  // zones: how strong recoloured zones are (and, with Dim, every zone), so the price stays readable through them
  if ($("zoneFill")) { const z = $("zoneFill"); z.value = +cfg.zoneFill || 0.12; $("zoneFillOut").textContent = Math.round(z.value * 100) + "%";
    z.oninput = () => { set({ zoneFill: +z.value }); $("zoneFillOut").textContent = Math.round(z.value * 100) + "%"; }; z.ondblclick = () => { z.value = 0.12; z.oninput(); }; }
  if ($("zoneDim")) seg("zoneDim", [[false, "Off"], [true, "On"]], () => !!cfg.zoneDim, (v) => set({ zoneDim: v }));
  // zone boxes: their shape (rounded corners, pill ends) and border design, also for zones left in their own colours
  syncZoneFx();
  if ($("zoneReact")) seg("zoneReact", [["off", "Off"], ["glow", "Glow"], ["strong", "Strong"], ["edge", "Edge"], ["spotlight", "Spotlight"], ["shimmer", "Shimmer"]], () => cfg.zoneReact || "off", (v) => set({ zoneReact: v }));
  if ($("zoneShape")) seg("zoneShape", [["square", "Square"], ["rounded", "Rounded"], ["pill", "Pill"]], () => (cfg.zoneShape === "oval" ? "pill" : cfg.zoneShape || "square"), (v) => { set({ zoneShape: v }); drawZonePreview(); });
  if ($("zoneStyle")) seg("zoneStyle", [["flat", "Flat"], ["fade", "Fade"], ["shine", "Shine"], ["glass", "Glass"], ["hollow", "Hollow"]], () => cfg.zoneStyle || "flat", (v) => { set({ zoneStyle: v }); drawZonePreview(); });
  if ($("zoneBorder")) seg("zoneBorder", [["line", "Line"], ["dashed", "Dashed"], ["double", "Double"], ["glow", "Glow"], ["none", "None"]], () => cfg.zoneBorder || "line", (v) => { set({ zoneBorder: v }); drawZonePreview(); });
  drawZonePreview();
  // Gradient colours: your own 2-3, or the built-in gradients
  // Markers: the small shapes on the chart (signal arrows, your trade arrows, an app's markers), in any colour
  if ($("markMode")) { seg("markMode", [["own", "Own"], ["custom", "Colour"], ["candles", "Candles"], ["rainbow", "Rainbow"], ["gradient", "Gradient"], ["wallpaper", "Wallpaper"]], () => cfg.markMode || "own", (v) => { set({ markMode: v }); syncIndicators(); });
    $("markColor").value = /^#[0-9a-f]{6}$/i.test(cfg.markColor || "") ? cfg.markColor : "#ffd166"; $("markColor").hidden = cfg.markMode !== "custom"; }
  if ($("gradRow")) { $("gradRow").hidden = cfg.indMode !== "gradient" && cfg.markMode !== "gradient";
    const g = Array.isArray(cfg.indGrad) ? cfg.indGrad : [], DEF = ["#2fe6c8", "#3a9bff", "#8a6cff"];
    ["g1", "g2", "g3"].forEach((idk, k) => { const inp = $(idk); inp.value = g[k] || DEF[k];
      inp.oninput = () => set({ indGrad: ["g1", "g2", "g3"].map((x) => $(x).value) }); });
    seg("gradMode", [["auto", "Built-in"], ["mine", "My colours"]], () => (Array.isArray(cfg.indGrad) && cfg.indGrad.length >= 2 ? "mine" : "auto"),
      (v) => { set({ indGrad: v === "mine" ? ["g1", "g2", "g3"].map((x) => $(x).value) : [] }); syncIndicators(); });
    $("gradPick").hidden = g.length < 2; }
  if ($("drawOn")) seg("drawOn", [[false, "Leave as they are"], [true, "Style them too"]], () => !!cfg.drawOn, (v) => set({ drawOn: v }));
  renderEachInd();
  $("indColor").value = /^#[0-9a-f]{6}$/i.test(cfg.indColor || "") ? cfg.indColor : "#ffd166";
}
if ($("indColor")) $("indColor").oninput = (e) => set({ indColor: e.target.value });
if ($("markColor")) $("markColor").oninput = (e) => set({ markColor: e.target.value });
// Each indicator: the lines and zones Priism has seen on your chart (by their own colour), each with its own colour,
// glow, thickness (lines) and a hide switch. Settings are by colour, so they follow that indicator on every chart.
const colourName = (k) => { const [r, g, b] = k.split(",").map(Number), mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  if (mx - mn < 24) return mx > 200 ? "white" : mx > 90 ? "grey" : "dark grey";
  const h = ((mx === r ? (g - b) / (mx - mn) + (g < b ? 6 : 0) : mx === g ? (b - r) / (mx - mn) + 2 : (r - g) / (mx - mn) + 4) * 60) % 360;
  return h < 15 || h >= 345 ? "red" : h < 40 ? "orange" : h < 65 ? "yellow" : h < 160 ? "green" : h < 195 ? "teal" : h < 250 ? "blue" : h < 290 ? "purple" : "pink"; };
const toHex6 = (k) => "#" + k.split(",").map((n) => (+n).toString(16).padStart(2, "0")).join("");
// a zone's own shape / border / style in Each indicator (key in indCustom, label, choices)
const ZONE_OWN = [["s", "Shape", [["square", "Square"], ["rounded", "Rounded"], ["pill", "Pill"]]],
  ["b", "Border", [["line", "Line"], ["dashed", "Dashed"], ["double", "Double"], ["glow", "Glow"], ["none", "None"]]],
  ["y", "Style", [["flat", "Flat"], ["fade", "Fade"], ["shine", "Shine"], ["glass", "Glass"], ["hollow", "Hollow"]]]];
async function renderEachInd() {
  const box = $("indEach"); if (!box) return;
  let seen = null; try { seen = (await storeGet({ indSeen: null })).indSeen; } catch {}
  const cust = cfg.indCustom || {}, items = (seen && Array.isArray(seen.items) ? seen.items : []);
  // keep any you've set up even if not on this chart right now
  for (const k of Object.keys(cust)) if (!items.some((i) => i.k === k)) items.push({ k, kind: "line", a: 1, name: "", off: true });
  if (!items.length) { box.innerHTML = `<p class="hint">Open a chart with your indicators on it (with Priism on). They show up here within a few seconds.</p>`; return; }
  box.innerHTML = (seen && seen.host ? `<p class="hint" style="margin:0 0 6px">On ${esc(seen.host)}:</p>` : "") + items.map((it) => {
    const e = cust[it.k] || {}, col = /^#/.test(e.c || "") ? e.c : toHex6(it.k), set = !!cust[it.k];
    const label = it.name || `${it.kind === "zone" ? "Zone" : it.kind === "marker" ? "Marker" : "Line"} (${colourName(it.k)})`;
    return `<div class="ind-row${set ? " set" : ""}${it.off ? " off" : ""}" data-k="${it.k}">
      <div class="ind-h"><i class="sw" style="background:${toHex6(it.k)}${it.kind === "zone" ? ";border-radius:2px" : ""}"></i><b>${esc(label)}</b>${it.off ? "<small>not on this chart</small>" : ""}
        <button class="link" data-a="reset" ${set ? "" : "hidden"}>Reset</button></div>
      <div class="ind-c"><input type="color" data-a="c" value="${col}" title="Colour" /><button class="chip${e.c === "rainbow" ? " on" : ""}" data-a="rb">Rainbow</button><button class="chip${e.c === "gradient" ? " on" : ""}" data-a="gr">Gradient</button>
        <button class="chip${e.h ? " on" : ""}" data-a="h" title="Hide it on the chart" style="margin-left:auto">${e.h ? "Hidden" : "Hide"}</button></div>
      <div class="ind-c"><span class="lbl">Glow</span><input type="range" data-a="g" min="0" max="1" step="0.05" value="${e.g === undefined || e.g === null ? 0 : e.g}" />
        ${it.kind === "line" ? `<span class="lbl">Width</span><input type="range" data-a="w" min="0" max="3" step="0.5" value="${+e.w || 0}" />` : ""}</div>
      ${it.kind === "zone" ? ZONE_OWN.map(([key, lbl, opts]) => `<div class="ind-c wrap" title="This zone's own ${lbl.toLowerCase()}. Like all zones = Chart › Lines, zones & labels › Zone ${lbl.toLowerCase()}"><span class="lbl">${lbl}</span>${[["", "Like all zones"], ...opts].map(([v, n]) =>
        `<button class="chip${(e[key] || "") === v ? " on" : ""}" data-a="${key}" data-v="${v}">${n}</button>`).join("")}</div>`).join("") : ""}</div>`; }).join("");
  const upd = (k, patch) => { const next = { ...(cfg.indCustom || {}) }; next[k] = { ...(next[k] || {}), ...patch }; set({ indCustom: next }); };
  box.querySelectorAll(".ind-row").forEach((row) => { const k = row.dataset.k;
    row.querySelector('[data-a="c"]').oninput = (e) => upd(k, { c: e.target.value });
    row.querySelector('[data-a="rb"]').onclick = () => { upd(k, { c: (cfg.indCustom[k] || {}).c === "rainbow" ? "" : "rainbow" }); renderEachInd(); };
    row.querySelector('[data-a="gr"]').onclick = () => { upd(k, { c: (cfg.indCustom[k] || {}).c === "gradient" ? "" : "gradient" }); renderEachInd(); };
    row.querySelector('[data-a="g"]').oninput = (e) => upd(k, { g: +e.target.value });
    const w = row.querySelector('[data-a="w"]'); if (w) w.oninput = (e) => upd(k, { w: +e.target.value });
    row.querySelector('[data-a="h"]').onclick = () => { upd(k, { h: !(cfg.indCustom[k] || {}).h }); renderEachInd(); };
    for (const [key] of ZONE_OWN) row.querySelectorAll(`[data-a="${key}"]`).forEach((b) => { b.onclick = () => { upd(k, { [key]: b.dataset.v }); renderEachInd(); }; });
    row.querySelector('[data-a="reset"]').onclick = () => { const next = { ...(cfg.indCustom || {}) }; delete next[k]; set({ indCustom: next }); renderEachInd(); };
  });
}
try { chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.indSeen) renderEachInd(); }); } catch {}
$("scaleGlow").oninput = (e) => { set({ scaleGlow: +e.target.value }); $("scaleGlowOut").textContent = Math.round(+e.target.value * 100) + "%"; };
$("scaleText").oninput = (e) => set({ scaleText: e.target.value });
$("scaleBgColor").oninput = (e) => set({ scaleBgColor: e.target.value });
$("uiAccent").oninput = (e) => set({ uiAccent: e.target.value });
$("candleGlow").oninput = (e) => { set({ candleGlow: +e.target.value }); renderLookGrid(); $("candleGlowOut").textContent = Math.round(+e.target.value * 100) + "%"; };
$("candleUp").oninput = (e) => { set({ candleUp: e.target.value, candleOn: true, candlePreset: "custom" }); $("candleOn").checked = true; renderLookGrid(); };
$("candleDown").oninput = (e) => { set({ candleDown: e.target.value, candleOn: true, candlePreset: "custom" }); $("candleOn").checked = true; renderLookGrid(); };

// ---------- undo ----------
// Any one-click change can be undone from the toast at the bottom.
let undoTimer;
function toast(msg, undo, btn) {
  $("toastMsg").textContent = msg;
  $("toast").hidden = false;
  $("toastUndo").hidden = !undo; $("toastUndo").textContent = btn || "Undo";
  $("toastUndo").onclick = undo ? () => { undo(); $("toast").hidden = true; } : null;
  clearTimeout(undoTimer); undoTimer = setTimeout(() => ($("toast").hidden = true), undo ? 8000 : 3000);
}
// ---------- Match everything: the whole chart in your wallpaper's colours, in one tap ----------
// The wallpaper's colours are read here in the panel (the same code the chart uses, skins.js PriismPalette), so it
// works for every wallpaper, on the browser, desktop and Android, even before a chart is open.
async function wallpaperPixels() {
  const c = document.createElement("canvas"); c.width = 192; c.height = 108; const g = c.getContext("2d", { willReadFrequently: true });
  // styling chart 2, 3...: read THAT chart's wallpaper (its Mix pick), else your main one
  const own = styleChart > 1 && (cfg.chartSkins || {})[styleChart], skinId = own ? (own.startsWith("media:") ? "media" : own) : cfg.skin, mediaId = own && own.startsWith("media:") ? own.slice(6) : cfg.mediaId;
  if (skinId === "media") {
    const m = (cfg.media || []).find((x) => x.id === mediaId), src = m && (m.thumb || (m.type !== "video" && m.src));
    if (!src) return null;
    const img = new Image(); await new Promise((r) => { img.onload = img.onerror = r; img.src = src; });
    if (!img.naturalWidth) return null;
    g.drawImage(img, 0, 0, c.width, c.height); return g.getImageData(0, 0, c.width, c.height).data;
  }
  const def = WickedSkins[skinId]; if (!def) return null;
  const sk = makeSkin(skinId, g); sk.resize(c.width, c.height);
  // let it run ~4 s (some wallpapers build up over time, like Code Rain) and sample three moments
  const out = new Uint8ClampedArray(c.width * c.height * 4 * 3); let k = 0;
  for (let i = 1; i <= 120; i++) {
    try { sk.frame(i / 30, 1 / 30); } catch {}
    if (i % 40 === 0) { out.set(g.getImageData(0, 0, c.width, c.height).data, k); k += c.width * c.height * 4; }
  }
  return out;
}
function mixHex(a, b, f) { const x = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16)), y = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  return "#" + x.map((v, i) => Math.round(v + (y[i] - v) * f).toString(16).padStart(2, "0")).join(""); }
let matchRun = 0;
async function matchEverything(auto) {
  const run = ++matchRun, pick = String(cfg.skin) + "|" + String(cfg.mediaId || "");
  let pal = null, grey = false, lum = 0.15;
  try { const d = await wallpaperPixels(); if (d) { pal = window.PriismPalette.fromData(d, true);
    let L = 0, n = 0; for (let i = 0; i < d.length; i += 16) { L += (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255; n++; } lum = n ? L / n : lum; } } catch {}
  if (!pal) { pal = { up: "#9fd8ff", down: "#ff6b8b", accent: "#c9d3e3", colors: ["#c9d3e3", "#9fd8ff", "#ff6b8b"] }; grey = true; }   // a grey wallpaper: a matching silver look
  // text on the chart: light tints of the wallpaper's colour on a dark wallpaper, deep ones on a bright wallpaper
  const bright = lum > 0.55, accent = pal.accent;
  // candles must stand out on a dark wallpaper: a deep colour (a saturated blue reads almost black) is lifted
  // towards white until it is bright enough, keeping its hue
  const lumHex = (x) => [1, 3, 5].map((i) => parseInt(x.slice(i, i + 2), 16) / 255).reduce((a, v, i) => a + v * [0.2126, 0.7152, 0.0722][i], 0);
  const lift = (x) => { if (bright || !/^#[0-9a-f]{6}$/i.test(x || "")) return x; let f = 0, y = x; while (lumHex(y) < 0.42 && f < 0.7) { f += 0.05; y = mixHex(x, "#ffffff", f); } return y; };
  pal = { ...pal, up: lift(pal.up), down: lift(pal.down) };
  // text (price scale, legend, ticker) must read: on a dark / black wallpaper never darker than a light grey, on a
  // bright one never lighter than a deep tone. A black wallpaper's "colour" is near black, so it's lifted a long way.
  const toLum = (x, min, max) => { let y = x, f = 0; if (min) while (lumHex(y) < min && f < 1) { f += 0.04; y = mixHex(x, "#ffffff", Math.min(1, f)); }
    if (max) while (lumHex(y) > max && f < 1) { f += 0.04; y = mixHex(x, "#000000", Math.min(1, f)); } return y; };
  const light = bright ? toLum(mixHex(accent, "#000000", 0.62), 0, 0.3) : toLum(mixHex(accent, "#ffffff", 0.5), 0.62, 0),
    soft = bright ? toLum(mixHex(accent, "#000000", 0.4), 0, 0.42) : toLum(mixHex(accent, "#ffffff", 0.25), 0.45, 0);
  // picked another wallpaper while this one was being read: only the newest one counts
  if (run !== matchRun || pick !== String(cfg.skin) + "|" + String(cfg.mediaId || "")) return;
  const name = cfg.skin === "media" ? "your wallpaper" : (WickedSkins[cfg.skin] || {}).name || "your wallpaper";
  const colors = (Array.isArray(pal.colors) && pal.colors.length >= 2 ? pal.colors : [pal.up, pal.down, accent]).slice(0, 5);
  applyWithUndo((() => { const all = {
    enabled: true,
    candleOn: true, candleUp: pal.up, candleDown: pal.down, candlePreset: "custom", lineGlow: Math.max(+cfg.lineGlow || 0, 0.25),
    chOn: true, chColor: accent, chLabels: true, gridOn: true, gridColor: accent, gridAlpha: 0.18, gridStyle: cfg.gridOn ? cfg.gridStyle : "dotted",
    plOn: true, plColor: "candle", scaleText: light, scaleGlow: Math.max(+cfg.scaleGlow || 0, 0.2),
    sbOn: true, sbColor: soft,                                     // session breaks
    tkOn: true, tkColor: light, tkGlow: !bright,
    bracketOn: true, bracketProfit: pal.up, bracketLoss: pal.down, bracketQty: soft, bracketLineColor: accent,
    pnlUp: pal.up, pnlDown: pal.down,
    panelMode: "skin", dlgMode: "glass", uiAccent: soft,
    // indicators, their zones and your drawings take the wallpaper's own colours (each one its own; the same reading as
    // the candles), zones soft so the price reads through them; the legend and indicator text stay readable
    markMode: "wallpaper", indMode: "wallpaper", wallMatch: { src: String(cfg.skin) + "|" + String(cfg.mediaId || ""), colors }, zoneFill: Math.min(+cfg.zoneFill || 0.12, 0.14),
    drawOn: true, lgOn: true, lgColor: light, lgVals: "own", txtMode: "custom", txtColor: light,   // legend names in a light (or, on bright wallpapers, deep) tint of the wallpaper
    // everything means everything: indicators you'd given their own colour (Each indicator) take the wallpaper's too
    // (hidden ones stay hidden, and their shapes, borders, styles and widths stay), and the chart frame and interface
    // skin, if they're on, take the wallpaper's accent
    indCustom: Object.fromEntries(Object.entries(cfg.indCustom || {}).map(([k, e]) => { const { c, g, ...rest } = e || {}; return [k, rest]; }).filter(([, e]) => Object.values(e).some((v) => v))),
    ...(cfg.frameOn ? { frameMode: "accent" } : {}), ...(cfg.barPatOn ? { barMode: "accent" } : {}),
    ...(cfg.scaleBg === "color" ? { scaleBgColor: bright ? mixHex(accent, "#ffffff", 0.8) : mixHex(accent, "#000000", 0.8) } : {}),
  };
  // styling chart 2, 3...: only that chart's own settings (the page-wide panels, ticker and legend stay as they are)
  return styleChart > 1 ? Object.fromEntries(Object.entries(all).filter(([k]) => PER_CHART_KEYS.has(k))) : all; })(), grey ? `${name} is a grey wallpaper, so everything now has a matching silver look.` : auto ? `Auto-matched everything to ${name}.` : `Everything now matches ${name}.`);
}
if ($("matchAll")) $("matchAll").onclick = () => matchEverything();
// Auto-match: every wallpaper you pick (built-in, your own upload or from the Workshop) runs Match everything on its
// own. One-tap looks keep their own designed colours.
function autoMatchPick() { if (cfg.matchOnPick && !noAutoMatch) matchEverything(true); }
function syncMatchOnPick() {
  const pick = (v) => { set({ matchOnPick: v }); syncMatchOnPick(); if (v) matchEverything(true); };
  for (const id of ["matchOnPick"]) if ($(id)) seg(id, [[false, "Off"], [true, "On"]], () => !!cfg.matchOnPick, pick);
  let view = ""; try { view = skinView; } catch {}                // (skinView is declared further down)
  if ($("matchPickRow")) $("matchPickRow").hidden = view === "looks";
}

function applyWithUndo(changes, label) {
  if (window.WickedMigrate && WickedMigrate.look) changes = WickedMigrate.look(changes);   // a look saved before 0.1.86
  // a look's wallOpts become that wallpaper's settings (skinOpts); a look without them leaves the wallpaper's alone
  if ("wallOpts" in changes) { const w = changes.wallOpts, sk = changes.skin || cfg.skin; changes = { ...changes }; delete changes.wallOpts;
    if (WickedSkins[sk]) { const all = { ...(cfg.skinOpts || {}) }; if (w && typeof w === "object") all[sk] = w; else delete all[sk]; changes.skinOpts = all; } }
  const before = Object.fromEntries(Object.keys(changes).map((k) => [k, cfg[k]]));
  set(changes); refreshAll();
  toast(label, () => { set(before); refreshAll(); });
}
function refreshAll() { renderChartStyle(); syncPanels(); syncPatterns(); syncTradePanel(); syncShortcuts(); syncTimer(); syncExtras(); syncSkinView(); renderSkins(); renderMedia(); renderCandles(); syncTune(); syncWatermark(); renderQuick(); renderLoadouts(); syncSessions(); syncSymbols(); syncCharts(); syncPnl(); syncBracket(); syncGoal(); renderJournal(); if ($("clipMode")) syncClipMode(); }

// ---------- one-click looks: skin + candles + glow + price scale in one tap ----------
// Look groups (shown as chips). New looks: add the id here or they land in "Classic".
const LOOK_GROUP = {
  "ocean-calm": "Calm", nightfall: "Calm", daybreak: "Calm", sterling: "Calm", harbor: "Calm", dune: "Calm", "clean-focus": "Calm", blossom: "Calm", "market-wall": "Calm", "midnight-moon": "Calm", "twinkle-oled": "Calm",
  glowstick: "Glow", blacklight: "Glow", vaporwave: "Glow", molten: "Glow", warp: "Glow", spectrum: "Glow", "neon-night": "Glow", firefly: "Glow",
  horizon: "Wow", bloom: "Wow", ink: "Wow", kaleido: "Wow", slick: "Wow", hypercube: "Wow", helix: "Wow", synapse: "Wow", "koi-pond": "Wow", "rainy-night": "Wow", "ringed-giant": "Wow", "deep-blue": "Wow", "cozy-room": "Wow", "tokyo-night": "Wow", "trading-floor": "Wow",
  "xmas-spirit": "Seasonal", "hallows-eve": "Seasonal", "cozy-lights": "Seasonal", "silent-night": "Seasonal", "northern-noel": "Seasonal",
};
const LOOK_GROUPS = ["All", "Signature", "Wow", "Seasonal", "Calm", "Glow", "Classic"];
const groupOf = (q) => q.group || LOOK_GROUP[q.id] || "Classic";
const QUICK_LOOKS = [
  // ----- Signature: the painted collection, each with candles, scale and glow made for it. A look can carry its
  // wallpaper's own settings (wallOpts: Orion is Storm with mountains and a violet recolour). -----
  { id: "sig-imperial", group: "Signature", name: "Imperial", sub: "Black silk · Gold", skin: "silk",
    set: { candleOn: true, candleUp: "#f2cf86", candleDown: "#8d7a63", candleLook: "chrome", candleGlow: 0.12, candlePreset: "custom", lineGlow: 0.15, scaleText: "#f3dca8", scaleGlow: 0.15, scaleBg: "auto", dim: 0.2 } },
  { id: "sig-eclipse", group: "Signature", name: "Eclipse", sub: "Totality · Corona gold", skin: "eclipse",
    set: { candleOn: true, candleUp: "#ffd27a", candleDown: "#e0675a", candleLook: "glass", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.2, scaleText: "#ffe3b0", scaleGlow: 0.2, scaleBg: "auto", dim: 0.18 } },
  { id: "sig-orion", group: "Signature", name: "Orion", sub: "Storm · Violet lightning", skin: "storm", wallOpts: { lightning: true, ground: true, rc: { c: ["#7b3cff", "#c26bff", "#3a2a8a"], s: 0.85 } },
    set: { candleOn: true, candleUp: "#c9a2ff", candleDown: "#5f6bff", candleLook: "neon", candleGlow: 0.35, candlePreset: "custom", lineGlow: 0.3, scaleText: "#e3d2ff", scaleGlow: 0.25, scaleBg: "auto", dim: 0.2 } },
  { id: "sig-glacier", group: "Signature", name: "Glacier", sub: "Icy peaks · Mist", skin: "mountains", wallOpts: { moon: false, fog: 0.9 },
    set: { candleOn: true, candleUp: "#bfefff", candleDown: "#7b93c9", candleLook: "crystal", candleGlow: 0.15, candlePreset: "custom", lineGlow: 0.15, scaleText: "#e3f4ff", scaleGlow: 0.15, scaleBg: "glass", dim: 0.3 } },
  { id: "sig-void", group: "Signature", name: "Void", sub: "Energy waves · Violet", skin: "void",
    set: { candleOn: true, candleUp: "#d58bff", candleDown: "#5b6bff", candleLook: "plasma", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.3, scaleText: "#ead2ff", scaleGlow: 0.25, scaleBg: "auto", dim: 0.15 } },
  { id: "sig-aurora", group: "Signature", name: "Aurora", sub: "Northern lights · Lake", skin: "aurora",
    set: { candleOn: true, candleUp: "#5dffc0", candleDown: "#a07bff", candleLook: "hologram", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.25, scaleText: "#c9fff0", scaleGlow: 0.2, scaleBg: "auto", dim: 0.15 } },
  { id: "sig-neoncity", group: "Signature", name: "Neon City", sub: "Night skyline · Neon", skin: "neoncity",
    set: { candleOn: true, candleUp: "#2ff0ff", candleDown: "#ff4fd0", candleLook: "fiber", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.3, scaleText: "#bff8ff", scaleGlow: 0.25, scaleBg: "auto", dim: 0.25 } },
  { id: "sig-obsidian", group: "Signature", name: "Obsidian", sub: "Black metal · Gold edges", skin: "obsidian",
    set: { candleOn: true, candleUp: "#e8c27a", candleDown: "#6f6a64", candleLook: "obsidian", candleGlow: 0.1, candlePreset: "custom", lineGlow: 0.12, scaleText: "#efd9a8", scaleGlow: 0.1, scaleBg: "auto", dim: 0.1 } },
  { id: "sig-storm", group: "Signature", name: "Storm", sub: "Thunderclouds · Lightning", skin: "storm", wallOpts: { lightning: true, ground: false },
    set: { candleOn: true, candleUp: "#9fc4ff", candleDown: "#8a93a8", candleLook: "liquid", candleGlow: 0.15, candlePreset: "custom", lineGlow: 0.15, scaleText: "#d8e6ff", scaleGlow: 0.15, scaleBg: "auto", dim: 0.15 } },
  { id: "sig-bloodmoon", group: "Signature", name: "Blood Moon", sub: "Red moon · Dark clouds", skin: "bloodmoon",
    set: { candleOn: true, candleUp: "#ffb08a", candleDown: "#b0263a", candleLook: "nebula", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.2, scaleText: "#ffd1bd", scaleGlow: 0.15, scaleBg: "auto", dim: 0.15 } },
  // ----- Seasonal drops: offered in their month (see SEASONS), available all year under Seasonal -----
  { id: "xmas-spirit", name: "Christmas Spirit", sub: "Christmas Eve · Glass candles", skin: "christmas",
    set: { candleOn: true, candleUp: "#4ee59a", candleDown: "#ff4d5e", candleLook: "glass", candleGlow: 0.35, candlePreset: "custom", lineGlow: 0.3, scaleText: "#ffe6b3", scaleGlow: 0.2, scaleBg: "auto", dim: 0.12 } },
  { id: "cozy-lights", name: "Cozy Lights", sub: "Tree Lights · Neon candles", skin: "treelights",
    set: { candleOn: true, candleUp: "#6ff0b0", candleDown: "#ff5a6e", candleLook: "neon", candleGlow: 0.45, candlePreset: "custom", lineGlow: 0.3, scaleText: "#ffe2b8", scaleGlow: 0.25, scaleBg: "auto", dim: 0.1 } },
  { id: "silent-night", name: "Silent Night", sub: "Winter Village · Ice candles", skin: "village",
    set: { candleOn: true, candleUp: "#9fd8ff", candleDown: "#ff8f7a", candleLook: "ice", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.2, scaleText: "#dfe9ff", scaleGlow: 0.2, scaleBg: "auto", dim: 0.1 } },
  { id: "northern-noel", name: "Northern Noel", sub: "Northern lights · Glass candles", skin: "noel",
    set: { candleOn: true, candleUp: "#4dffc3", candleDown: "#ff6fa8", candleLook: "glass", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.3, scaleText: "#c9fff0", scaleGlow: 0.25, scaleBg: "auto", dim: 0.08 } },
  { id: "hallows-eve", name: "Hallows Eve", sub: "Hallows Night · Lava candles", skin: "hallows",
    set: { candleOn: true, candleUp: "#a77bff", candleDown: "#ff8a2a", candleLook: "lava", candleGlow: 0.35, candlePreset: "custom", lineGlow: 0.3, scaleText: "#ffd2a1", scaleGlow: 0.2, scaleBg: "auto", dim: 0.1 } },
  // ----- Wow: the showpiece wallpapers, each with one of the new candle looks (no wallpaper reused) -----
  { id: "horizon", name: "Event Horizon", sub: "Black hole · Glass candles", skin: "blackhole",
    set: { candleOn: true, candleUp: "#ffd27a", candleDown: "#8c6bff", candleLook: "glass", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.25, scaleText: "#ffe1a8", scaleGlow: 0.2, scaleBg: "auto", dim: 0.3 } },
  { id: "bloom", name: "Bloom", sub: "Fractal Bloom · Holo", skin: "julia",
    set: { candleOn: true, candleUp: "#ff9ecf", candleDown: "#6f63ff", candleLook: "holo", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.2, scaleText: "#ffc7e4", scaleGlow: 0.15, scaleBg: "auto", dim: 0.25 } },
  { id: "ink", name: "Ink", sub: "Ink Flow · Outline", skin: "inkflow",
    set: { candleOn: true, candleUp: "#e8e3d6", candleDown: "#7d8db0", candleLook: "outline", candleGlow: 0, candlePreset: "custom", lineGlow: 0, scaleText: "#e8e3d6", scaleGlow: 0, scaleBg: "auto", dim: 0.35 } },
  { id: "kaleido", name: "Mirror", sub: "Kaleidoscope · Fade", skin: "kaleido",
    set: { candleOn: true, candleUp: "#7df9ff", candleDown: "#ff5ec8", candleLook: "fade", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.25, scaleText: "#b8fbff", scaleGlow: 0.2, scaleBg: "auto", dim: 0.35 } },
  { id: "slick", name: "Liquid Chrome", sub: "Oil Slick · Chrome", skin: "oilslick",
    set: { candleOn: true, candleUp: "#b9f7ff", candleDown: "#c08bff", candleLook: "chrome", candleGlow: 0.1, candlePreset: "custom", lineGlow: 0.15, scaleText: "#d9faff", scaleGlow: 0.1, scaleBg: "glass", dim: 0.3 } },
  { id: "hypercube", name: "Hypercube", sub: "Tesseract · Neon", skin: "tesseract",
    set: { candleOn: true, candleUp: "#00e5ff", candleDown: "#ff3d7f", candleLook: "neon", candleGlow: 0.5, candlePreset: "custom", lineGlow: 0.4, scaleText: "#8ff4ff", scaleGlow: 0.35, scaleBg: "auto", dim: 0.35 } },
  { id: "helix", name: "Genome", sub: "Double Helix · 3D", skin: "helix",
    set: { candleOn: true, candleUp: "#39ff88", candleDown: "#ff4d6d", candleLook: "bevel", candleGlow: 0.15, candlePreset: "custom", lineGlow: 0.2, scaleText: "#a8ffc9", scaleGlow: 0.15, scaleBg: "auto", dim: 0.35 } },
  { id: "synapse", name: "Neural", sub: "Synapse · Ice", skin: "synapse",
    set: { candleOn: true, candleUp: "#c8f3ff", candleDown: "#7a8cff", candleLook: "ice", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.2, scaleText: "#d6f5ff", scaleGlow: 0.15, scaleBg: "auto", dim: 0.35 } },
  { id: "koi-pond", name: "Koi Pond", sub: "Koi Pond · 3D", skin: "koi",
    set: { candleOn: true, candleUp: "#6fe8c0", candleDown: "#ff7a3a", candleLook: "bevel", candleGlow: 0.1, candlePreset: "custom", lineGlow: 0.15, scaleText: "#d8fff0", scaleGlow: 0.1, scaleBg: "auto", dim: 0.3 } },
  { id: "rainy-night", name: "Rainy Night", sub: "Rain on Glass · Glass", skin: "rainglass",
    set: { candleOn: true, candleUp: "#8fdcff", candleDown: "#ffa26b", candleLook: "glass", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.2, scaleText: "#dceeff", scaleGlow: 0.15, scaleBg: "auto", dim: 0.3 } },
  { id: "ringed-giant", name: "Ringed Giant", sub: "Ringed Giant · Holo", skin: "ringed",
    set: { candleOn: true, candleUp: "#ffe0a3", candleDown: "#a48dff", candleLook: "holo", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.2, scaleText: "#ffe9c4", scaleGlow: 0.15, scaleBg: "auto", dim: 0.3 } },
  { id: "deep-blue", name: "Deep Blue", sub: "Deep Blue · Ice", skin: "deepblue",
    set: { candleOn: true, candleUp: "#7ff3ff", candleDown: "#ff7f9e", candleLook: "ice", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.25, scaleText: "#cdf7ff", scaleGlow: 0.2, scaleBg: "auto", dim: 0.25 } },
  { id: "cozy-room", name: "Cozy Room", sub: "Cozy Room · Soft", skin: "cozyroom",
    set: { candleOn: true, candleUp: "#ffd29a", candleDown: "#b49cff", candleLook: "fade", candleGlow: 0.2, candlePreset: "custom", lineGlow: 0.15, scaleText: "#ffe6c8", scaleGlow: 0.1, scaleBg: "auto", dim: 0.2 } },
  { id: "tokyo-night", name: "Tokyo Night", sub: "Tokyo Rooftop · Neon", skin: "tokyo",
    set: { candleOn: true, candleUp: "#2ee6ff", candleDown: "#ff3fa4", candleLook: "neon", candleGlow: 0.45, candlePreset: "custom", lineGlow: 0.35, scaleText: "#9ff3ff", scaleGlow: 0.3, scaleBg: "auto", dim: 0.25 } },
  { id: "trading-floor", name: "Trading Floor", sub: "Trading Floor · Glass", skin: "tradingfloor",
    set: { candleOn: true, candleUp: "#46f0aa", candleDown: "#ff6b78", candleLook: "glass", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.2, scaleText: "#bfe7ff", scaleGlow: 0.15, scaleBg: "auto", dim: 0.2 } },
  { id: "market-wall", name: "Market Wall", sub: "Market Wall · Solid", skin: "marketwall",
    set: { candleOn: true, candleUp: "#3ee6a0", candleDown: "#ff5f6d", candleLook: "solid", candleGlow: 0.15, candlePreset: "custom", lineGlow: 0.15, scaleText: "#d6e4f5", scaleGlow: 0.1, scaleBg: "auto", dim: 0.3 } },
  { id: "midnight-moon", name: "Midnight Moon", sub: "Midnight Moon · Ice", skin: "midnight",
    set: { candleOn: true, candleUp: "#9fd8ff", candleDown: "#b58cff", candleLook: "ice", candleGlow: 0.25, candlePreset: "custom", lineGlow: 0.2, scaleText: "#d9e4ff", scaleGlow: 0.15, scaleBg: "auto", dim: 0.15 } },
  { id: "twinkle-oled", name: "Twinkle", sub: "Twinkle · Solid · OLED", skin: "twinkle",
    set: { candleOn: true, candleUp: "#e8eefc", candleDown: "#6f7b96", candleLook: "solid", candleGlow: 0, candlePreset: "custom", lineGlow: 0.1, scaleText: "#c9d3e3", scaleGlow: 0, scaleBg: "auto", dim: 0 } },
  { id: "neon-night", name: "Neon Night", sub: "Cyber Grid · Tube", skin: "cybergrid",
    set: { candleOn: true, candleUp: "#fcee0a", candleDown: "#00f0ff", candleLook: "neon", candleGlow: 0.5, candlePreset: "cyberpunk", lineGlow: 0.5, scaleText: "#7df9ff", scaleGlow: 0.45, scaleBg: "auto", dim: 0.25 } },
  { id: "clean-focus", name: "Clean Focus", sub: "Slate · Mono", skin: "graphite",
    set: { candleOn: true, candleUp: "#ffffff", candleDown: "#5c5f6e", candleLook: "solid", candleGlow: 0, candlePreset: "mono", lineGlow: 0, scaleText: "", scaleGlow: 0, scaleBg: "auto", dim: 0.35 } },
  { id: "cosmic", name: "Cosmic", sub: "Spiral Galaxy · Rainbow", skin: "galaxy",
    set: { candleOn: true, candleUp: "#b388ff", candleDown: "#ff6ec7", candleLook: "prism", candleGlow: 0.35, candlePreset: "custom", lineGlow: 0.35, scaleText: "", scaleGlow: 0.3, scaleBg: "auto", dim: 0.2 } },
  { id: "inferno", name: "Inferno", sub: "Cinders · Magma", skin: "embers",
    set: { candleOn: true, candleUp: "#ffb300", candleDown: "#ff3d00", candleLook: "solid", candleGlow: 0.6, candlePreset: "lava", lineGlow: 0.3, scaleText: "#ffcc80", scaleGlow: 0.35, scaleBg: "auto", dim: 0.3 } },
  { id: "ocean-calm", name: "Ocean Calm", sub: "Tide · Glacier", skin: "ocean",
    set: { candleOn: true, candleUp: "#8be9ff", candleDown: "#3d5afe", candleLook: "solid", candleGlow: 0.2, candlePreset: "ice", lineGlow: 0.15, scaleText: "", scaleGlow: 0, scaleBg: "auto", dim: 0.3 } },
  { id: "flow", name: "Colour Flow", sub: "Aurora · Cycle", skin: "aurora",
    set: { candleOn: true, candleUp: "#00ffa3", candleDown: "#ff2e97", candleLook: "shift", shiftSpeed: 12, candleGlow: 0.3, candlePreset: "neon", lineGlow: 0.3, scaleText: "", scaleGlow: 0.2, scaleBg: "auto", dim: 0.3 } },
  // Nexus Match: dark Deep Field so Nexus "Priisma Neon" glass zones pop; candles + scale in the same cyan→magenta family.
  { id: "nexus-match", name: "Nexus Match", sub: "Deep Field · for Priisma Neon zones", skin: "starfield",
    set: { candleOn: true, candleUp: "#00eeff", candleDown: "#ff36bc", candleLook: "solid", candleGlow: 0.3, candlePreset: "custom", lineGlow: 0.2, scaleText: "#7ef0ff", scaleGlow: 0.3, scaleBg: "glass", dim: 0.5 } },
  // Monochrome: a live black background with crisp white (up) and dark (down) candles. Clean for streams.
  { id: "mono-black", name: "Blackout", sub: "Deep Field · White & Black", skin: "starfield",
    set: { candleOn: true, candleUp: "#ffffff", candleDown: "#2a2d36", candleLook: "solid", candleGlow: 0, candlePreset: "mono", lineGlow: 0.1, scaleText: "#ffffff", scaleGlow: 0, scaleBold: true, scaleBg: "auto", scaleLabels: false, dim: 0.55 } },
  // Terminal green on black — hacker/retro.
  { id: "terminal", name: "Terminal", sub: "Code Rain · Green", skin: "matrix",
    set: { candleOn: true, candleUp: "#00ff41", candleDown: "#0b6623", candleLook: "neon", candleGlow: 0.4, candlePreset: "matrix", lineGlow: 0.4, scaleText: "#00ff41", scaleGlow: 0.4, scaleFont: "mono", scaleBg: "auto", dim: 0.4 } },
  // Gold on deep navy — premium look.
  { id: "midas", name: "Midas", sub: "Abyssal Glow · Gold", skin: "deepsea",
    set: { candleOn: true, candleUp: "#ffd36b", candleDown: "#8a6d1a", candleLook: "solid", candleGlow: 0.35, candlePreset: "gold", lineGlow: 0.25, scaleText: "#ffd36b", scaleGlow: 0.3, scaleBg: "glass", dim: 0.35 } },
  // Soft pastel on falling petals — calm, pretty.
  { id: "blossom", name: "Blossom", sub: "Petal Drift · Pastel", skin: "sakura",
    set: { candleOn: true, candleUp: "#7cf7d4", candleDown: "#ff8fd8", candleLook: "solid", candleGlow: 0.2, candlePreset: "bubblegum", lineGlow: 0.15, scaleText: "", scaleGlow: 0, scaleBg: "glass", dim: 0.25 } },

  // ----- Calm, low-distraction "matching everything" looks. Each uses a DIFFERENT wallpaper (no skin reused across
  // these), solid candles, little/no glow, and the wallpaper dimmed back so the chart stays the focus. -----
  // Nightfall: muted teal up / dusty rose down over Night Drizzle. Quiet, rainy-city calm.
  { id: "nightfall", name: "Nightfall", sub: "Night Drizzle · Muted", skin: "rain",
    set: { candleOn: true, candleUp: "#5fb0a8", candleDown: "#cf8a8f", candleLook: "solid", candleGlow: 0, candlePreset: "custom", lineGlow: 0, scaleText: "#aebccb", scaleGlow: 0, scaleBg: "auto", dim: 0.5 } },
  // Daybreak: a LIGHT look — deep teal up / clay down on Snowfall. Clean and bright (like ChartSkins' light themes).
  { id: "daybreak", name: "Daybreak", sub: "Snowfall · Light", skin: "snow",
    set: { candleOn: true, candleUp: "#2f8f78", candleDown: "#c75d4d", candleLook: "solid", candleGlow: 0, candlePreset: "custom", lineGlow: 0, scaleText: "#39404c", scaleGlow: 0, scaleBg: "glass", dim: 0.12 } },
  // Sterling: soft platinum up / slate down on Stardust. Barely-there glow, elegant and understated.
  { id: "sterling", name: "Sterling", sub: "Stardust · Platinum", skin: "nebula",
    set: { candleOn: true, candleUp: "#d7dce4", candleDown: "#7b8392", candleLook: "solid", candleGlow: 0.08, candlePreset: "custom", lineGlow: 0.06, scaleText: "#d7dce4", scaleGlow: 0, scaleBg: "auto", dim: 0.5 } },
  // Firefly: warm amber up / deep moss down on Glowbugs. Cozy and gentle, low glow.
  { id: "firefly", name: "Firefly", sub: "Glowbugs · Amber", skin: "fireflies",
    set: { candleOn: true, candleUp: "#e8b864", candleDown: "#5f7a4e", candleLook: "solid", candleGlow: 0.15, candlePreset: "custom", lineGlow: 0.12, scaleText: "#e8cf9a", scaleGlow: 0.1, scaleBg: "glass", dim: 0.45 } },
  // Harbor: steel-blue up / slate-grey down on Thunderstorm, toned right down. Moody but calm, not flashy.
  { id: "harbor", name: "Harbor", sub: "Storm · Steel", skin: "storm",
    set: { candleOn: true, candleUp: "#7fa8c9", candleDown: "#566273", candleLook: "solid", candleGlow: 0.1, candlePreset: "custom", lineGlow: 0.08, scaleText: "#b9c6d6", scaleGlow: 0, scaleBg: "auto", dim: 0.5 } },
  // Dune: a loud skin (Retro Sun) deliberately made CALM — warm sand up / terracotta down, low glow. The surprise one.
  { id: "dune", name: "Dune", sub: "Retro Sun · Sand", skin: "synthwave",
    set: { candleOn: true, candleUp: "#e6c391", candleDown: "#c2734e", candleLook: "solid", candleGlow: 0.12, candlePreset: "custom", lineGlow: 0.1, scaleText: "#ecd6b0", scaleGlow: 0.1, scaleBg: "glass", dim: 0.5 } },

  // ----- Glow-in-the-dark / bold crowd-favourite looks. Luminous neon-tube candles, strong glow, dark wallpaper
  // pushed back so the candles light up the chart. Each on its own (previously-unused) wallpaper. -----
  // Glowstick: electric lime up / hot-magenta down, neon tube, max glow. Literal rave glow-in-the-dark.
  { id: "glowstick", name: "Glowstick", sub: "Plasma · Neon tube", skin: "plasma",
    set: { candleOn: true, candleUp: "#b6ff00", candleDown: "#ff1fa5", candleLook: "neon", candleGlow: 0.7, candlePreset: "custom", lineGlow: 0.55, scaleText: "#d6ff6b", scaleGlow: 0.5, scaleBg: "auto", dim: 0.45 } },
  // Blacklight: UV violet up / acid-cyan down — that blacklight-poster glow. Outside-the-box.
  { id: "blacklight", name: "Blacklight", sub: "Circuit · UV glow", skin: "circuit",
    set: { candleOn: true, candleUp: "#9b5cff", candleDown: "#2bf5d0", candleLook: "neon", candleGlow: 0.65, candlePreset: "custom", lineGlow: 0.5, scaleText: "#c6a3ff", scaleGlow: 0.5, scaleBg: "auto", dim: 0.5 } },
  // Vaporwave: pink + cyan on a neon skyline, glowing. The aesthetic people love.
  { id: "vaporwave", name: "Vaporwave", sub: "Neon City · Pink & Cyan", skin: "neoncity",
    set: { candleOn: true, candleUp: "#2ff0ff", candleDown: "#ff4fd0", candleLook: "neon", candleGlow: 0.6, candlePreset: "custom", lineGlow: 0.45, scaleText: "#8ff6ff", scaleGlow: 0.45, scaleBg: "auto", dim: 0.4 } },
  // Molten: glowing lava orange up / deep ember red down on Lava Lamp. Warm, radiant.
  { id: "molten", name: "Molten", sub: "Lava Lamp · Lava glow", skin: "lavalamp",
    set: { candleOn: true, candleUp: "#ffaa1d", candleDown: "#ff2b2b", candleLook: "neon", candleGlow: 0.65, candlePreset: "lava", lineGlow: 0.4, scaleText: "#ffcf7a", scaleGlow: 0.45, scaleBg: "auto", dim: 0.4 } },
  // Warp: icy white up / electric blue down streaking through Lightspeed, glowing. Fast and cool.
  { id: "warp", name: "Warp", sub: "Lightspeed · Ion glow", skin: "hyperspace",
    set: { candleOn: true, candleUp: "#eafcff", candleDown: "#2b8bff", candleLook: "neon", candleGlow: 0.6, candlePreset: "custom", lineGlow: 0.5, scaleText: "#bfe8ff", scaleGlow: 0.5, scaleBg: "auto", dim: 0.35 } },
  // Spectrum: candles cycle through the whole rainbow across the chart (prism), glowing, on Ticker Tape. Wild.
  { id: "spectrum", name: "Spectrum", sub: "Ticker Tape · Rainbow", skin: "tickertape",
    set: { candleOn: true, candleUp: "#00e5ff", candleDown: "#ff00a8", candleLook: "prism", candleGlow: 0.5, candlePreset: "custom", lineGlow: 0.4, scaleText: "", scaleGlow: 0.35, scaleBg: "glass", dim: 0.45 } },
];
let lookGroup = localStorage.getItem("lookGroup") || "All";
const skinQuery = () => ($("skinSearch") ? $("skinSearch").value.trim().toLowerCase() : "");
const matchQ = (...parts) => { const q = skinQuery(); return !q || parts.join(" ").toLowerCase().includes(q); };
// ---------- seasonal drops ----------
// In a season's month, a small card at the top of Skins offers its look (one tap, Undo as always); in "All", the
// seasonal look comes first. "Not now" hides the card until next year's season.
const SEASONS = [
  { id: "christmas", month: 11, look: "xmas-spirit", icon: "\u{1F384}", title: "Christmas is here", text: "Snow, twinkling lights and festive candles: the Christmas Spirit look. Four more Christmas looks are in Seasonal." },
  { id: "halloween", month: 9, look: "hallows-eve", icon: "\u{1F383}", title: "Happy Halloween", text: "A harvest moon, glowing pumpkins and lava candles: the Hallows Eve look." },
];
const currentSeason = () => SEASONS.find((x) => x.month === (window.__bdMonth ?? new Date().getMonth())) || null;
function renderSeason() {
  const bar = $("seasonBar"); if (!bar) return;
  const se = currentSeason(), q = se && QUICK_LOOKS.find((x) => x.id === se.look), key = se && `seasonSeen:${se.id}:${new Date().getFullYear()}`;
  if (!se || !q || localStorage.getItem(key) || cfg.skin === q.skin) { bar.hidden = true; return; }
  bar.hidden = false;
  bar.innerHTML = `<span class="ic">${se.icon}</span><div><b>${esc(se.title)}</b><small>${esc(se.text)}</small></div><div class="acts"><button class="primary keep" data-a="go">Try it</button><button class="link" data-a="no">Not now</button></div>`;
  bar.querySelector("[data-a=go]").onclick = () => { localStorage.setItem(key, "1"); applyWithUndo({ enabled: true, skin: q.skin, candleClosedLook: "", ...q.set }, `Applied ${q.name}. Happy holidays!`); };
  bar.querySelector("[data-a=no]").onclick = () => { localStorage.setItem(key, "1"); bar.hidden = true; };
}
function renderQuick() {
  const box = $("quickLooks"); if (!box) return;
  setTimeout(renderHero, 0); renderSeason();
  if ($("lookChips")) { $("lookChips").innerHTML = "";
    for (const g of LOOK_GROUPS) { const b = document.createElement("button"); b.className = "chip" + (g === lookGroup ? " on" : ""); b.textContent = g;
      b.onclick = () => { lookGroup = g; localStorage.setItem("lookGroup", g); renderQuick(); }; $("lookChips").appendChild(b); } }
  box.innerHTML = ""; quickPreviews = [];
  let shown = 0;
  const se = currentSeason(), list = se ? [...QUICK_LOOKS].sort((a, b) => (b.id === se.look) - (a.id === se.look)) : QUICK_LOOKS;   // in season: its look first
  for (const q of list) {
    const grp = groupOf(q);
    if (lookGroup !== "All" && grp !== lookGroup) continue;
    const sk0 = WickedSkins[q.skin]; if (!sk0) continue;
    if (!matchQ(q.name, q.sub, grp, sk0.name)) continue;
    shown++;
    const on = cfg.skin === q.skin && cfg.candleOn && cfg.candleUp === q.set.candleUp && cfg.candleLook === q.set.candleLook;
    const card = document.createElement("button");
    card.className = "card" + (on ? " on" : "");
    const cv = document.createElement("canvas"); cv.width = 160; cv.height = 64;
    const sk = makeSkin(q.skin, cv.getContext("2d"), q.wallOpts ? q : undefined); sk.resize(160, 64); quickPreviews.push(watchPreview({ skin: sk, t: 0 }, cv));   // a look with its own wallpaper settings shows them
    card.append(cv);
    card.insertAdjacentHTML("beforeend", `<div class="bars">${bars(q.set.candleUp, q.set.candleDown)}</div><div class="label"><span>${esc(q.name)}<small>${esc(q.sub)}</small></span></div>`);
    card.onclick = () => applyWithUndo($("keepBg") && $("keepBg").checked ? { enabled: true, candleClosedLook: "", ...q.set } : { enabled: true, skin: q.skin, candleClosedLook: "", ...q.set, ...(q.wallOpts ? { wallOpts: q.wallOpts } : {}) },
      $("keepBg") && $("keepBg").checked ? `Applied ${q.name} (kept your wallpaper).` : `Applied ${q.name}.`);
    box.appendChild(card);
  }
  updateEmpty(shown);
}
function updateEmpty(n) { if ($("skinEmpty")) $("skinEmpty").hidden = n > 0 || !skinQuery(); }
// Looks / Wallpapers switch + search (remembered)
let skinView = localStorage.getItem("skinView") || "looks";
function syncSkinView() {
  if (!$("skinView")) return;
  seg("skinView", [["looks", "Looks"], ["walls", "Wallpapers"], ["mine", "My uploads"], ["tune", "Adjust"]], () => skinView, (v) => { skinView = v; localStorage.setItem("skinView", v); syncSkinView(); });
  $("viewLooks").hidden = skinView !== "looks"; $("viewWalls").hidden = skinView !== "walls"; $("tab-media").hidden = skinView !== "mine"; $("viewTune").hidden = skinView !== "tune";
  if ($("skinSearch")) $("skinSearch").hidden = skinView === "mine" || skinView === "tune"; $("matchPickRow").hidden = skinView === "tune";
  if (skinView === "tune") { setTimeout(() => { wallPrev = null; try { drawWallPrev(); } catch {} }, 60); return; }
  syncMatchOnPick();
  if (skinView === "mine") return renderMedia();
  if (skinView === "looks") renderQuick(); else renderSkins();
}
// "Use your own wallpaper" links (Wallpapers view, Workshop): open Wallpaper › My uploads
document.querySelectorAll("[data-goto-mine]").forEach((b) => b.addEventListener("click", () => {
  skinView = "mine"; localStorage.setItem("skinView", "mine");
  const t = document.querySelector('#nav button[data-tab="skins"]'); if (t) t.click();
  syncSkinView();
}));
if ($("skinSearch")) $("skinSearch").oninput = () => (skinView === "looks" ? renderQuick() : renderSkins());
if ($("keepBg")) { $("keepBg").checked = localStorage.getItem("keepBg") === "1"; $("keepBg").onchange = (e) => localStorage.setItem("keepBg", e.target.checked ? "1" : "0"); }

// ---------- This wallpaper: its own settings + Recolour (Adjust tab), saved per wallpaper in cfg.skinOpts ----------
const RC_PRESETS = [["candles", "My candles", null], ["priism", "Priism", ["#19d3ff", "#2ef2b0", "#c6ff3d"]], ["ice", "Ice", ["#5ee7ff", "#4f7dff"]],
  ["ember", "Ember", ["#ff7a1a", "#ff2e63"]], ["violet", "Violet", ["#8f5bff", "#ff4fd8"]], ["gold", "Gold", ["#ffd166", "#ff9f43"]],
  ["emerald", "Emerald", ["#00e6a0", "#00b3ff"]], ["rose", "Rose", ["#ff8fb1", "#b48cff"]], ["mono", "Mono", ["#c9d3e3"]]];
// the wallpaper on the chart now: a built-in id, or "media:<id>" for your own upload (effects work on both)
const wallId = () => (WickedSkins[cfg.skin] ? cfg.skin : cfg.skin === "media" && cfg.mediaId ? "media:" + cfg.mediaId : "");
const wallMedia = (id) => (id && id.startsWith("media:") ? (cfg.media || []).find((m) => m.id === id.slice(6)) : null);
const wallName = (id) => (WickedSkins[id] ? WickedSkins[id].name : (wallMedia(id) || {}).name || "Your wallpaper");
// every effect (skins.js), the ones that swell with your music marked with a note
const FX_LIST = [["", "Off"], ...Object.entries(window.PriismEffects || {}).map(([k, e]) => [k, e.name + (e.music ? " \u266A" : "")])];
const wallSaved = (id) => ({ ...(((cfg.skinOpts || {})[id]) || {}) });
let wallPrev = null;
// change this wallpaper's settings. live = only the panel previews now (while dragging); the chart gets it on release
function setWall(patch, live) {
  const id = wallId(); if (!id) return;
  const cur = { ...wallSaved(id), ...patch };
  for (const k of Object.keys(cur)) if (cur[k] === undefined) delete cur[k];
  const all = { ...(cfg.skinOpts || {}) }; if (Object.keys(cur).length) all[id] = cur; else delete all[id];
  if (live) cfg.skinOpts = all; else set({ skinOpts: all });
  refreshWallPreviews(id);
}
function refreshWallPreviews(id) {
  for (const p of previews) if (p.id === id && p.cv) { try { p.skin = makeSkin(id, p.cv.getContext("2d")); p.skin.resize(p.cv.width, p.cv.height); p.skin.frame(p.t || 2, 0.016); } catch {} }
  heroP.key = ""; try { renderHero(); } catch {}
  wallPrev = null; drawWallPrev();
}
// the preview: the wallpaper (live, or your upload's picture) with its effect on top, like on the chart
function drawWallPrev() {
  const cv = $("wallOptsPrev"), id = wallId(); if (!cv || !id || !cv.offsetParent) return;
  if (wallPrev) return;
  try {
    const W = cv.width, H = cv.height, base = offscreenCanvas(W, H), fxc = offscreenCanvas(W, H), p = { cv, id, t: 2, base, fxc, skin: null, img: null, fx: null };
    if (WickedSkins[id]) { p.skin = makeSkin(id, base.getContext("2d")); p.skin.resize(W, H); }
    else { const m = wallMedia(id), src = m && (m.thumb || (m.type !== "video" && m.src)); if (src) { p.img = new Image(); p.img.src = src; } }
    const f = ((cfg.skinOpts || {})[id] || {}).fx;
    if (f && f.k) { p.fx = window.PriismMakeSkin("fx:" + f.k, fxc.getContext("2d"), f); p.fx.resize(W, H); }
    wallPrev = p; stepWallPrev(0.016);
  } catch { wallPrev = null; }
}
function offscreenCanvas(w, h) { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; }
function stepWallPrev(d) {
  const p = wallPrev; if (!p) return;
  const g = p.cv.getContext("2d"), W = p.cv.width, H = p.cv.height; p.t += d;
  if (p.skin) { p.skin.frame(p.t, d); g.drawImage(p.base, 0, 0); }
  else { g.fillStyle = "#000"; g.fillRect(0, 0, W, H); if (p.img && p.img.complete && p.img.naturalWidth) { const r = Math.max(W / p.img.naturalWidth, H / p.img.naturalHeight), iw = p.img.naturalWidth * r, ih = p.img.naturalHeight * r; g.drawImage(p.img, (W - iw) / 2, (H - ih) / 2, iw, ih); } }
  if (p.fx) { p.fx.frame(p.t, d); g.drawImage(p.fxc, 0, 0); }
}
function syncWallOpts() {
  const grp = $("wallOptsGrp"); if (!grp) return;
  const id = wallId(), def = id && WickedSkins[id];
  grp.hidden = !id; if (!id) return;
  $("wallOptsName").textContent = wallName(id);
  const saved = wallSaved(id), vals = def ? window.PriismSkinOpts.optsOf(def, saved) : {}, box = $("wallOptsRows"); box.innerHTML = "";
  // Effect: rain, a storm, snow... over this wallpaper (built-in or your own)
  const fx = saved.fx && saved.fx.k ? saved.fx : null;
  seg("fxK", FX_LIST, () => (fx ? fx.k : ""), (k) => { setWall({ fx: k ? { ...(fx || {}), k, amount: fx ? fx.amount || 1 : 1 } : undefined }); syncWallOpts(); });
  $("fxAmtRow").hidden = !fx; $("fxLightRow").hidden = !fx || fx.k !== "storm";
  if (fx) {
    const a = $("fxA"); a.value = fx.amount || 1; $("fxAOut").textContent = Math.round(a.value * 100) + "%";
    a.oninput = () => { $("fxAOut").textContent = Math.round(a.value * 100) + "%"; setWall({ fx: { ...fx, amount: +a.value } }, true); };
    a.onchange = () => setWall({ fx: { ...fx, amount: +a.value } });
    a.ondblclick = () => { a.value = 1; a.onchange(); syncWallOpts(); };
    seg("fxL", [[true, "On"], [false, "Off"]], () => fx.lightning !== false, (v) => { setWall({ fx: { ...fx, lightning: v } }); syncWallOpts(); });
  }
  $("rcRow").hidden = !def;                                   // Recolour: built-in wallpapers only (yours keep their own colours)
  if (!def) { $("rcBox").hidden = true; return; }
  for (const d of def.opts || []) {
    const row = document.createElement("div"); row.className = "row";
    if (d.type === "toggle") {
      row.innerHTML = `<span>${esc(d.label)}</span><div class="seg" id="wo_${d.k}"></div>`; box.appendChild(row);
      seg("wo_" + d.k, [[true, "On"], [false, "Off"]], () => !!window.PriismSkinOpts.optsOf(def, wallSaved(id))[d.k], (v) => setWall({ [d.k]: v }));
    } else {
      const pct = (v) => Math.round(v * 100) + "%";
      row.innerHTML = `<span>${esc(d.label)}</span><input type="range" min="${d.min}" max="${d.max}" step="${d.step}" /><output></output>`; box.appendChild(row);
      const inp = row.querySelector("input"), out = row.querySelector("output"); inp.value = vals[d.k]; out.textContent = pct(vals[d.k]);
      inp.oninput = () => { out.textContent = pct(+inp.value); setWall({ [d.k]: +inp.value }, true); };
      inp.onchange = () => setWall({ [d.k]: +inp.value });
      inp.ondblclick = () => { inp.value = d.def; out.textContent = pct(d.def); setWall({ [d.k]: d.def }); };
    }
  }
  // Recolour
  const rc = saved.rc && Array.isArray(saved.rc.c) ? saved.rc : null;
  seg("rcOn", [[false, "Off"], [true, "On"]], () => !!rc, (v) => {
    if (!v) { setWall({ rc: undefined }); return syncWallOpts(); }
    const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") ? cfg.candleUp : "#19d3ff", dn = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") ? cfg.candleDown : "#c6ff3d";
    setWall({ rc: { c: [up, dn], s: 0.85 } }); syncWallOpts(); });
  $("rcBox").hidden = !rc; if (!rc) return;
  const cols = rc.c.slice(0, 3);
  ["rc0", "rc1", "rc2"].forEach((k, i) => { const el = $(k); el.hidden = i >= cols.length; el.value = cols[i] || cols[cols.length - 1];
    el.oninput = () => { const c = cols.slice(); c[i] = el.value; setWall({ rc: { ...rc, c } }, true); };
    el.onchange = () => { const c = cols.slice(); c[i] = el.value; setWall({ rc: { ...rc, c } }); syncWallOpts(); }; });
  seg("rcN", [[1, "1"], [2, "2"], [3, "3"]], () => cols.length, (n) => {
    const c = cols.slice(0, n); while (c.length < n) c.push(c.length === 1 ? "#ff4fd8" : "#c6ff3d"); setWall({ rc: { ...rc, c } }); syncWallOpts(); });
  const sEl = $("rcS"); sEl.value = rc.s === undefined ? 0.85 : rc.s; $("rcSOut").textContent = Math.round(sEl.value * 100) + "%";
  sEl.oninput = () => { $("rcSOut").textContent = Math.round(sEl.value * 100) + "%"; setWall({ rc: { ...rc, s: +sEl.value } }, true); };
  sEl.onchange = () => setWall({ rc: { ...rc, s: +sEl.value } });
  const chips = $("rcPresets"); chips.innerHTML = "";
  for (const [pid, name, pc] of RC_PRESETS) {
    const c = pc || [cfg.candleUp || "#19d3ff", cfg.candleDown || "#c6ff3d"], b = document.createElement("button");
    b.className = "chip rcchip" + (JSON.stringify(c) === JSON.stringify(cols) ? " on" : "");
    b.innerHTML = `<i style="background:linear-gradient(90deg,${c.map(esc).join(",")}${c.length === 1 ? "," + esc(c[0]) : ""})"></i>${esc(name)}`;
    b.onclick = () => { setWall({ rc: { ...rc, c: c.slice() } }); syncWallOpts(); };
    chips.appendChild(b);
  }
}
if ($("wallOptsReset")) $("wallOptsReset").onclick = () => { const id = wallId(); if (!id) return;
  const all = { ...(cfg.skinOpts || {}) }, before = cfg.skinOpts; delete all[id];
  set({ skinOpts: all }); syncWallOpts(); refreshWallPreviews(id);
  toast(`${wallName(id)} is back to how it came.`, () => { set({ skinOpts: before }); syncWallOpts(); refreshWallPreviews(id); }); };
{ const t = document.querySelector('#nav button[data-tab="skins"]'); if (t) t.addEventListener("click", () => setTimeout(() => { wallPrev = null; drawWallPrev(); }, 60)); }
if ($("wallOptsGrp")) $("wallOptsGrp").addEventListener("toggle", () => { if ($("wallOptsGrp").open) setTimeout(() => { wallPrev = null; drawWallPrev(); }, 30); });
if ($("gotoWallOpts")) $("gotoWallOpts").onclick = () => {
  const t = document.querySelector('#nav button[data-tab="skins"]'); if (t) t.click();
  skinView = "tune"; localStorage.setItem("skinView", "tune"); syncSkinView();
  const g = $("wallOptsGrp"); if (g) { g.open = true; setTimeout(() => g.scrollIntoView({ block: "start", behavior: "smooth" }), 60); }
  syncWallOpts(); setTimeout(drawWallPrev, 80);
};

// ---------- remember which sections are open ----------
document.querySelectorAll("details.grp").forEach((d) => {
  const k = "grp:" + d.dataset.grp, v = localStorage.getItem(k);
  if (v !== null) d.open = v === "1";
  d.addEventListener("toggle", () => localStorage.setItem(k, d.open ? "1" : "0"));
});
// the candle switch lives inside a <summary>; don't let clicking it fold the section
document.querySelectorAll("summary .switch").forEach((sw) => sw.addEventListener("click", (e) => e.stopPropagation()));

// ---------- my media ----------
// Extension: files are stored as Blobs in IndexedDB (src/mediadb.js) and played by player/player.html,
// so big videos are fine. Desktop app (no chrome.runtime): falls back to data URLs, 50 MB each.
const EXT_MODE = !!(chrome.runtime && chrome.runtime.id);

// Desktop app only: a status card like ChartSkins — "Open TradingView with skins" / "Close". The app no longer
// pops a chart open by itself; you open it from here.
const DESK = window.wickedStore && window.wickedStore.tv;
function renderDesk(open) {
  if (!DESK) return;
  $("deskCard").hidden = false;
  $("deskTitle").textContent = open ? "TradingView is open — skins are on" : "TradingView is closed";
  $("deskHint").textContent = open ? `Your look is live on the chart. ${/Mac/.test(navigator.platform) ? "\u2318" : "Ctrl+"}T opens another chart tab, and ${/Mac/.test(navigator.platform) ? "\u2318," : "Ctrl+,"} brings you back here.` : "Your real TradingView, with your look. Sign in once in that window and your layouts, alerts and broker come with you.";
  const btn = $("deskBtn");
  btn.textContent = open ? "Show chart" : "Open TradingView";
  btn.onclick = () => (open ? DESK.open() : DESK.open());   // both focus/open; close is via the chart window
}
function deskCard() {
  if (!DESK) { const c = $("deskCard"); if (c) c.hidden = true; return; }
  DESK.state().then((s) => renderDesk(!!(s && s.open)));
  DESK.onState((s) => renderDesk(!!(s && s.open)));
}
const IS_TAB = new URLSearchParams(location.search).has("page");
const MAX_FILE_MB = EXT_MODE ? 2048 : MAX_MB;
const converting = {}; // id -> progress 0..1

// quality (resolution) + OLED tags for a wallpaper card
function wallTags(w, h, oled) {
  const q = window.PriismWallInfo && w && h ? PriismWallInfo.qualityOf(w, h) : "";
  return (q ? `<span class="wtag q" title="${w}\u00D7${h}">${q}</span>` : "") + (oled ? '<span class="wtag oled" title="Mostly true black and no bright part that stays still: easy on OLED screens">OLED</span>' : "");
}
// uploads from before labels existed: measure them once, quietly, one at a time
let measuring = false;
async function labelOldUploads() {
  if (measuring || !window.PriismWallInfo) return; const todo = cfg.media.filter((m) => !m.pending && m.w === undefined); if (!todo.length) return;
  measuring = true;
  try { for (const m of todo) {
    let q = null; try { const src = m.file && window.WickedMediaDB ? await WickedMediaDB.get(m.id) : m.src; if (src) q = await PriismWallInfo.measure(src, m.type); } catch {}
    const cur = cfg.media.find((x) => x.id === m.id); if (!cur) continue;
    Object.assign(cur, q ? { w: q.w, h: q.h, oled: q.oled } : { w: 0, h: 0 });
  } set({ media: cfg.media }); renderMedia(); } finally { measuring = false; }
}
function renderMedia() {
  const box = $("mediaCards"); box.innerHTML = "";
  setTimeout(labelOldUploads, 400);
  cfg.media.forEach((m) => {
    const card = document.createElement("div");
    card.className = "card" + (currentSrc() === "media:" + m.id ? " on" : "");
    if (m.thumb || m.pending) {
      const img = document.createElement("img");
      if (m.thumb) img.src = m.thumb; else img.alt = "";
      card.append(img);
    } else {
      const el = document.createElement(m.type === "video" ? "video" : "img");
      el.src = m.src;
      if (m.type === "video") Object.assign(el, { muted: true, loop: true, autoplay: true });
      card.append(el);
    }
    const badge = m.pending ? `<span class="live">${converting[m.id] !== undefined ? "CONVERTING " + Math.round(converting[m.id] * 100) + "%" : "WAITING TO CONVERT"}</span>`
      : m.type === "video" ? '<span class="live">● VIDEO</span>' : "";
    card.insertAdjacentHTML("beforeend", `${badge}${wallTags(m.w, m.h, m.oled)}<div class="label"><span>${esc(m.name)}</span><button class="x" title="Remove">${ICON_X}</button></div>`);
    card.onclick = (e) => {
      if (e.target.classList.contains("x")) {
        const media = cfg.media.filter((x) => x.id !== m.id);
        const wasActive = cfg.skin === "media" && cfg.mediaId === m.id;
        if (m.file && window.WickedMediaDB) WickedMediaDB.del(m.id).catch(() => {});
        const chartSkins = Object.fromEntries(Object.entries(cfg.chartSkins || {}).filter(([, v]) => v !== "media:" + m.id));
        set(wasActive ? { media, chartSkins, skin: "aurora", mediaId: null } : { media, chartSkins });
      } else if (!m.pending) return pickSource("media:" + m.id);
      renderMedia(); renderSkins(); syncTune();
    };
    box.appendChild(card);
  });
}

const IMAGE_EXT = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", jfif: "image/jpeg", pjpeg: "image/jpeg",
  gif: "image/gif", webp: "image/webp", avif: "image/avif", apng: "image/apng", bmp: "image/bmp",
  ico: "image/x-icon", svg: "image/svg+xml" };
// Any of these is accepted. Ones the browser can't play are converted to WebM on your computer.
const VIDEO_EXT = new Set(["mp4", "m4v", "mov", "qt", "webm", "mkv", "avi", "wmv", "asf", "flv", "f4v", "mpg", "mpeg",
  "mpe", "m2v", "ts", "mts", "m2ts", "3gp", "3g2", "ogv", "ogg", "hevc", "h264", "264", "h265", "265", "vob", "divx",
  "xvid", "rm", "rmvb", "mxf", "dv", "y4m", "gifv"]);
const UNSUPPORTED = { heic: "HEIC (iPhone photo): export it as JPG or PNG first",
  heif: "HEIF: export it as JPG or PNG first", tif: "TIFF: convert it to PNG first", tiff: "TIFF: convert it to PNG first",
  psd: "PSD: export it as PNG first" };

function classify(f) {
  const ext = (f.name.split(".").pop() || "").toLowerCase();
  if (UNSUPPORTED[ext]) return { err: UNSUPPORTED[ext] };
  if (f.type.startsWith("video/") || VIDEO_EXT.has(ext)) return { type: "video" };
  if (f.type.startsWith("image/") || IMAGE_EXT[ext]) return { type: "image", mime: f.type || IMAGE_EXT[ext] };
  return { err: "not an image or video file" };
}

// Load it for real; for videos also grab a small thumbnail frame.
function probe(type, url) {
  return new Promise((ok) => {
    const el = document.createElement(type === "video" ? "video" : "img");
    let t;
    const done = (v) => { clearTimeout(t); ok(v); };
    t = setTimeout(() => done(null), 10000);
    const thumbOf = (src, w, h) => {
      try {
        const c = document.createElement("canvas"); c.width = 192; c.height = 108;
        const g = c.getContext("2d"), s = Math.max(192 / w, 108 / h);
        g.drawImage(src, (192 - w * s) / 2, (108 - h * s) / 2, w * s, h * s);
        return c.toDataURL("image/jpeg", 0.7);
      } catch { return null; }
    };
    if (type === "video") {
      Object.assign(el, { muted: true, preload: "auto", playsInline: true });
      el.onloadeddata = () => { if (!el.videoWidth) return done(null); el.currentTime = Math.min(1, (el.duration || 2) / 3); };
      el.onseeked = () => done({ thumb: thumbOf(el, el.videoWidth, el.videoHeight) });
    } else el.onload = () => done(el.naturalWidth ? { thumb: thumbOf(el, el.naturalWidth, el.naturalHeight) } : null);
    el.onerror = () => done(null);
    el.src = url;
  });
}

const readAsDataURL = (f, mime) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(mime ? r.result.replace(/^data:[^;,]*/, "data:" + mime) : r.result);
  r.onerror = () => rej(r.error);
  r.readAsDataURL(f);
});

const hint = (t) => { $("mediaHint").textContent = t; };
const saveMedia = (media, extra = {}) => { set({ media, ...extra }); if (extra.skin === "media") autoMatchPick(); };

async function addFiles(files) {
  const problems = []; let added = 0, needConvert = 0, lastId = null;
  hint("Checking files…");
  for (const f of files) {
    const c = classify(f);
    if (c.err) { problems.push(`${f.name}: ${c.err}`); continue; }
    if (f.size > MAX_FILE_MB * 1024 * 1024) { problems.push(`${f.name}: over ${MAX_FILE_MB >= 1024 ? MAX_FILE_MB / 1024 + " GB" : MAX_FILE_MB + " MB"}`); continue; }
    const name = f.name;
    const id = uid();

    if (!EXT_MODE) { // desktop app fallback
      const src = await readAsDataURL(f, c.mime);
      const p = await probe(c.type, src);
      if (!p) { problems.push(`${f.name}: can't play in the desktop app yet (try MP4 H.264 or WebM)`); continue; }
      cfg.media = [...cfg.media, { id, name, type: c.type, src }]; lastId = id; added++;
      continue;
    }

    const url = URL.createObjectURL(f);
    const p = await probe(c.type, url);
    URL.revokeObjectURL(url);
    if (p) {
      await WickedMediaDB.put(id, f);
      let q = null; try { q = await window.PriismWallInfo.measure(f, c.type); } catch {}
      cfg.media = [...cfg.media, { id, name, type: c.type, file: true, thumb: p.thumb, size: f.size, ...(q ? { w: q.w, h: q.h, oled: q.oled } : {}) }];
      lastId = id; added++;
    } else if (c.type === "video") {
      await WickedMediaDB.put(id + ":src", f); // original kept until converted
      cfg.media = [...cfg.media, { id, name, type: "video", file: true, pending: true, origName: f.name, size: f.size }];
      needConvert++;
    } else problems.push(`${f.name}: this image's format can't be shown in the browser`);
  }
  saveMedia(cfg.media, lastId ? { skin: "media", mediaId: lastId } : {});
  renderMedia(); renderSkins();
  const parts = [];
  if (added) parts.push(`Added ${added} file${added > 1 ? "s" : ""}.`);
  if (needConvert) parts.push(`${needConvert} video${needConvert > 1 ? "s" : ""} need converting…`);
  if (problems.length) parts.push("Skipped " + problems.join(" · "));
  hint(parts.join(" ") || "Files stay on your computer.");
  if (needConvert) {
    if (IS_TAB) convertPending();
    else chrome.tabs.create({ url: chrome.runtime.getURL("popup/popup.html?page=media") }); // keep converting even if the popup closes
  }
}

// ---------- video converter (ffmpeg.wasm, runs locally, loaded only when needed) ----------
let ffmpegP;
function getFFmpeg() {
  if (ffmpegP) return ffmpegP;
  // ESM build: ffmpeg.wasm 0.12 runs in a module worker, which needs the ESM core.
  const base = chrome.runtime.getURL("vendor/ffmpeg/");
  ffmpegP = import(base + "esm/index.js").then(async ({ FFmpeg }) => {
    const ff = new FFmpeg();
    await ff.load({ coreURL: base + "ffmpeg-core.js", wasmURL: base + "ffmpeg-core.wasm" });
    return ff;
  }).catch((e) => { ffmpegP = null; throw e; });
  return ffmpegP;
}

let convertBusy = false;
async function convertPending() {
  if (convertBusy || !EXT_MODE) return;
  convertBusy = true;
  try {
    for (;;) {
      const m = cfg.media.find((x) => x.pending);
      if (!m) break;
      converting[m.id] = 0; renderMedia();
      hint(`Converting ${m.origName} to a format the browser can play… keep this tab open.`);
      try {
        const src = await WickedMediaDB.get(m.id + ":src");
        if (!src) throw new Error("original file missing");
        const ff = await getFFmpeg();
        const onProg = ({ progress }) => { converting[m.id] = Math.max(0, Math.min(1, progress || 0)); renderMedia(); };
        ff.on("progress", onProg);
        const inName = "in." + ((m.origName.split(".").pop() || "bin").toLowerCase());
        await ff.writeFile(inName, new Uint8Array(await src.arrayBuffer()));
        // Wallpaper-friendly: no audio, max 1920px wide (3840 = 4K with Ultra sharpness), 30 fps, fast VP8 WebM, first 3 minutes.
        const big = cfg.res === "ultra";
        const code = await ff.exec(["-i", inName, "-t", "180", "-an", "-vf", `scale='min(${big ? 3840 : 1920},iw)':-2,fps=30`,
          "-c:v", "libvpx", "-b:v", big ? "14M" : "4M", "-deadline", "realtime", "-cpu-used", "8", "-pix_fmt", "yuv420p", "out.webm"]);
        ff.off("progress", onProg);
        if (code !== 0) throw new Error("ffmpeg could not read this video");
        const data = await ff.readFile("out.webm");
        await ff.deleteFile(inName).catch(() => {}); await ff.deleteFile("out.webm").catch(() => {});
        const blob = new Blob([data.buffer], { type: "video/webm" });
        const url = URL.createObjectURL(blob); const p = await probe("video", url); URL.revokeObjectURL(url);
        if (!p) throw new Error("converted video still won't play");
        await WickedMediaDB.put(m.id, blob);
        await WickedMediaDB.del(m.id + ":src");
        delete converting[m.id];
        cfg.media = cfg.media.map((x) => (x.id === m.id ? { id: x.id, name: x.name, type: "video", file: true, thumb: p.thumb, size: blob.size, converted: true } : x));
        saveMedia(cfg.media, { skin: "media", mediaId: m.id });
        hint(`Converted ${m.origName}. It's on your chart now.`);
      } catch (e) {
        delete converting[m.id];
        await WickedMediaDB.del(m.id + ":src").catch(() => {});
        cfg.media = cfg.media.filter((x) => x.id !== m.id);
        saveMedia(cfg.media);
        hint(`Couldn't convert ${m.origName}: ${e.message || e}.`);
      }
      renderMedia(); renderSkins();
    }
  } finally { convertBusy = false; }
}

// In the popup, picking files opens the full-tab manager: Chrome can close the popup when a file
// dialog opens, and long conversions need a page that stays open.
$("addMedia").addEventListener("click", (e) => {
  if (EXT_MODE && !IS_TAB) { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL("popup/popup.html?page=media&pick=1") }); }
});
$("file").onchange = async (e) => { await addFiles([...e.target.files]); e.target.value = ""; };

// Drag & drop anywhere on the Uploads tab
const mediaTab = $("tab-media");
mediaTab.addEventListener("dragover", (e) => { e.preventDefault(); mediaTab.classList.add("drop"); });
mediaTab.addEventListener("dragleave", () => mediaTab.classList.remove("drop"));
mediaTab.addEventListener("drop", (e) => { e.preventDefault(); mediaTab.classList.remove("drop"); addFiles([...e.dataTransfer.files]); });

// ---------- workshop: community wallpapers ----------
let wsSort = "popular", wsPage = 0, wsItems = [], wsKind = localStorage.getItem("wsKind") || "looks";
const W = () => window.Workshop;

// The extension Workshop is browse + use only — no account. Sharing/liking/reporting and admin review all live
// on the website (login there), which avoids a sign-in wall and the free-tier email limits inside the popup.
const WS_SITE = () => (window.WORKSHOP_CONFIG && window.WORKSHOP_CONFIG.siteUrl) || "https://arcuto29.github.io/wicked-skins/";
function wsTabs() {
  seg("wsKind", [["looks", "Community looks"], ["walls", "Wallpapers"]], () => wsKind, (v) => { wsKind = v; localStorage.setItem("wsKind", v); wsSort = "popular"; wsLoad(true); });
  $("wsSubmit").hidden = wsKind !== "walls"; $("wsShareLook").hidden = wsKind !== "looks";
  const box = $("wsTabs"); box.innerHTML = "";
  for (const [k, label] of [["popular", wsKind === "looks" ? "Top" : "Popular"], ["new", "New"], ...(wsKind === "looks" ? [["mine", "Mine"]] : [])]) {
    const b = document.createElement("button"); b.className = "chip" + (k === wsSort ? " on" : ""); b.textContent = label;
    b.onclick = () => { wsSort = k; wsLoad(true); };
    box.appendChild(b);
  }
}
async function wsLoad(reset) {
  if (!W() || !W().configured) return;
  if (reset) { wsPage = 0; wsItems = []; }
  wsTabs();
  $("wsMsg").textContent = "Loading…";
  if (wsKind === "looks") return wsLoadLooks(reset);
  try {
    const rows = await W().list(wsSort, wsPage);
    wsItems = reset ? rows : [...wsItems, ...rows];
    $("wsMore").hidden = rows.length < 24;
    $("wsMsg").textContent = wsItems.length ? "" : "No approved wallpapers yet. Shared one? It shows here once it's approved: on the website, check \u201cMy uploads\u201d (moderators approve under Review).";
  } catch (e) { $("wsMsg").textContent = "Couldn't load the Workshop: " + e.message; }
  wsRender();
}
// ---------- community looks ----------
// A look is settings only (built-in wallpaper + styling), so the card preview is drawn live from the data itself.
const LOOK_SAFE = new Set(LOOK_KEYS);
const cleanLook = (data) => Object.fromEntries(Object.entries(data || {}).filter(([k, v]) => LOOK_SAFE.has(k) && (v === null || ["string", "number", "boolean"].includes(typeof v) || (typeof v === "object" && JSON.stringify(v).length < 2000))));
const myShared = () => { try { return JSON.parse(localStorage.getItem("myLooks") || "[]"); } catch { return []; } };
let wsLooks = [];
async function wsLoadLooks(reset) {
  try {
    let rows;
    if (wsSort === "mine") {
      // live = it's in the Workshop's approved list; otherwise it's still in review (or wasn't approved: the website
      // shows which, under Your shares)
      const mine = myShared().slice().reverse(), live = mine.length ? await W().listLooks("new", 0) : [];
      rows = mine.map((m) => live.find((r) => r.title === m.t && r.skin === m.s) || { id: "", title: m.t, skin: m.s, data: m.l || {}, uses: 0, mine: "review" });
      const nRev = rows.filter((r) => r.mine === "review").length;
      $("wsMsg").innerHTML = !rows.length ? "Looks you publish show here straight away. Publish one from <b>Saved</b> (or tap \u201cShare my current look\u201d)."
        : nRev ? `${nRev} still in review: everyone sees ${nRev === 1 ? "it" : "them"} once approved. <a href="${esc(WS_SITE() + "workshop.html#mine")}" target="_blank" rel="noopener">See status on the website</a>` : "";
    } else {
      rows = await W().listLooks(wsSort === "new" ? "new" : "top", wsPage);
      $("wsMsg").textContent = "";
    }
    wsLooks = reset ? rows : [...wsLooks, ...rows];
    $("wsMore").hidden = wsSort === "mine" || rows.length < 24;
    if (!wsLooks.length && wsSort !== "mine") $("wsMsg").textContent = "No community looks yet. Be the first: tap \u201cShare my current look\u201d.";
  } catch (e) {
    // the backend hasn't been set up for looks yet (WORKSHOP.md: re-run supabase/schema.sql): say so plainly
    const notReady = /looks|relation|schema cache|404|not find/i.test(String(e && e.message));
    $("wsMsg").textContent = notReady ? "Community looks are coming soon. Wallpapers already work: switch to Wallpapers above." : "Couldn't load community looks right now. Check your connection and try again.";
    if (notReady) $("wsShareLook").hidden = true;
  }
  wsRenderLooks();
}
function wsRenderLooks() {
  const box = $("wsCards"); box.innerHTML = ""; lookPreviews.length = 0;
  for (const it of wsLooks) {
    if (!WickedSkins[it.skin]) continue;
    const d = cleanLook(it.data), card = document.createElement("button"); card.className = "card wslook";
    const cv = document.createElement("canvas"); cv.width = 160; cv.height = 64;
    const sk = makeSkin(it.skin, cv.getContext("2d"), it.data); sk.resize(160, 64); lookPreviews.push(watchPreview({ skin: sk, t: 0 }, cv));
    card.append(cv);
    const up = d.candleUp || "#26a69a", down = d.candleDown || "#ef5350";
    card.insertAdjacentHTML("beforeend", `<div class="bars">${bars(up, down)}</div><span class="oncount${it.mine ? " review" : ""}">${it.mine ? "IN REVIEW" : it.uses + " ON"}</span>
      <div class="label"><span>${esc(it.title)}<small>${it.mine ? "yours" : "by " + esc(it.author || "trader")} · ${esc(WickedSkins[it.skin].name)}</small></span></div>`);
    const wallId = it.data && typeof it.data.wallId === "string" && /^[0-9a-f-]{36}$/i.test(it.data.wallId) ? it.data.wallId : "";
    if (wallId) W().getWallpaper(wallId).then((w) => { if (!w || !w.thumbUrl) return; const im = document.createElement("img"); im.alt = ""; im.loading = "lazy"; im.src = w.thumbUrl; im.className = "wslookimg"; cv.replaceWith(im);
      const sm = card.querySelector(".label small"); if (sm) sm.textContent = (it.mine ? "yours" : "by " + (it.author || "trader")) + " \u00B7 its own " + (w.kind === "video" ? "video" : "picture"); }).catch(() => {});
    card.onclick = () => {
      applyWithUndo({ ...d, enabled: true, ...(wallId ? {} : { skin: it.skin }) }, it.mine ? `Applied your look \u201c${it.title}\u201d.` : `Applied \u201c${it.title}\u201d by ${it.author || "trader"}.`);
      if (wallId) useLookWall(wallId, it.skin);
      if (!it.id) return;
      const used = new Set(JSON.parse(localStorage.getItem("usedLooks") || "[]"));
      if (!used.has(it.id)) { used.add(it.id); localStorage.setItem("usedLooks", JSON.stringify([...used].slice(-500))); W().countLookUse(it.id); }   // count each person once
    };
    box.appendChild(card);
  }
}
// A look that comes with its own Workshop wallpaper: use it (downloaded once into My uploads, then reused).
// The look's own colours stay: Auto-match is skipped for this pick.
let noAutoMatch = false;
async function useLookWall(wallId, fallbackSkin) {
  const have = (cfg.media || []).find((m) => m.wsId === wallId && !m.pending);
  if (have) { pickSource("media:" + have.id); return; }
  try {
    const w = await W().getWallpaper(wallId); if (!w) throw new Error("its wallpaper isn't in the Workshop any more");
    toast(`Downloading the look's wallpaper \u201c${w.title}\u201d\u2026`);
    const blob = await W().fetchFile(w), ext = (blob.type.split("/")[1] || "").replace("jpeg", "jpg");
    const before = new Set((cfg.media || []).map((m) => m.id));
    noAutoMatch = true;
    try { await addFiles([new File([blob], `${w.title}.${ext || (w.kind === "video" ? "webm" : "png")}`, { type: blob.type })]); } finally { noAutoMatch = false; }
    const added = (cfg.media || []).find((m) => !before.has(m.id));
    if (added) set({ media: cfg.media.map((m) => (m.id === added.id ? { ...m, wsId: wallId } : m)) });
    toast(`\u201c${w.title}\u201d is on your chart and in My uploads.`);
  } catch (e) { set({ skin: fallbackSkin && WickedSkins[fallbackSkin] ? fallbackSkin : "aurora" }); syncSkinView(); toast("Couldn't get the look's wallpaper (" + e.message + "), so it uses a built-in one."); }
}
// Publish: the website (you sign in there once; it remembers you) receives the look as a code and puts it in the
// Workshop: live straight away for the owner, after a check for everyone else. We keep a copy here, so
// Workshop › Mine shows it (with "In review") from the moment you publish, not only once it's approved.
function publishLook(name, src) {
  name = (name || "My look").slice(0, 40);
  const { skin, look } = lookPayload(src), code = makeLookCode(name, src);
  const a = myShared().filter((m) => !(m.t === name && m.s === skin));
  localStorage.setItem("myLooks", JSON.stringify([...a, { t: name, s: skin, l: look, at: Date.now() }].slice(-50)));
  const u = WS_SITE() + "workshop.html#look=" + encodeURIComponent(code);
  if (window.PriismNative && window.PriismNative.openUrl) window.PriismNative.openUrl(u);          // Android app
  else if (chrome.tabs && chrome.tabs.create) chrome.tabs.create({ url: u });                       // extension
  else window.open(u, "_blank");                                                                      // desktop app -> your browser
  if ((src ? src.skin : cfg.skin) === "media") toast("On the website, add the same file to the look (Choose the file), so everyone gets your wallpaper too.");
}
const shareLook = () => publishLook(($("loName") && $("loName").value.trim()) || (WickedSkins[cfg.skin] ? WickedSkins[cfg.skin].name : "My look"));
if ($("wsShareLook")) $("wsShareLook").onclick = shareLook;
if ($("loShare")) $("loShare").onclick = shareLook;
function wsRender() {
  if (wsKind === "looks") return wsRenderLooks();
  const box = $("wsCards"); box.innerHTML = "";
  for (const it of wsItems) {
    const card = document.createElement("div"); card.className = "card ws";
    const sub = `${it.likes} like${it.likes === 1 ? "" : "s"} · ${it.uses} use${it.uses === 1 ? "" : "s"}` + (it.credit ? ` · Credit: ${it.credit}` : "");
    card.innerHTML = `<img alt="" loading="lazy" src="${esc(it.thumbUrl || "")}"><span class="live">${it.kind === "video" ? "● VIDEO" : "IMAGE"}</span>${wallTags(it.width, it.height, it.oled)}
      <div class="label"><span>${esc(it.title)}<small>${esc(sub)}</small></span></div><div class="acts"></div>`;
    const acts = card.querySelector(".acts");
    const btn = (label, fn, cls) => { const b = document.createElement("button"); b.textContent = label; if (cls) b.className = cls; b.onclick = (e) => { e.stopPropagation(); fn(b); }; acts.appendChild(b); return b; };
    btn("Use", () => wsUse(it), "primary");
    card.onclick = () => wsUse(it);
    box.appendChild(card);
  }
}
// "Use": download into your Uploads and put it on the chart. No account needed.
async function wsUse(it) {
  toast(`Downloading “${it.title}”…`);
  try {
    const blob = await W().fetchFile(it);
    const ext = (blob.type.split("/")[1] || "").replace("jpeg", "jpg");
    await addFiles([new File([blob], `${it.title}.${ext || (it.kind === "video" ? "webm" : "png")}`, { type: blob.type })]);
    toast(`“${it.title}” is on your chart and in My uploads (Skins tab).`);
  } catch (e) { toast("Couldn't use it: " + e.message); }
}
$("wsMore").onclick = () => { wsPage++; wsLoad(false); };

function initWorkshop() {
  const on = !!(window.Workshop && Workshop.configured);
  $("wsOff").hidden = on; $("wsOn").hidden = !on;
  // Not connected to a backend yet (see WORKSHOP.md): hide the tab entirely instead of showing an empty one.
  document.querySelector('#nav [data-tab="workshop"]').hidden = !on;
  if (!on) return;
  $("wsSubmit").href = WS_SITE() + "workshop.html#submit";
  $("wsReportLink").href = WS_SITE() + "workshop.html";
  // Load fresh every time you open the tab (at most every 15 s), so something just approved shows up without
  // closing the panel; the desktop settings window stays open for hours.
  let loadedAt = 0;
  document.querySelector('#nav [data-tab="workshop"]').addEventListener("click", () => { if (Date.now() - loadedAt > 15000) { loadedAt = Date.now(); wsLoad(true); } });
}

// ---------- saved looks ----------
// a look = these settings + the wallpaper's own settings / Recolour (wallOpts: kept per wallpaper in skinOpts)
const wallOptsNow = () => (WickedSkins[cfg.skin] && (cfg.skinOpts || {})[cfg.skin]) || null;
const snapshot = () => Object.fromEntries(LOOK_KEYS.map((k) => [k, k === "wallOpts" ? wallOptsNow() : cfg[k]]));
const lookPreviews = [];
const sameLook = (lo) => lo.skin === cfg.skin && (lo.skin !== "media" || lo.mediaId === cfg.mediaId) &&
  ["candleOn", "candleUp", "candleDown", "candleLook", "lineGlow", "dim"].every((k) => JSON.stringify(lo.look[k]) === JSON.stringify(cfg[k]));
function describe(lo) {
  const sk = lo.skin === "media" ? (cfg.media.find((m) => m.id === lo.mediaId)?.name || "Upload") : (WickedSkins[lo.skin]?.name || lo.skin);
  const preset = lo.look.candleOn ? (CANDLE_PRESETS.find(([, , u, d]) => u === lo.look.candleUp && d === lo.look.candleDown)?.[1] || "Custom colours") : "Chart colours";
  const lm = window.__bdCandleLooks && window.__bdCandleLooks.META[lo.look.candleLook];
  const style = lo.look.candleLook && lo.look.candleLook !== "solid" && lm ? " · " + lm.name : "";
  return `${sk} · ${preset}${style}`;
}
function applyLook(lo) {
  const hasMedia = lo.skin !== "media" || cfg.media.some((m) => m.id === lo.mediaId);
  applyWithUndo({ ...lo.look, enabled: true, skin: hasMedia ? lo.skin : cfg.skin, mediaId: hasMedia ? lo.mediaId : cfg.mediaId },
    hasMedia ? `Applied “${lo.name}”.` : `Applied “${lo.name}” (its upload is gone, kept your current wallpaper).`);
  renderLoadouts();
}
function download(name, data) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  a.download = name; a.click();
}
// uploads (your own files) aren't put in shared files: size + they're yours
const exportable = (lo) => ({ name: lo.name, skin: lo.skin === "media" ? "aurora" : lo.skin, look: lo.look });

// ---------- Look Codes: a short, pasteable text version of a whole look (skin + candles + glow + scale + brackets).
// Share it in chat and a friend pastes it to get your exact vibe. Uploaded wallpapers can't travel in a code, so
// a code made on an upload falls back to a built-in skin; everything else (colours/glow/scale/brackets) carries. ----
const LOOK_CODE_PREFIX = "PRIISM1-";
// url-safe base64 of a UTF-8 JSON string
function b64urlEncode(str) {
  const bytes = new TextEncoder().encode(str); let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlDecode(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
  const bin = atob(s), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
// the parts of a look worth sending: its built-in wallpaper (an upload becomes Polar Lights) + only the settings that
// differ from the defaults. src = a saved look ({ skin, look }), or what's on your chart now.
function lookPayload(src = { skin: cfg.skin, look: cfg }) {
  const skin = src.skin === "media" || !WickedSkins[src.skin] ? "aurora" : src.skin, look = {};
  for (const k of LOOK_KEYS) if (src.look && k in src.look && JSON.stringify(src.look[k]) !== JSON.stringify(DEFAULTS[k])) look[k] = src.look[k];
  if (src.look === cfg && wallOptsNow()) look.wallOpts = wallOptsNow();            // the chart's current look: its wallpaper settings too
  if (skin !== src.skin) delete look.wallOpts;                                       // (your own upload: shared on another wallpaper)
  if (look.wallOpts == null) delete look.wallOpts;
  return { skin, look };
}
function makeLookCode(name, src) {
  const { skin, look } = lookPayload(src);
  // your own upload can't travel in a code: say which file it was, so the website can ask you to add it to the look
  const srcSkin = src ? src.skin : cfg.skin, mid = src ? src.mediaId : cfg.mediaId, m = srcSkin === "media" ? (cfg.media || []).find((x) => x.id === mid) : null;
  return LOOK_CODE_PREFIX + b64urlEncode(JSON.stringify({ v: 1, n: (name || "").slice(0, 40), s: skin, l: look, ...(m ? { m: { n: String(m.name || "").slice(0, 80), t: m.type === "video" ? "video" : "image" } } : {}) }));
}
const lookLink = (code) => WS_SITE() + "look.html#" + code;
function parseLookCode(code) {
  const m = String(code || "").match(/PRIISM1-[A-Za-z0-9_-]+/);    // a share link or a bare code
  const raw = m ? m[0] : "";
  if (!raw.startsWith(LOOK_CODE_PREFIX)) return null;
  try {
    const p = JSON.parse(b64urlDecode(raw.slice(LOOK_CODE_PREFIX.length)));
    if (!p || p.v !== 1 || !WickedSkins[p.s]) return null;
    const look = Object.fromEntries(LOOK_KEYS.filter((k) => p.l && k in p.l).map((k) => [k, p.l[k]]));
    return { name: typeof p.n === "string" ? p.n.slice(0, 40) : "", skin: p.s, look };
  } catch { return null; }
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; }
  catch { try { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); return true; } catch { return false; } }
}

function renderLoadouts() {
  const box = $("loCards"); box.innerHTML = ""; lookPreviews.length = 0;
  $("loEmpty").hidden = cfg.loadouts.length > 0;
  cfg.loadouts.forEach((lo) => {
    const card = document.createElement("div");
    card.className = "card look" + (sameLook(lo) ? " on" : "");
    // preview: the look's skin (live) or upload thumbnail, with its candle colours on top
    const media = lo.skin === "media" && cfg.media.find((m) => m.id === lo.mediaId);
    if (media && media.thumb) { const im = document.createElement("img"); im.src = media.thumb; card.append(im); }
    else {
      const cv = document.createElement("canvas"); cv.width = 160; cv.height = 64;
      const sk = makeSkin(WickedSkins[lo.skin] ? lo.skin : "aurora", cv.getContext("2d"), lo.look); sk.resize(160, 64);
      lookPreviews.push({ skin: sk, t: 0 }); card.append(cv);
    }
    if (lo.look.candleOn) card.insertAdjacentHTML("beforeend", `<div class="bars">${bars(lo.look.candleUp, lo.look.candleDown)}</div>`);
    card.insertAdjacentHTML("beforeend", `<div class="label"><span class="nm">${esc(lo.name)}<small>${esc(describe(lo))}</small></span></div>
      <div class="acts">
        <button data-a="update" title="Save your current setup into this look">Update</button>
        <button data-a="rename" title="Rename">Rename</button>
        <button data-a="publish" class="pub" title="Publish this look to the Workshop, so everyone can use it">Publish</button>
        <button data-a="del" class="x" title="Delete">${ICON_X}</button>
      </div>`);
    card.onclick = (e) => {
      const act = e.target.closest("[data-a]")?.dataset.a;
      if (!act) return applyLook(lo);
      e.stopPropagation();
      if (act === "del") {
        const before = cfg.loadouts;
        set({ loadouts: cfg.loadouts.filter((x) => x.id !== lo.id) }); renderLoadouts();
        toast(`Deleted “${lo.name}”.`, () => { set({ loadouts: before }); renderLoadouts(); });
      } else if (act === "update") {
        set({ loadouts: cfg.loadouts.map((x) => (x.id === lo.id ? { ...x, skin: cfg.skin, mediaId: cfg.mediaId, look: snapshot() } : x)) });
        renderLoadouts();
        // shared it in the Workshop before? offer to update that copy too (the website replaces it, no second card)
        if (myShared().some((m) => m.t === lo.name)) toast(`Updated \u201c${lo.name}\u201d. Update it in the Workshop too?`, () => { const n = cfg.loadouts.find((x) => x.id === lo.id); if (n) publishLook(n.name, { skin: n.skin, mediaId: n.mediaId, look: n.look }); }, "Update in Workshop");
        else hintToast(`Updated “${lo.name}” with your current setup.`);
      } else if (act === "rename") {
        const span = card.querySelector(".nm");
        span.innerHTML = `<input class="field" maxlength="40" value="${esc(lo.name)}" />`;
        const inp = span.querySelector("input"); inp.focus(); inp.select();
        const done = () => { const v = inp.value.trim(); if (v && v !== lo.name) set({ loadouts: cfg.loadouts.map((x) => (x.id === lo.id ? { ...x, name: v } : x)) }); renderLoadouts(); };
        inp.onkeydown = (k) => { if (k.key === "Enter") done(); if (k.key === "Escape") renderLoadouts(); };
        inp.onblur = done; inp.onclick = (k) => k.stopPropagation();
      } else if (act === "publish") {
        publishLook(lo.name, { skin: lo.skin, mediaId: lo.mediaId, look: lo.look });
      }
    };
    box.appendChild(card);
  });
}
const hintToast = (msg) => toast(msg);
const saveLook = () => {
  const name = $("loName").value.trim() || `Look ${cfg.loadouts.length + 1}`;
  set({ loadouts: [{ id: uid(), name, skin: cfg.skin, mediaId: cfg.mediaId, look: snapshot() }, ...cfg.loadouts] });
  $("loName").value = ""; renderLoadouts(); hintToast(`Saved “${name}”.`);
};
$("loSave").onclick = saveLook;
$("loName").onkeydown = (e) => { if (e.key === "Enter") saveLook(); };
$("loExport").onclick = () => download("priism-skins-looks.json", cfg.loadouts.map(exportable));
$("loImport").onchange = async (e) => {
  try {
    const arr = JSON.parse(await e.target.files[0].text());
    const clean = (Array.isArray(arr) ? arr : [arr]).filter((x) => x && typeof x.name === "string" && WickedSkins[x.skin]).map((x) => ({
      id: uid(), name: x.name.slice(0, 40), skin: x.skin, mediaId: null,
      look: Object.fromEntries(LOOK_KEYS.filter((k) => x.look && k in x.look).map((k) => [k, x.look[k]])),
    }));
    if (!clean.length) throw 0;
    set({ loadouts: [...clean, ...cfg.loadouts] }); renderLoadouts(); hintToast(`Imported ${clean.length} look${clean.length > 1 ? "s" : ""}.`);
  } catch { hintToast("That file isn't a saved-looks file."); }
  e.target.value = "";
};

// ---------- look codes (copy / paste a short code of the whole look) ----------
const codeMsg = (t, ok) => { const el = $("codeMsg"); if (!el) return; el.style.display = ""; el.textContent = t; el.style.color = ok === false ? "#ff8a8a" : ""; };
if ($("codeCopy")) $("codeCopy").onclick = async () => {
  const link = lookLink(makeLookCode(($("loName") && $("loName").value.trim()) || ""));
  const done = await copyText(link);
  if ($("codeInput")) $("codeInput").value = link;
  codeMsg(done ? "Link copied! Paste it anywhere to share your look." : "Couldn't copy: select the link above and copy it.", done);
};
if ($("codeApply")) {
  const apply = () => {
    const parsed = parseLookCode($("codeInput").value);
    if (!parsed) return codeMsg("That isn't a Priism share link or look code.", false);
    applyWithUndo({ ...parsed.look, enabled: true, skin: parsed.skin },
      parsed.name ? `Applied look code “${parsed.name}”.` : "Applied look code.");
    codeMsg("Applied! (Use the Undo in the toast to revert.)", true);
  };
  $("codeApply").onclick = apply;
  $("codeInput").onkeydown = (e) => { if (e.key === "Enter") apply(); };
}

// ---------- snapshot (capture the chart with skin + watermark as a shareable PNG) ----------
if ($("snapBtn")) $("snapBtn").onclick = async () => {
  const msg = $("snapMsg"), prev = $("snapPreview"), img = $("snapImg");
  const show = (t, ok) => { msg.style.display = ""; msg.textContent = t; msg.style.color = ok === false ? "#ff8a8a" : ""; };
  if (DESK && DESK.action) {
    const r = await DESK.action("snapshot");
    return r && r.ok !== false ? show("Snapshot taken in your chart window. Choose where to save it.", true) : show((r && r.reason) || "Open your chart first (Open TradingView with skins).", false);
  }
  if (!EXT_MODE || IS_TAB) return show("Open this on a TradingView chart tab to capture.", false);
  show("Capturing…"); prev.style.display = "none";
  const r = await tabMsgAnyFrame({ ws: "snapshot" });
  if (!r) return show("Couldn't reach the chart. Open your TradingView chart, make sure Priism Skins is on here, then try again.", false);
  if (!r.ok) return show(r.reason || "Couldn't capture the chart.", false);
  img.src = r.url; prev.href = r.url;
  const sym = (await tabMsg({ ws: "symbol" }).catch(() => null)) || {};
  prev.download = `priism-${(sym.symbol || "chart").replace(/[^\w-]+/g, "")}.png`;
  prev.style.display = "";
  if ($("snapOut")) { $("snapOut").hidden = false; $("snapOut").textContent = `PNG · lossless · ${r.w}×${r.h} · ${((r.url.length - r.url.indexOf(",") - 1) * 0.75 / 1048576).toFixed(1)} MB`; }
  show(r.mediaMissed
    ? "Done — click the image to save. (Your uploaded wallpaper couldn't be included because it renders in a protected frame; the chart and watermark are captured.)"
    : "Done — click the image to save or drag it out to share.", true);
};

// ---------- live clip (short animated WebM of the chart + moving wallpaper) ----------
let clipSecs = 10;
// Chart only = we redraw the chart + effects ourselves (fast, no prompts). Whole screen = Chrome's screen share,
// which records exactly what you see (every effect, uploaded wallpapers, the lot) after you pick what to share.
const CLIP_HINTS = {
  chart: "Records an animated clip (MP4 where your browser can, else WebM) of your chart with the live wallpaper and effects moving, from 2 seconds up to 2 minutes. Click Record, then close this panel if you like: it downloads by itself when it ends. A badge on the chart shows the countdown; click it to stop and save early. Keep the chart tab visible. An uploaded wallpaper can't be read this way; use Whole screen for that.",
  screen: "Records exactly what you see, so every effect and any uploaded wallpaper is in it. After you click Record, a card appears on your chart: click \u201cChoose what to record\u201d and pick Entire Screen (or a window / this tab) in Chrome's box. It records for the length below, then downloads by itself. Stop early with Chrome's \u201cStop sharing\u201d button.",
};
const AUDIO_HINT = {
  mic: "Your voice: Chrome asks once to use your microphone on tradingview.com.",
  computer: "Computer sound (music, videos, alerts): Chrome asks what to share when you record. On Windows pick Entire screen and tick \u201cShare system audio\u201d. On a Mac Chrome can only take a tab's sound, so pick the tab that's playing and keep \u201cShare tab audio\u201d on.",
  both: "Your voice and the computer's sound, mixed. Chrome asks once for the microphone, then what to share: on Windows tick \u201cShare system audio\u201d; on a Mac pick the tab that's playing.",
};
const syncClipMode = () => {
  if ($("clipAudio")) { seg("clipAudio", [["none", "Off"], ["mic", "Voice"], ["computer", "Computer"], ["both", "Both"]], () => cfg.clipAudio || "none", (v) => { set({ clipAudio: v }); syncClipMode(); });
    $("clipAudioHint").hidden = !AUDIO_HINT[cfg.clipAudio]; $("clipAudioHint").textContent = AUDIO_HINT[cfg.clipAudio] || ""; }
  renderPresets();
  if ($("clipEdit")) seg("clipEdit", [[true, "Crop & trim first"], [false, "Download right away"]], () => cfg.clipEdit !== false, (v) => set({ clipEdit: v }));
  seg("clipFps", [[30, "30 fps"], [60, "60 fps"]], () => (+cfg.clipFps === 60 ? 60 : 30), (v) => { set({ clipFps: v }); syncClipMode(); });
  seg("clipMode", [["chart", "Chart only"], ["screen", "Whole screen"]], () => cfg.clipMode || "chart", (v) => { set({ clipMode: v }); syncClipMode(); });
  if ($("clipHint")) $("clipHint").textContent = CLIP_HINTS[cfg.clipMode === "screen" ? "screen" : "chart"];
  if ($("clipBtnTxt")) $("clipBtnTxt").textContent = cfg.clipMode === "screen" ? "Start screen recording" : "Start recording";
  syncReady();
};
// ---------- Capture Studio (the Capture tab): Screenshot | Record, Quality as cards, what you'll really get ----------
// Quality (clipQuality) is the one quality setting; each card picks it with its usual frame rate (Frame rate, under
// Advanced, can still change that). The sizes come from the chart itself (capinfo): never upscaled, so on a 1080p
// screen High and Ultra record 1080p, and the cards say so.
const PRESETS = [["balanced", "Balanced", "1080p", 30], ["high", "High quality", "1440p", 60], ["ultra", "Ultra", "4K", 60], ["small", "Small file", "720p · Discord", 30]];
let capInfo = null;
const csMode = () => localStorage.getItem("csMode") === "rec" ? "rec" : "shot";
function syncCsMode() { if (!$("csMode")) return; const m = csMode(); $("csMode").querySelectorAll("button").forEach((b) => { b.classList.toggle("on", b.dataset.m === m); b.setAttribute("aria-selected", b.dataset.m === m); });
  $("csShot").hidden = m !== "shot"; $("csRec").hidden = m !== "rec"; }
if ($("csMode")) { $("csMode").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; localStorage.setItem("csMode", b.dataset.m); syncCsMode(); }; syncCsMode(); }
function renderPresets() {
  const box = $("clipPresets"); if (!box) return; box.innerHTML = "";
  const cur = cfg.clipQuality || "balanced";
  for (const [q, name, target, fps] of PRESETS) {
    const c = capInfo && capInfo.clips && capInfo.clips[q], fpsNow = q === cur ? (+cfg.clipFps === 60 ? 60 : 30) : fps;
    const long = c ? Math.max(c.w, c.h) : 0, full = { balanced: 1920, high: 2560, ultra: 3840, small: 1280 }[q];
    const capped = c && long < full * 0.85;   // the screen has far fewer pixels than the preset: it records what the screen has
    const b = document.createElement("button"); b.type = "button"; b.className = "cs-card" + (q === cur ? " on" : "") + (capped && q !== "small" ? " capped" : "");
    b.setAttribute("role", "radio"); b.setAttribute("aria-checked", q === cur);
    b.innerHTML = `<b>${name}</b><span>${target} · ${fpsNow} fps</span><small>${c ? (capped && q !== "small" ? `${c.w}×${c.h} ${capInfo.chartDensity < capInfo.screenDpr - 0.01 ? "(the chart’s own detail)" : "on this screen"}` : `${c.w}×${c.h}`) : "&nbsp;"}</small>`;
    if (c && !c.mime) { b.disabled = true; b.title = "This browser can't record this size"; }
    else if (capped && q !== "small") b.title = capInfo && capInfo.chartDensity < capInfo.screenDpr - 0.01
      ? `This chart draws at ${capInfo.chartDensity}\u00D7, so it's recorded at its real detail (${c.w}\u00D7${c.h}): never upscaled.`
      : "This screen has fewer pixels than this preset: it records your screen's own pixels, never upscaled. True 4K needs a 4K screen (or a Retina screen at 2x).";
    b.onclick = () => { set({ clipQuality: q, clipFps: fps }); syncClipMode(); };
    box.appendChild(b);
  }
}
function syncReady() {
  const el = $("clipReady"); if (!el) return;
  if (cfg.clipMode === "screen") { el.textContent = "Ready · whole screen · Chrome asks what to share"; return; }
  const c = capInfo && capInfo.clips && capInfo.clips[cfg.clipQuality || "balanced"];
  el.textContent = c && c.label ? `Ready · ${c.label.replace(/ · \d+ fps/, ` · ${+cfg.clipFps === 60 ? 60 : 30} fps`)}` : capInfo && !capInfo.canRecord ? "This browser can't record clips" : "Open your chart to record";
  if ($("snapSpec")) $("snapSpec").textContent = capInfo && capInfo.snap ? `PNG · lossless · ${capInfo.snap[0]}×${capInfo.snap[1]}${capInfo.dpr > 1 ? ` (${+capInfo.dpr.toFixed(2)}×, your screen's native pixels)` : " (native pixels)"}` : "PNG · lossless · your screen's native pixels";
}
async function loadCapInfo() {
  if (!EXT_MODE || IS_TAB || !$("clipPresets")) return;
  try { const r = await tabMsgAnyFrame({ ws: "capinfo", fps: +cfg.clipFps === 60 ? 60 : 30 }); if (r && r.ok) capInfo = r; } catch {}
  renderPresets(); syncReady();
}
function syncKeyHints() { if ($("recKeyHint")) $("recKeyHint").textContent = cfg.recordKey ? keyLabel(cfg.recordKey) : ""; if ($("snapKeyHint")) $("snapKeyHint").textContent = cfg.snapKey ? keyLabel(cfg.snapKey) : ""; }
// "MP4 · H.264 · 2560×1440 · 60 fps · 10.0 s · 12.4 MB" (what the file really is: as recorded, counted on the chart)
const clipOut = (r) => { const fmt = /mp4/.test(r.mime || "") ? "MP4" : "WebM", codec = /vp9/.test(r.mime || "") ? "VP9" : /av01/.test(r.mime || "") ? "AV1" : /vp8/.test(r.mime || "") ? "VP8" : /mp4/.test(r.mime || "") ? "H.264" : "";
  return [fmt, codec, r.w && `${r.w}×${r.h}`, r.fps && `${r.fps} fps`, r.secs && `${(+r.secs).toFixed(1)} s`, r.bytes && `${(r.bytes / 1048576).toFixed(1)} MB`].filter(Boolean).join(" · "); };
if ($("clipMode")) syncClipMode();
setTimeout(() => { syncKeyHints(); loadCapInfo(); }, 0);   // (after the whole panel has loaded; again whenever the Capture tab is opened: the chart may have been resized)
document.querySelector('#nav [data-tab="capture"]') && document.querySelector('#nav [data-tab="capture"]').addEventListener("click", () => { syncKeyHints(); loadCapInfo(); });
if ($("clipLen")) seg("clipLen", [[5, "5s"], [10, "10s"], [30, "30s"], [60, "1 min"], [120, "2 min"]], () => clipSecs, (v) => { clipSecs = v; set({ clipLen: v }); if ($("clipCustom")) $("clipCustom").value = ""; });
if ($("clipCustom")) $("clipCustom").addEventListener("input", () => { const c = Math.round(+$("clipCustom").value); if (c >= 2) set({ clipLen: Math.min(120, c) }); });
// a custom length (2-120 s) overrides the preset
const clipLength = () => { const c = Math.round(+($("clipCustom") && $("clipCustom").value)); return c >= 2 ? Math.min(120, c) : clipSecs; };
if ($("clipBtn")) $("clipBtn").onclick = async () => {
  const msg = $("clipMsg"), prev = $("clipPreview"), vid = $("clipVid"), btn = $("clipBtn");
  const show = (t, ok) => { msg.style.display = ""; msg.textContent = t; msg.style.color = ok === false ? "#ff8a8a" : ""; };
  const secs = clipLength();
  if (DESK && DESK.action) {                                   // desktop app: record in the chart window
    set({ clipLen: secs });
    const r = await DESK.action("record");
    if (!r || r.ok === false) return show((r && r.reason) || "Open your chart first (Open TradingView with skins), then record.", false);
    return show(r.stopped ? "Stopped. Your clip is saving." : `Recording on your chart window for ${secs}s. It saves by itself when it ends.`, true);
  }
  if (!EXT_MODE || IS_TAB) return show("Open this on a TradingView chart tab to record.", false);
  if (cfg.clipMode !== "screen" && (cfg.clipAudio === "computer" || cfg.clipAudio === "both")) {
    const r1 = await tabMsgAnyFrame({ ws: "clip", seconds: secs, fps: +cfg.clipFps === 60 ? 60 : 30 });
    if (!r1) return show("Couldn't reach the chart. Open your TradingView chart, make sure Priism Skins is on here, then try again.", false);
    if (!r1.ok) return show(r1.reason || "Couldn't start the recording.", false);
    return show(`Now click \u201cChoose sound\u201d on your chart and pick what to share. It records ${secs}s, then downloads by itself.`, true);
  }
  if (cfg.clipMode === "screen") {
    const r0 = await tabMsgAnyFrame({ ws: "clip", seconds: secs, mode: "screen", fps: +cfg.clipFps === 60 ? 60 : 30 });
    if (!r0) return show("Couldn't reach the chart. Open your TradingView chart, make sure Priism Skins is on here, then try again.", false);
    if (!r0.ok) return show(r0.reason || "Couldn't start the screen recording.", false);
    return show(`Now click \u201cChoose what to record\u201d on your chart and pick what to share. It records ${secs}s, then downloads by itself.`, true);
  }
  prev.style.display = "none"; btn.disabled = true;
  let left = secs; show(`Recording ${secs}s. You can close this panel; the clip downloads by itself when it ends.`);
  const tick = setInterval(() => { left--; }, 1000);
  const r = await tabMsgAnyFrame({ ws: "clip", seconds: secs, fps: +cfg.clipFps === 60 ? 60 : 30 });
  clearInterval(tick); btn.disabled = false;
  if (!r) return show("Couldn't reach the chart. Open your TradingView chart, make sure Priism Skins is on here, then try again.", false);
  if (!r.ok) return show(r.reason || "Couldn't record the clip.", false);
  if (r.saved) {
    return show(`Saved ${r.name} to your downloads · ${clipOut(r)}${r.lowered ? " (lowered to 30 fps to keep trading smooth)" : ""}.` + (r.mediaMissed ? " (Your uploaded wallpaper renders in a protected frame, so it isn't in the clip; the chart + watermark are.)" : ""), true);
  }
  vid.src = r.url; prev.href = r.url;
  const sym = (await tabMsg({ ws: "symbol" }).catch(() => null)) || {};
  prev.download = `priism-${(sym.symbol || "chart").replace(/[^\w-]+/g, "")}.${/mp4/.test(r.mime || "") ? "mp4" : "webm"}`;
  prev.style.display = "";
  const kb = Math.round((r.bytes || 0) / 1024);
  show(r.mediaMissed
    ? `Done (${kb} KB) — click to save. (Your uploaded wallpaper renders in a protected frame, so it's not in the clip; the chart + watermark are.)`
    : `Done (${kb} KB) — click the clip to save, or drag it out to share.`, true);
};

// ---------- daily goal & limit + trade journal (the data lives in chrome.storage.local; the page writes it) ----------
const dayKeyP = () => { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
const fmtMoneyP = (v, u) => `${v >= 0 ? "+" : "\u2212"}${u && u.length === 1 ? u : ""}${Math.abs(v).toFixed(2)}${u && u.length > 1 ? " " + u : ""}`;
const fmtDurP = (s) => (s < 90 ? s + "s" : s < 5400 ? Math.round(s / 60) + "m" : (s / 3600).toFixed(1) + "h");
const storeGet = (defaults) => new Promise((res) => { try { chrome.storage.local.get(defaults, res); } catch { res(defaults); } });
// Trading sounds (src/sounds.js): picking Soft or Loud plays the sound once so you know what you'll hear.
const SOUND_LEVELS = [["off", "Off"], ["soft", "Soft"], ["loud", "Loud"]];
const preview = (kind, level) => { try { window.PriismSounds && window.PriismSounds.play(kind, level); } catch {} };
if ($("goalGuard")) $("goalGuard").onchange = (e) => set({ goalGuard: e.target.checked, goalOn: cfg.goalOn || e.target.checked });
function syncGoal() {
  if (!$("goalOn")) return;
  $("goalOn").checked = !!cfg.goalOn;
  if (document.activeElement !== $("goalTarget")) $("goalTarget").value = cfg.goalTarget;
  if (document.activeElement !== $("goalLimit")) $("goalLimit").value = cfg.goalLimit;
  seg("goalPos", [["bl", "Bottom left"], ["tl", "Top left"], ["tc", "Top"]], () => cfg.goalPos || "bl", (v) => set({ goalPos: v }));
  if ($("goalGuard")) $("goalGuard").checked = !!cfg.goalGuard;
  seg("goalSound", SOUND_LEVELS, () => cfg.goalSound || "off", (v) => { set({ goalSound: v }); preview("goal", v); });
  storeGet({ dayPnl: null }).then((s) => {
    const d = s.dayPnl && s.dayPnl.date === dayKeyP() ? s.dayPnl : null;
    $("goalToday").textContent = d ? `${fmtMoneyP(d.realized, d.unit)} \u00B7 ${d.trades} closed trade${d.trades === 1 ? "" : "s"}` : "no closed trades yet";
  });
}
if ($("goalOn")) {
  $("goalOn").onchange = (e) => set({ goalOn: e.target.checked });
  $("goalTarget").oninput = (e) => set({ goalTarget: Math.max(0, +e.target.value || 0) });
  $("goalLimit").oninput = (e) => set({ goalLimit: Math.max(0, +e.target.value || 0) });
  $("goalReset").onclick = () => { try { chrome.storage.local.remove("dayPnl", syncGoal); } catch {} hintToast("Today's total was reset."); };
}
function renderJournal() {
  const box = $("journalList"); if (!box) return;
  $("journalOn").checked = !!cfg.journalOn;
  storeGet({ journal: [] }).then((s) => {
    const list = Array.isArray(s.journal) ? s.journal : [];
    box.innerHTML = ""; $("journalEmpty").hidden = list.length > 0; $("journalClear").hidden = list.length === 0;
    for (const e of list) {
      const row = document.createElement("div"); row.className = "jrow";
      const when = new Date(e.t).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
      if (e.img) {
        const a = document.createElement("a"), im = document.createElement("img");
        im.src = e.img; im.alt = "trade"; a.href = e.img; a.title = "Click to save the picture";
        a.download = `trade-${(e.sym || "chart").replace(/[^\w-]+/g, "")}-${new Date(e.t).toISOString().slice(0, 16).replace(/[:T]/g, "-")}.jpg`;
        a.append(im); row.append(a);
      }
      const meta = document.createElement("div"); meta.className = "jmeta";
      meta.innerHTML = `<b>${esc(e.sym || "Trade")}</b> <span class="${e.v >= 0 ? "jup" : "jdn"}">${esc(cfg.privacy && cfg.privacyPnl !== "show" ? "\u2022\u2022\u2022\u2022\u2022" : fmtMoneyP(e.v, e.unit))}</span><small>${esc(when)} \u00B7 held ${fmtDurP(e.secs || 0)}</small>`;
      const del = document.createElement("button"); del.className = "x"; del.title = "Delete"; del.innerHTML = ICON_X;
      del.onclick = async () => { const cur = (await storeGet({ journal: [] })).journal || []; chrome.storage.local.set({ journal: cur.filter((x) => x.id !== e.id) }, renderJournal); };
      row.append(meta, del); box.append(row);
    }
  });
}
// streamer mode + auto trade clips
function syncExtras() {
  if ($("privacyOn")) { $("privacyOn").checked = !!cfg.privacy; seg("privacyPeek", [[false, "Stay blurred"], [true, "Clear while pointing"]], () => !!cfg.privacyPeek, (v) => set({ privacyPeek: v }));
    seg("privacyPnl", [["hide", "Hidden"], ["ticks", "Ticks"], ["points", "Points"], ["show", "Dollars"]], () => cfg.privacyPnl || "hide", (v) => { set({ privacyPnl: v }); syncPrivHint(); renderJournal(); });
    $("privacyAcct").checked = cfg.privacyAcct !== false; $("privacyOrder").checked = !!cfg.privacyOrder; syncPrivHint(); }
  if ($("tradeClipOn")) { $("tradeClipOn").checked = !!cfg.tradeClipOn; $("tradeClipLenRow").hidden = !cfg.tradeClipOn;
    seg("tradeClipLen", [[15, "Last 15s"], [30, "Last 30s"], [60, "Last 1 min"]], () => +cfg.tradeClipLen || 30, (v) => set({ tradeClipLen: v })); }
}
function syncPrivHint() {
  const m = cfg.privacyPnl || "hide";
  $("privacyPnlHint").textContent = m === "hide" ? "Every number in your trade labels becomes dots."
    : m === "show" ? "Your P&L stays visible in dollars; only the panels you pick below are blurred."
    : `Dollar amounts become dots; ${m === "points" ? "TradingView's tick values are shown in points (futures we know the tick size of; others stay in ticks)" : "tick and % values stay visible"}. Set TradingView to show ticks: Settings \u203A Trading \u203A P&L in Ticks.`;
}
if ($("privacyAcct")) $("privacyAcct").onchange = (e) => set({ privacyAcct: e.target.checked });
if ($("privacyOrder")) $("privacyOrder").onchange = (e) => set({ privacyOrder: e.target.checked });
if ($("privacyOn")) $("privacyOn").onchange = (e) => { set({ privacy: e.target.checked }); renderJournal(); };
if ($("tradeClipOn")) $("tradeClipOn").onchange = (e) => { set({ tradeClipOn: e.target.checked }); syncExtras(); };
if ($("journalOn")) {
  $("journalOn").onchange = (e) => set({ journalOn: e.target.checked });
  $("journalClear").onclick = () => { try { chrome.storage.local.set({ journal: [] }, renderJournal); } catch {} };
}
// the page updates these while the panel is open (a trade just closed)
try { chrome.storage.onChanged && chrome.storage.onChanged.addListener((ch, area) => { if (area !== "local") return; if (ch.dayPnl) syncGoal(); if (ch.journal) renderJournal(); }); } catch {}

// sliders: their track fills up to the value (CSS reads --p), for every slider in the panel, as it moves
function paintRange(r) { const min = +r.min || 0, max = r.max === "" ? 100 : +r.max, v = +r.value; r.style.setProperty("--p", (max > min ? ((v - min) / (max - min)) * 100 : 0) + "%"); }
document.addEventListener("input", (e) => { if (e.target && e.target.type === "range") paintRange(e.target); }, true);
new MutationObserver(() => document.querySelectorAll('input[type="range"]').forEach(paintRange)).observe(document.body, { childList: true, subtree: true });
setTimeout(() => document.querySelectorAll('input[type="range"]').forEach(paintRange), 0);

// ---------- tune ----------
const SLIDERS = [
  ["opacity", "Opacity", 0, 1, 0.05, (v) => Math.round(v * 100) + "%"],
  ["overOpacity", "On top", 0.05, 1, 0.05, (v) => Math.round(v * 100) + "%"],
  ["dim", "Darken", 0, 0.9, 0.05, (v) => Math.round(v * 100) + "%"],
  ["blur", "Blur", 0, 20, 1, (v) => v + "px"],
  ["vividness", "Saturation", 0, 2, 0.05, (v) => Math.round(v * 100) + "%"],
  ["tint", "Hue", 0, 360, 5, (v) => (v ? v + "°" : "Off")],
  ["speed", "Speed", 0.25, 3, 0.05, (v) => v.toFixed(1) + "×"],
  ["vignette", "Vignette", 0, 1, 0.05, (v) => (v ? Math.round(v * 100) + "%" : "Off")],
  ["posX", "Horizontal", 0, 100, 1, (v) => (v === 50 ? "Middle" : v + "%")],
  ["posY", "Vertical", 0, 100, 1, (v) => (v === 50 ? "Middle" : v + "%")],
];
function seg(id, options, get, onPick) {
  const box = $(id); box.innerHTML = "";
  options.forEach(([val, label]) => {
    const b = document.createElement("button");
    if (label.startsWith("<svg")) { b.innerHTML = label; b.title = val; } else b.textContent = label;
    b.className = get() === val ? "on" : "";
    b.onclick = () => { onPick(val); seg(id, options, get, onPick); };
    box.appendChild(b);
  });
}
// ---------- chart styling: grid, crosshair, price line ----------
const CHART_PARTS = [
  { k: "grid", title: "Grid", desc: "The lines behind the candles.", styles: [["solid", "Solid"], ["dotted", "Dotted"], ["dashed", "Dashed"], ["none", "None"]] },
  { k: "ch", title: "Crosshair", desc: "The lines that follow your pointer.", styles: [["solid", "Solid"], ["dotted", "Dotted"], ["dashed", "Dashed"]], glow: true },
  { k: "pl", title: "Price line", desc: "The dotted line at the last price.", styles: [["solid", "Solid"], ["dotted", "Dotted"], ["dashed", "Dashed"]] },
  { k: "sb", title: "Session breaks", desc: "The lines between trading sessions (turn them on in TradingView first).", styles: [["solid", "Solid"], ["dotted", "Dotted"], ["dashed", "Dashed"], ["none", "Hide"]] },
  { k: "ax", title: "Scale borders", desc: "The edge lines of the price and time scales.", styles: [["solid", "Show"], ["none", "Hide"]] },
];
function renderChartStyle() {
  const box = $("chartStyle"); if (!box) return;
  box.innerHTML = ""; if ($("scaleParts")) $("scaleParts").innerHTML = "";
  for (const p of CHART_PARTS) {
    const on = !!cfg[p.k + "On"], card = document.createElement("div"); card.className = "cpart";
    const host = p.k === "ax" && $("scaleParts") ? $("scaleParts") : box;     // scale borders live with the price scale
    card.innerHTML = `<div class="cpart-h"><div><b>${p.title}</b><small>${p.desc}</small></div><div class="seg cpart-mode" id="cs-${p.k}-on"></div></div>`;
    host.appendChild(card);
    seg(`cs-${p.k}-on`, [[false, "Own"], [true, "Styled"]], () => !!cfg[p.k + "On"], (v) => { set({ [p.k + "On"]: v }); renderChartStyle(); });
    if (!on) continue;
    const body = document.createElement("div"); body.className = "cpart-b";
    const colKey = p.k + "Color", cur = cfg[colKey] || "";
    body.innerHTML = `<div class="row"><span>Colour</span><div class="seg" id="cs-${p.k}-cm"></div><input type="color" id="cs-${p.k}-col" ${/^#/.test(cur) ? "" : "hidden"} /></div>
      <div class="row"><span>Width</span><div class="seg" id="cs-${p.k}-w"></div></div>
      <div class="row"><span>Style</span><div class="seg" id="cs-${p.k}-st"></div></div>` +
      (p.k === "grid" ? `<div class="row"><span>Strength</span><input type="range" id="cs-grid-a" min="0.05" max="1" step="0.05" /><output id="cs-grid-ao"></output></div>` : "") +
      (p.glow ? `<div class="row"><span>Glow at the pointer</span><div class="seg" id="cs-ch-glow"></div></div>` +
        (cfg.chGlow ? `<div class="row"><span>Glow colour</span><div class="seg" id="cs-ch-gc"></div><input type="color" id="cs-ch-gcol" ${/^#/.test(cfg.chGlowColor || "") ? "" : "hidden"} /></div>` : "") + `<div class="row"><span>Price &amp; time labels</span><div class="seg" id="cs-ch-lab"></div></div>` : "");
    card.appendChild(body);
    seg(`cs-${p.k}-cm`, [["", "Skin colour"], ["candle", "Candle"], ["custom", "Custom"]], () => (/^#/.test(cfg[colKey] || "") ? "custom" : cfg[colKey] || ""),
      (v) => { set({ [colKey]: v === "custom" ? ($(`cs-${p.k}-col`).value || "#7df9ff") : v }); renderChartStyle(); });
    const ci = $(`cs-${p.k}-col`); ci.value = /^#/.test(cur) ? cur : "#7df9ff"; ci.oninput = (e) => set({ [colKey]: e.target.value });
    seg(`cs-${p.k}-w`, [[0, "1"], [1, "2"], [2, "3"]], () => +cfg[p.k + "W"] || 0, (v) => set({ [p.k + "W"]: v }));
    seg(`cs-${p.k}-st`, p.styles, () => cfg[p.k + "Style"], (v) => set({ [p.k + "Style"]: v }));
    if (p.k === "grid") { const r = $("cs-grid-a"); r.value = cfg.gridAlpha; $("cs-grid-ao").textContent = Math.round(cfg.gridAlpha * 100) + "%";
      r.oninput = (e) => { set({ gridAlpha: +e.target.value }); $("cs-grid-ao").textContent = Math.round(+e.target.value * 100) + "%"; }; }
    if (p.glow) { seg("cs-ch-glow", [[false, "Off"], [true, "On"]], () => !!cfg.chGlow, (v) => { set({ chGlow: v }); renderChartStyle(); });
      if (cfg.chGlow) {   // the glow's own colour: the crosshair's (default), your up-candle colour, or any colour
        const gc = cfg.chGlowColor || "";
        seg("cs-ch-gc", [["", "Crosshair"], ["candle", "Candle"], ["custom", "Custom"]], () => (/^#/.test(gc) ? "custom" : gc),
          (v) => { set({ chGlowColor: v === "custom" ? ($("cs-ch-gcol").value || "#ffd166") : v }); renderChartStyle(); });
        const gi = $("cs-ch-gcol"); gi.value = /^#/.test(gc) ? gc : "#ffd166"; gi.oninput = (e) => set({ chGlowColor: e.target.value });
      }
      seg("cs-ch-lab", [[false, "Own"], [true, "Match crosshair"]], () => !!cfg.chLabels, (v) => set({ chLabels: v })); }
  }
  renderTicker(box);
  renderLegend(box);
  renderChartText(box);
}
// Text indicators draw ON the chart (labels, levels, values, prints). Black text on a dark wallpaper is always made
// readable; this lets you go further.
function renderChartText(box) {
  const card = document.createElement("div"); card.className = "cpart";
  card.innerHTML = `<div class="cpart-h"><div><b>Chart text</b><small>Text your indicators write on the chart: labels, levels, values, prints.</small></div></div>
    <div class="cpart-b"><div class="row"><span>Colour</span><div class="seg" id="tx-mode"></div><input type="color" id="tx-col" ${cfg.txtMode === "custom" ? "" : "hidden"} /></div>
    <div class="row"><span>Outline</span><div class="seg" id="tx-out"></div></div>
    <div class="row"><span>Size</span><div class="seg" id="tx-size"></div></div>
    <p class="hint">Text inside an indicator's own label box keeps its colours. Black text on a dark wallpaper is always lightened.</p></div>`;
  box.appendChild(card);
  seg("tx-mode", [["own", "Own"], ["readable", "Readable"], ["candle", "Candle"], ["custom", "Custom"]], () => cfg.txtMode || "own",
    (v) => { set(v === "custom" && !/^#/.test(cfg.txtColor || "") ? { txtMode: v, txtColor: $("tx-col").value || "#ffffff" } : { txtMode: v }); renderChartStyle(); });
  const ci = $("tx-col"); ci.value = /^#[0-9a-f]{6}$/i.test(cfg.txtColor || "") ? cfg.txtColor : "#ffffff"; ci.oninput = (e) => set({ txtColor: e.target.value });
  seg("tx-out", [[0, "Off"], [1, "Soft"], [2, "Strong"]], () => +cfg.txtOutline || 0, (v) => set({ txtOutline: v }));
  seg("tx-size", [[0, "Normal"], [1, "Large"], [2, "XL"]], () => +cfg.txtSize || 0, (v) => set({ txtSize: v }));
}
// The legend: indicator names and values, and O H L C, at the top left of the chart. Made for the platform's own
// background, so on some wallpapers it's hard to read: give it your colour and / or a backing.
function renderLegend(box) {
  const card = document.createElement("div"); card.className = "cpart";
  card.innerHTML = `<div class="cpart-h"><div><b>Legend</b><small>Indicator names and values, and O H L C, at the top left.</small></div><div class="seg cpart-mode" id="lg-on"></div></div>`;
  box.appendChild(card);
  seg("lg-on", [[false, "Own"], [true, "Styled"]], () => !!cfg.lgOn, (v) => { set({ lgOn: v }); renderChartStyle(); });
  if (!cfg.lgOn) return;
  const cur = cfg.lgColor || "", body = document.createElement("div"); body.className = "cpart-b";
  body.innerHTML = `<div class="row"><span>Text</span><div class="seg" id="lg-cm"></div><input type="color" id="lg-col" ${/^#/.test(cur) ? "" : "hidden"} /></div>
    <div class="row"><span>Values</span><div class="seg" id="lg-vals"></div></div>
    <div class="row"><span>Box behind the text</span><div class="seg" id="lg-back"></div></div>
    <p class="hint"><b>Text</b>: Readable picks white or black for your wallpaper. <b>Box behind the text</b> puts a small dark box (or a light one on bright wallpapers) behind each legend line, so names and values stay easy to read on a busy wallpaper. Frosted blurs the wallpaper behind it. The ticker's own style (above) still wins for the symbol name.</p>`;
  card.appendChild(body);
  seg("lg-cm", [["", "Readable"], ["candle", "Candle"], ["custom", "Custom"]], () => (/^#/.test(cfg.lgColor || "") ? "custom" : cfg.lgColor || ""),
    (v) => { set({ lgColor: v === "custom" ? ($("lg-col").value || "#ffffff") : v }); renderChartStyle(); });
  const ci = $("lg-col"); ci.value = /^#/.test(cur) ? cur : "#ffffff"; ci.oninput = (e) => set({ lgColor: e.target.value });
  seg("lg-vals", [["own", "Keep their colours"], ["all", "Same colour"]], () => cfg.lgVals === "all" ? "all" : "own", (v) => set({ lgVals: v }));
  seg("lg-back", [["none", "None"], ["shade", "Box"], ["glass", "Frosted"]], () => ["shade", "glass"].includes(cfg.lgBack) ? cfg.lgBack : "none", (v) => set({ lgBack: v }));
}
// The ticker: the symbol name at the top left of the chart (plus timeframe and exchange). Not a line, but it lives
// with the other parts of the chart you can style.
function renderTicker(box) {
  const card = document.createElement("div"); card.className = "cpart";
  card.innerHTML = `<div class="cpart-h"><div><b>Ticker</b><small>The symbol name at the top left of the chart.</small></div><div class="seg cpart-mode" id="tk-on"></div></div>`;
  box.appendChild(card);
  seg("tk-on", [[false, "Own"], [true, "Styled"]], () => !!cfg.tkOn, (v) => { set({ tkOn: v }); renderChartStyle(); });
  if (!cfg.tkOn) return;
  const cur = cfg.tkColor || "", body = document.createElement("div"); body.className = "cpart-b";
  body.innerHTML = `<div class="row"><span>Colour</span><div class="seg" id="tk-cm"></div><input type="color" id="tk-col" ${/^#/.test(cur) ? "" : "hidden"} /></div>
    <div class="row"><span>Size</span><div class="seg" id="tk-size"></div></div>
    <div class="row"><span>Font</span><div class="seg" id="tk-font"></div></div>
    <div class="row"><span>Glow</span><div class="seg" id="tk-glow"></div></div>
    <div class="row"><span>Show</span><div class="seg" id="tk-only"></div></div>`;
  card.appendChild(body);
  seg("tk-cm", [["", "Skin colour"], ["candle", "Candle"], ["custom", "Custom"]], () => (/^#/.test(cfg.tkColor || "") ? "custom" : cfg.tkColor || ""),
    (v) => { set({ tkColor: v === "custom" ? ($("tk-col").value || "#ffffff") : v }); renderChartStyle(); });
  const ci = $("tk-col"); ci.value = /^#/.test(cur) ? cur : "#ffffff"; ci.oninput = (e) => set({ tkColor: e.target.value });
  seg("tk-size", [[0, "Normal"], [1, "Large"], [2, "XL"], [3, "Huge"]], () => +cfg.tkSize || 0, (v) => set({ tkSize: v }));
  fontPicker("tk-font", "tkFont");
  seg("tk-glow", [[false, "Off"], [true, "On"]], () => !!cfg.tkGlow, (v) => set({ tkGlow: v }));
  seg("tk-only", [[false, "Name, timeframe, exchange"], [true, "Name only"]], () => !!cfg.tkOnly, (v) => set({ tkOnly: v }));
}
// ---------- shortcuts ----------
const KEY_NAMES = { focusKey: "Focus mode", privacyKey: "Streamer mode", recordKey: "Record a clip", snapKey: "Snapshot", lensKey: "Magnifier", toggleKey: "Turn everything on/off" };
const keyLabel = (spec) => spec ? String(spec).split("+").map((k) => k.replace(/^Key/, "").replace(/^Digit/, "").replace(/^Arrow/, "")).join("+") : "Off";
const TV_ALT = ["KeyT", "KeyH", "KeyJ", "KeyV", "KeyC", "KeyF", "KeyI", "KeyL", "KeyR", "KeyS", "KeyA", "KeyG", "KeyP", "KeyW", "KeyX", "KeyZ", "KeyK", "KeyN", "KeyO", "KeyD", "KeyB"];
let keyListen = null;
function syncShortcuts() {
  document.querySelectorAll(".keybtn").forEach((b) => { b.textContent = keyListen === b.dataset.key ? "Press keys\u2026" : keyLabel(cfg[b.dataset.key]); b.classList.toggle("listening", keyListen === b.dataset.key);
    b.onclick = () => { keyListen = keyListen === b.dataset.key ? null : b.dataset.key; if ($("keyMsg")) $("keyMsg").textContent = keyListen ? "Press the new shortcut. Esc cancels, Backspace turns it off." : ""; syncShortcuts(); }; });
  if ($("focusHides")) seg("focusHides", [["wallpaper", "Wallpaper"], ["all", "Everything"]], () => cfg.focusHides || "wallpaper", (v) => set({ focusHides: v }));
  if ($("tipToggle")) $("tipToggle").textContent = keyLabel(cfg.toggleKey); if ($("tipFocus")) $("tipFocus").textContent = keyLabel(cfg.focusKey);
  const fb = $("focusBar");
  if (fb) { fb.hidden = !cfg.focus; if (cfg.focus) { fb.innerHTML = `<b>Focus is on</b><p class="hint" style="color:#cfd5e2;margin:2px 0 8px">Your wallpaper is hidden. Press <b>${esc(keyLabel(cfg.focusKey))}</b> on the chart to bring it back.</p><button class="primary" id="focusExit">Exit focus</button>`; $("focusExit").onclick = () => { set({ focus: false }); syncShortcuts(); }; } }
}
addEventListener("keydown", (e) => {
  if (!keyListen) return;
  e.preventDefault(); e.stopPropagation();
  const msg = (t) => { if ($("keyMsg")) $("keyMsg").textContent = t; };
  if (e.key === "Escape") { keyListen = null; msg(""); return syncShortcuts(); }
  if (e.key === "Backspace" || e.key === "Delete") { set({ [keyListen]: "" }); msg(`${KEY_NAMES[keyListen]} shortcut turned off.`); keyListen = null; return syncShortcuts(); }
  if (["Shift", "Control", "Alt", "Meta"].includes(e.key)) return;               // wait for the real key
  const fkey = /^F([1-9]|1[0-2])$/.test(e.code);
  if (!e.altKey && !e.ctrlKey && !e.metaKey && !fkey) return msg("Add Alt, Ctrl or \u2318 (or use an F-key) so it never fires while you type.");
  const spec = [e.ctrlKey && "Ctrl", e.altKey && "Alt", e.shiftKey && "Shift", e.metaKey && "Meta", e.code].filter(Boolean).join("+");
  const used = Object.keys(KEY_NAMES).find((k) => k !== keyListen && cfg[k] === spec);
  if (used) return msg(`${keyLabel(spec)} is already used for ${KEY_NAMES[used]}.`);
  if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && ["KeyC", "KeyV", "KeyX", "KeyZ", "KeyY", "KeyS", "KeyF", "KeyP", "KeyA", "KeyR", "KeyW", "KeyT", "KeyN"].includes(e.code))
    return msg(`${keyLabel(spec)} is a browser shortcut. Pick another one.`);
  const tvClash = (e.altKey && !e.shiftKey && !e.ctrlKey && !e.metaKey && TV_ALT.includes(e.code))
    || (e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && e.code === "KeyR");   // Alt+Shift+R = TradingView's Rectangle tool
  set({ [keyListen]: spec });
  msg(`${KEY_NAMES[keyListen]}: ${keyLabel(spec)}.` + (tvClash ? ` TradingView also uses ${keyLabel(spec)}; on the chart Priism takes it. Add Shift to keep both.` : ""));
  keyListen = null; syncShortcuts();
}, true);

// ---------- session timer ----------
function syncTimer() {
  if (!$("timerOn")) return;
  $("timerOn").checked = !!cfg.timerOn; $("timerMarket").value = cfg.timerMarket || "auto";
  seg("timerPos", [["bl", "Bottom left"], ["bc", "Bottom centre"], ["br", "Bottom right"]], () => (["bl", "bc", "br"].includes(cfg.timerPos) ? cfg.timerPos : "bc"), (v) => set({ timerPos: v, timerOn: true }));
  seg("timerStyle", [["pill", "Pill"], ["glass", "Glass card"], ["minimal", "Minimal"]], () => cfg.timerStyle || "pill", (v) => set({ timerStyle: v, timerOn: true }));
  seg("timerShow", [["full", "Status + next"], ["next", "Next only"]], () => cfg.timerShow || "full", (v) => { set({ timerShow: v, timerOn: true }); syncTimer(); });
  seg("timerFormat", [["in", "Countdown"], ["at", "Clock time"]], () => cfg.timerFormat || "in", (v) => { set({ timerFormat: v, timerOn: true }); syncTimer(); });
  seg("timerClosed", [["show", "Keep showing"], ["hide", "Hide"]], () => cfg.timerClosed || "show", (v) => { set({ timerClosed: v, timerOn: true }); syncTimer(); });
  if ($("timerPreview")) {   // what the timer will read, with these choices
    const when = cfg.timerFormat === "at" ? "at " + new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date(2026, 0, 1, 16, 0)) : "in 1h 20m";
    $("timerPreview").textContent = `Example: \u201c${cfg.timerShow === "next" ? "" : "NY session open \u00B7 "}NY session closes ${when}\u201d${cfg.timerClosed === "hide" ? ". Hidden while the market is closed." : ""}`;
  }
  seg("sessionSound", SOUND_LEVELS, () => cfg.sessionSound || "off", (v) => { set({ sessionSound: v }); preview("bell", v); });
}
if ($("timerOn")) { $("timerOn").onchange = (e) => set({ timerOn: e.target.checked }); $("timerMarket").onchange = (e) => set({ timerMarket: e.target.value, timerOn: true }); }

// ---------- share link offer: open the panel on a Priism share link and add the look in one tap ----------
(async function lookOffer() {
  const el = $("lookOffer"); if (!el || !(chrome.tabs && chrome.tabs.query)) return;
  let tab; try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch { return; }
  const parsed = tab && tab.url && /look\.html#PRIISM1-/.test(tab.url) ? parseLookCode(tab.url) : null;
  if (!parsed) return;
  el.innerHTML = `<b>Add this look?</b><p class="hint" style="color:#cfd5e2;margin:2px 0 8px">\u201c${esc(parsed.name || "Shared look")}\u201d \u00B7 ${esc((WickedSkins[parsed.skin] || {}).name || parsed.skin)}. It goes on your chart right away, with Undo.</p><button class="primary" id="lookOfferGo">Add look</button>`;
  el.hidden = false;
  $("lookOfferGo").onclick = () => { applyWithUndo({ ...parsed.look, enabled: true, skin: parsed.skin }, `Added \u201c${parsed.name || "Shared look"}\u201d.`); el.hidden = true; };
})();

// ---------- Pattern skins (TradingView tab): the chart frame + TradingView's bars ----------
const PAT_MODES = [["accent", "Accent"], ["candles", "Candles"], ["gradient", "Gradient"], ["rainbow", "Rainbow"], ["aurora", "Aurora"], ["galaxy", "Galaxy"], ["holo", "Holo"], ["custom", "Custom"]];
const patAccent = () => { const okc = (c) => /^#[0-9a-f]{6}$/i.test(c || ""); const m = cfg.wallMatch;
  return okc(m && m.accent) ? m.accent : okc(cfg.uiAccent) ? cfg.uiAccent : okc(cfg.candleUp) && cfg.candleOn ? cfg.candleUp : "#7c6cff"; };
const patOpts = (mode, c1, c2) => ({ mode, color: c1, color2: c2, up: cfg.candleOn ? cfg.candleUp : "#26a69a", down: cfg.candleOn ? cfg.candleDown : "#ef5350", accent: patAccent(), mood: cfg.candleOn ? cfg.candleUp : "#00e08a" });
// a grid of pattern chips, each a little swatch in the chosen colours
function patGrid(id, cur, mode, c1, c2, pick) {
  const box = $(id), P = window.PriismPatterns; if (!box || !P) return;
  const bg = P.paint({ ...patOpts(mode, c1, c2), round: false }), sig = bg + "|" + P.LIST.length;
  if (box.dataset.sig !== sig) { box.dataset.sig = sig; box.textContent = "";
    for (const [pid, name] of P.LIST) { const b = document.createElement("button"); b.type = "button"; b.className = "patchip"; b.dataset.p = pid;
      const sw = document.createElement("i"); const m = P.mask(pid, 0.8); sw.style.background = bg;
      if (pid !== "solid") { sw.style.webkitMaskImage = sw.style.maskImage = m.image; sw.style.webkitMaskSize = sw.style.maskSize = m.size; }
      const lab = document.createElement("span"); lab.textContent = name; b.append(sw, lab); b.onclick = () => pick(pid); box.appendChild(b); } }
  for (const b of box.children) b.classList.toggle("on", b.dataset.p === cur);
}
// the preview: your wallpaper with a little chart, the frame around it, and a bar along the top
function drawPatPreview() { for (const id of ["patPrev", "ifPrev"]) { const cv = $(id); if (cv && cv.offsetParent !== null) drawPatPreviewOn(cv); } }
function drawPatPreviewOn(cv) {
  const P = window.PriismPatterns; if (!cv || !P) return;
  const g = cv.getContext("2d"), W = cv.width, H = cv.height; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
  try { const sk = WickedSkins[cfg.skin]; if (sk) { const s0 = makeSkin(cfg.skin, g); s0.resize(W, H); s0.frame(3, 0.016); } } catch {}
  g.fillStyle = "rgba(0,0,0,0.35)"; g.fillRect(0, 0, W, H);
  const barH = 22, tv = !document.body.classList.contains("lw-page");
  if (tv) { g.fillStyle = "#131722"; g.fillRect(0, 0, W, barH); g.fillRect(0, barH, 26, H - barH); }
  const x0 = tv ? 26 : 0, y0 = tv ? barH : 0, cw = W - x0 - (tv && cfg.barPatOn && String(cfg.barWhere || "tlrb").includes("r") ? 70 : 0), ch = H - y0;
  // candles
  let p = 50, seed = 3; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 26; i++) { const o = p; p += (rnd() - 0.47) * 9; const up = p >= o, x = x0 + 22 + i * ((cw - 44) / 26), top = y0 + ch * 0.5 - (Math.max(o, p) - 50) * 1.4, hh = Math.max(2, Math.abs(p - o) * 1.4);
    g.fillStyle = up ? (cfg.candleOn ? cfg.candleUp : "#26a69a") : (cfg.candleOn ? cfg.candleDown : "#ef5350"); g.fillRect(x, top, 7, hh); g.fillRect(x + 3, top - 5, 1, hh + 10); }
  let wait = false;
  if (cfg.frameOn) { if (cfg.framePattern !== "solid" && !P.image(cfg.framePattern)) wait = true;
    P.band(g, x0, y0, cw, ch, Math.max(2, +cfg.frameW || 8), { ...patOpts(cfg.frameMode, cfg.frameColor, cfg.frameColor2), round: true, pattern: cfg.framePattern, scale: cfg.frameSize,
      alpha: cfg.frameAlpha, radius: cfg.frameRound ? 12 : 0, edge: !!cfg.frameEdge, dpr: 1 }); }
  if (tv && cfg.barPatOn) { if (cfg.barPattern !== "solid" && !P.image(cfg.barPattern)) wait = true;
    const where = String(cfg.barWhere || "tlrb"), o = { ...patOpts(cfg.barMode, cfg.barColor, cfg.barColor2), round: false, pattern: cfg.barPattern, scale: cfg.barSize, alpha: Math.min(1, (+cfg.barAlpha || 0.25) * 1.6), dpr: 1 };
    const pg = g.globalCompositeOperation; g.globalCompositeOperation = "screen";
    if (where.includes("t")) P.band(g, 0, 0, W, barH, 0, o); if (where.includes("l")) P.band(g, 0, barH, 26, H - barH, 0, o);
    if (where.includes("r")) { g.globalCompositeOperation = pg; g.fillStyle = "#131722"; g.fillRect(W - 70, barH, 70, H - barH); g.globalCompositeOperation = "screen"; P.band(g, W - 70, barH, 70, H - barH, 0, o); }
    g.globalCompositeOperation = pg; }
  if (tv) { g.fillStyle = "rgba(226,232,244,.85)"; g.font = "600 11px system-ui"; g.fillText("NQ1!  5m", 10, 15); for (let i = 0; i < 4; i++) g.fillRect(9, barH + 12 + i * 26, 8, 8); }   // tools stay clear
  if (cv.id === "patPrev" ? !cfg.frameOn : !(tv && cfg.barPatOn)) { g.fillStyle = "rgba(255,255,255,.6)"; g.font = "600 12px system-ui"; g.textAlign = "center"; g.fillText(cv.id === "patPrev" ? "Turn the frame on to see it here" : "Turn the skin on to see it here", W / 2, H - 14); g.textAlign = "start"; }
  if (wait) setTimeout(drawPatPreview, 120);
}
function syncPatterns() {
  if (!$("frameOn")) return;
  seg("frameOn", [[false, "Off"], [true, "On"]], () => !!cfg.frameOn, (v) => { set({ frameOn: v }); syncPatterns(); });
  $("frameBox").hidden = !cfg.frameOn;
  const fm = [...PAT_MODES, ["mood", "Live mood"]];
  patGrid("framePattern", cfg.framePattern || "carbon", cfg.frameMode, cfg.frameColor, cfg.frameColor2, (p) => { set({ framePattern: p }); syncPatterns(); });
  seg("frameMode", fm, () => cfg.frameMode || "accent", (v) => { set({ frameMode: v }); syncPatterns(); });
  $("frameColRow").hidden = !["custom", "gradient"].includes(cfg.frameMode); $("frameColor").value = cfg.frameColor || "#7c6cff"; $("frameColor2").value = cfg.frameColor2 || "#ff4df0"; $("frameColor2").hidden = cfg.frameMode !== "gradient";
  $("frameW").value = cfg.frameW; $("frameWOut").textContent = cfg.frameW + "px";
  $("frameAlpha").value = cfg.frameAlpha; $("frameAlphaOut").textContent = Math.round(cfg.frameAlpha * 100) + "%";
  $("frameSize").value = cfg.frameSize; $("frameSizeOut").textContent = (+cfg.frameSize).toFixed(1) + "×";
  seg("frameRound", [[false, "Square"], [true, "Rounded"]], () => !!cfg.frameRound, (v) => { set({ frameRound: v }); drawPatPreview(); });
  seg("frameEdge", [[false, "Off"], [true, "On"]], () => !!cfg.frameEdge, (v) => { set({ frameEdge: v }); drawPatPreview(); });
  seg("frameMove", [[false, "Still"], [true, "Slow drift"]], () => !!cfg.frameMove, (v) => set({ frameMove: v }));
  $("frameHint").textContent = cfg.frameMode === "mood" ? (cfg.react === "off" ? "Live mood is off (Trading › Live mood): the frame stays dim in your up colour until you turn it on." : "The frame takes Live mood's colour and lights up as the glow does.")
    : "Behind the chart: candles, lines and the price scale draw over it. Slow drift moves the pattern very slowly (off with Power saver).";
  seg("barPatOn", [[false, "TradingView"], [true, "Skin it"]], () => !!cfg.barPatOn, (v) => { set({ barPatOn: v }); syncPatterns(); });
  $("barBox").hidden = !cfg.barPatOn || document.body.classList.contains("lw-page");
  patGrid("barPattern", cfg.barPattern || "zebra", cfg.barMode, cfg.barColor, cfg.barColor2, (p) => { set({ barPattern: p }); syncPatterns(); });
  const where = String(cfg.barWhere || "tlrb");
  { const box = $("barWhere"); box.innerHTML = "";
    for (const [k, n] of [["t", "Top"], ["l", "Left"], ["r", "Right"], ["b", "Bottom"]]) { const b = document.createElement("button"); b.textContent = n; b.className = where.includes(k) ? "on" : "";
      b.onclick = () => { const next = where.includes(k) ? where.replace(k, "") : where + k; set({ barWhere: next || "t" }); syncPatterns(); }; box.appendChild(b); } }
  seg("barMode", PAT_MODES, () => cfg.barMode || "accent", (v) => { set({ barMode: v }); syncPatterns(); });
  $("barColRow").hidden = !["custom", "gradient"].includes(cfg.barMode); $("barColor").value = cfg.barColor || "#7c6cff"; $("barColor2").value = cfg.barColor2 || "#ff4df0"; $("barColor2").hidden = cfg.barMode !== "gradient";
  $("barAlpha").value = cfg.barAlpha; $("barAlphaOut").textContent = Math.round(cfg.barAlpha * 100) + "%";
  $("barSize").value = cfg.barSize; $("barSizeOut").textContent = (+cfg.barSize).toFixed(1) + "×";
  drawPatPreview();
}
for (const [id, key, fmt] of [["frameW", "frameW", (v) => v + "px"], ["frameAlpha", "frameAlpha", (v) => Math.round(v * 100) + "%"], ["frameSize", "frameSize", (v) => (+v).toFixed(1) + "×"],
  ["barAlpha", "barAlpha", (v) => Math.round(v * 100) + "%"], ["barSize", "barSize", (v) => (+v).toFixed(1) + "×"]]) {
  const el = $(id); if (el) el.oninput = (e) => { set({ [key]: +e.target.value }); $(id + "Out").textContent = fmt(+e.target.value); drawPatPreview(); };
}
for (const id of ["frameColor", "frameColor2", "barColor", "barColor2"]) { const el = $(id); if (el) el.oninput = (e) => { set({ [id]: e.target.value }); syncPatterns(); }; }
// ---------- Trade panel (TradingView tab) ----------
function syncTradePanel() {
  if (!$("tpOn")) return;
  seg("tpOn", [[false, "TradingView's"], [true, "Style it"]], () => !!cfg.tpOn, (v) => { set({ tpOn: v }); syncTradePanel(); });
  $("tpBox").hidden = !cfg.tpOn;
  seg("tpColors", [["candles", "Candles"], ["custom", "Custom"]], () => cfg.tpColors || "candles", (v) => { set({ tpColors: v }); syncTradePanel(); });
  $("tpColRow").hidden = cfg.tpColors !== "custom"; $("tpBuy").value = cfg.tpBuy || "#2962ff"; $("tpSell").value = cfg.tpSell || "#f23645";
  seg("tpStyle", [["solid", "Solid"], ["glass", "Glass"], ["outline", "Outline"], ["neon", "Neon"]], () => cfg.tpStyle || "solid", (v) => { set({ tpStyle: v }); syncTradePanel(); });
  seg("tpShape", [["rounded", "Rounded"], ["pill", "Pill"], ["square", "Square"]], () => cfg.tpShape || "rounded", (v) => { set({ tpShape: v }); syncTradePanel(); });
  seg("tpPanel", [["keep", "TradingView's"], ["glass", "Glass"]], () => cfg.tpPanel || "keep", (v) => { set({ tpPanel: v }); syncTradePanel(); });
  // the preview: the same look the chart gets, on your wallpaper
  const L = window.PriismTradeLook && window.PriismTradeLook({ buy: cfg.tpColors === "custom" ? cfg.tpBuy : (cfg.candleOn ? cfg.candleUp : "#26a69a"), sell: cfg.tpColors === "custom" ? cfg.tpSell : (cfg.candleOn ? cfg.candleDown : "#ef5350"), shape: cfg.tpShape, style: cfg.tpStyle });
  const box = $("tpPrev");
  if (L && box) { for (const [cls, st] of [["tp-b", L.buy], ["tp-s", L.sell]]) { const b = box.querySelector("." + cls); b.removeAttribute("style"); for (const [k, v] of Object.entries(st)) b.style.setProperty(k, v); }
    if (!box.dataset.bg) { try { const c = document.createElement("canvas"); c.width = 280; c.height = 70; if (WickedSkins[cfg.skin]) { const s0 = makeSkin(cfg.skin, c.getContext("2d")); s0.resize(280, 70); s0.frame(3, 0.016); box.style.backgroundImage = `url(${c.toDataURL()})`; box.dataset.bg = "1"; } } catch {} } }
}
for (const id of ["tpBuy", "tpSell"]) { const el = $(id); if (el) el.oninput = (e) => { set({ [id]: e.target.value }); syncTradePanel(); }; }
function syncPanels() {
  if (!$("panelMode")) return;
  if ($("dlgMode")) {
    seg("dlgMode", [["off", "TradingView"], ["glass", "Glass"], ["color", "Colour"]], () => cfg.dlgMode || "off", (v) => { set({ dlgMode: v }); syncPanels(); });
    $("dlgColor").hidden = cfg.dlgMode !== "color"; $("dlgColor").value = cfg.dlgColor || "#12151f";
    $("dlgAlphaRow").hidden = !cfg.dlgMode || cfg.dlgMode === "off";
    $("dlgAlpha").value = cfg.dlgAlpha; $("dlgAlphaOut").textContent = Math.round(cfg.dlgAlpha * 100) + "%";
  }
  seg("panelMode", [["off", "TradingView"], ["skin", "Skin"], ["color", "Colour"]], () => cfg.panelMode || "off", (v) => { set({ panelMode: v }); syncPanels(); });
  if ($("pnStyle")) { seg("pnStyle", [["flat", "Flat"], ["glass", "Glass"], ["neon", "Neon edge"], ["outline", "Outline"], ["aurora", "Aurora edge"]], () => cfg.pnStyle || "flat", (v) => { set({ pnStyle: v }); syncPanels(); });
    seg("pnRound", [[false, "Square"], [true, "Rounded"]], () => !!cfg.pnRound, (v) => { set({ pnRound: v }); syncPanels(); });
    seg("pnWindows", [[true, "Panels + windows & menus"], [false, "Panels only"]], () => cfg.pnWindows !== false, (v) => { set({ pnWindows: v }); syncPanels(); }); }
  $("panelColor").hidden = cfg.panelMode !== "color"; $("panelColor").value = cfg.panelColor || "#10131c";
}
if ($("dlgColor")) $("dlgColor").oninput = (e) => set({ dlgColor: e.target.value, dlgMode: "color" });
if ($("dlgAlpha")) $("dlgAlpha").oninput = (e) => { set({ dlgAlpha: +e.target.value }); $("dlgAlphaOut").textContent = Math.round(+e.target.value * 100) + "%"; };
if ($("panelColor")) $("panelColor").oninput = (e) => set({ panelColor: e.target.value, panelMode: "color" });

function syncTune() {
  try { syncWallOpts(); wallPrev = null; setTimeout(drawWallPrev, 30); } catch {}
  $("sliders").innerHTML = "";
  SLIDERS.forEach(([key, label, min, max, step, fmt]) => {
    // only show what matters right now
    if ((key === "posX" || key === "posY") && cfg.skin !== "media") return;
    if (key === "overOpacity" && cfg.layer !== "over") return;
    if (key === "opacity" && cfg.layer === "over") return;
    const row = document.createElement("div"); row.className = "row"; row.dataset.key = key;
    row.innerHTML = `<span>${label}</span><input type="range" min="${min}" max="${max}" step="${step}"><output></output>`;
    const inp = row.querySelector("input"), out = row.querySelector("output");
    inp.value = cfg[key]; out.textContent = fmt(+cfg[key]);
    inp.oninput = () => { set({ [key]: +inp.value }); out.textContent = fmt(+inp.value); };
    inp.ondblclick = () => { inp.value = DEFAULTS[key]; inp.oninput(); }; // double-click resets
    $("sliders").appendChild(row);
    if (PLAN === "free" && PP.isPro(key)) proLock(row, label);
  });
  document.querySelectorAll("[data-only=media]").forEach((el) => (el.hidden = cfg.skin !== "media"));
  // the wallpaper in black & white (candles, indicators and the rest of the chart keep their colours)
  seg("bwSeg", [[false, "Colour"], [true, "Black & white"]], () => !!cfg.bw, (v) => set({ bw: v }));
  seg("smooth", [["eco", "Eco"], ["balanced", "Balanced"], ["smooth", "Smooth"], ["max", "Max"]],
    () => (cfg.powerSaver ? "eco" : cfg.fps === "max" ? "max" : cfg.fps === "auto" || String(cfg.fps) === "60" ? "smooth" : "balanced"),
    (v) => set(v === "eco" ? { powerSaver: true, fps: 30 } : v === "balanced" ? { powerSaver: false, fps: 30 } : v === "max" ? { powerSaver: false, fps: "max" } : { powerSaver: false, fps: "auto" }));
  // Max runs at your screen's refresh rate (120/144/240Hz). Show it when known.
  const hz = +document.documentElement.getAttribute("data-bd-hz") || 0;   // only set on a chart page, not the popup
  if ($("res")) { seg("res", [["standard", "Standard"], ["sharp", "Sharp"], ["ultra", "Ultra 4K"]], () => cfg.res || "standard", (v) => { set({ res: v }); syncTune(); });
    $("resHint").textContent = cfg.res === "ultra" ? "Ultra: built-in wallpapers and effects drawn with every pixel of your screen (4K on a 4K or Retina screen), clips export up to 4K, and videos you upload keep up to 4K. Uses your graphics card more; Auto quality eases off if your computer can't keep up."
      : cfg.res === "sharp" ? "Sharp: drawn at your screen's size (crisper than Standard). Your own uploaded pictures and videos always show at their own full quality."
      : "Standard: drawn a little under your screen's size, the lightest on your computer. Your own uploaded pictures and videos always show at their own full quality."; }
  if ($("smoothHint")) $("smoothHint").textContent = cfg.powerSaver ? "Eco: 15 fps, lightest on your computer." : cfg.fps === "max" ? "Max: runs at your screen's refresh rate (e.g. 120/144/240Hz) for the smoothest motion. Uses more GPU." : cfg.fps === "auto" ? "Smooth: 60 fps." : "Balanced: 30 fps.";
  // Auto quality: meaningful on Smooth or Max (it eases off if your computer struggles). Eco/Balanced already cap things.
  $("autoQRow").hidden = cfg.powerSaver || (cfg.fps !== "auto" && cfg.fps !== "max");
  seg("autoQuality", [[true, "Auto"], [false, "Max"]], () => (cfg.autoQuality !== false), (v) => set({ autoQuality: v }));
  seg("fit", [["cover", "Cover"], ["fit", "Contain"], ["stretch", "Stretch"]], () => cfg.fit, (v) => set({ fit: v }));
  seg("calm", [[false, "Off"], [true, "On"]], () => cfg.calm, (v) => set({ calm: v }));
  seg("motion", [[false, "On"], [true, "Paused"]], () => cfg.paused, (v) => set({ paused: v }));
  seg("layer", [["behind", "Under chart"], ["over", "On top"]], () => cfg.layer, (v) => { set({ layer: v }); syncTune(); });
  syncClarity();
  // Sides only makes sense under the chart (On top already floats over everything).
  $("sidesRow").hidden = cfg.layer === "over"; if ($("leftBarRow")) $("leftBarRow").hidden = cfg.layer === "over";
  if ($("sidesHint")) $("sidesHint").hidden = cfg.layer === "over";
  seg("sides", [["off", "Default"], ["glass", "Glass"], ["clear", "Clear"]], () => cfg.sides || "off", (v) => set({ sides: v }));
  if ($("leftBar")) seg("leftBar", [["off", "Default"], ["glass", "Glass"], ["clear", "Clear"]], () => cfg.leftBar || "off", (v) => set({ leftBar: v }));
  // Interface (fonts / size / accent for TradingView's own panels)
  fontPicker("uiFont", "uiFont");
  seg("uiSize", [[0, "Normal"], [1, "Large"]], () => (+cfg.uiSize || 0), (v) => set({ uiSize: v }));
  seg("uiAccentMode", [["off", "Default"], ["custom", "Custom"]], () => (cfg.uiAccent ? "custom" : "off"),
    (v) => { set({ uiAccent: v === "custom" ? ($("uiAccent").value || "#2ef2b0") : "" }); syncTune(); });
  $("uiAccent").value = cfg.uiAccent || "#2ef2b0"; $("uiAccent").hidden = !cfg.uiAccent;
  seg("react", [["off", "Off"], ["market", "Day\u2019s move"], ["momentum", "Recent move"], ["pnl", "My position"], ["music", "Music"]], () => cfg.react, (v) => { set({ react: v }); syncReact(); });
  syncReact();
}
function syncReact() {
  $("reactOpts").hidden = cfg.react === "off";
  seg("moodLook", [["glow", "Glow"], ["horizon", "Horizon"], ["frame", "Outline"]], () => cfg.moodLook || "glow", (v) => { set({ moodLook: v }); drawMoodPreview(); });
  seg("moodRange", [[0.5, "High"], [1, "Normal"], [2, "Low"]], () => +cfg.moodRange || 1, (v) => set({ moodRange: v }));
  $("moodRangeRow").hidden = !["market", "momentum"].includes(cfg.react);
  seg("moodPulse", [["off", "Off"], ["soft", "Soft"], ["strong", "Strong"]], () => cfg.moodPulse || "soft", (v) => set({ moodPulse: v }));
  $("musicOpts").hidden = cfg.react !== "music";
  { const box = $("musicParts"), parts = String(cfg.musicParts == null ? "gwfi" : cfg.musicParts); box.innerHTML = "";
    for (const [k, n] of [["g", "Glow"], ["w", "Wallpaper"], ["f", "Chart frame"], ["i", "Interface skin"]]) { const b = document.createElement("button"); b.textContent = n; b.className = parts.includes(k) ? "on" : "";
      b.onclick = () => { set({ musicParts: parts.includes(k) ? parts.replace(k, "") : parts + k }); syncReact(); }; box.appendChild(b); } }
  if ($("lensZoom")) { seg("lensZoom", [[2, "2\u00D7"], [2.5, "2.5\u00D7"], [3, "3\u00D7"], [4, "4\u00D7"]], () => +cfg.lensZoom || 2.5, (v) => set({ lensZoom: v }));
    seg("lensSize", [["s", "Small"], ["m", "Medium"], ["l", "Large"]], () => cfg.lensSize || "m", (v) => set({ lensSize: v })); }
  seg("musicFeel", [["punchy", "Punchy"], ["smooth", "Smooth"]], () => cfg.musicFeel || "punchy", (v) => set({ musicFeel: v }));
  seg("musicSens", [["low", "Low"], ["normal", "Normal"], ["high", "High"]], () => cfg.musicSens || "normal", (v) => set({ musicSens: v }));
  drawMoodPreview();

  $("reactStrength").value = cfg.reactStrength;
  $("reactStrengthOut").textContent = Math.round(cfg.reactStrength * 100) + "%";

  $("reactHint").textContent = cfg.react === "momentum"
    ? "Glows green / red with how price moved over the last 10 minutes, so it follows the market live and calms down when price goes sideways. Move sensitivity sets how big a move lights it fully."
    : cfg.react === "music"
    ? "Moves with the music you're playing, beat for beat. On the chart, tap \u201cChoose the music tab\u201d, pick the tab playing it (YouTube, Spotify, SoundCloud\u2026) and tick \u201cShare tab audio\u201d (on Windows you can share your whole screen with system audio instead). Moves: the glow, your wallpaper (a brighter, slightly bigger kick on each beat), the chart frame and the interface skin, if they're on. Punchy follows every kick; Smooth swells. Nothing is recorded or sent."
    : cfg.react === "market"
    ? "Chart edges glow green/red with the day's move and pulse on every tick. Skins speed up when price moves."
    : "Glows green/red with the open P&L shown on your chart's position line (broker, prop platform or paper trading). Nothing is sent anywhere.";
}
// the Live mood look, up and down, on your wallpaper (the same CSS as on the chart)
function drawMoodPreview() {
  const box = $("moodPrev"), M = window.PriismMood; if (!box || !M) return;
  const up = /^#[0-9a-f]{6}$/i.test(cfg.candleUp || "") && cfg.candleOn ? cfg.candleUp : "#00e08a", dn = /^#[0-9a-f]{6}$/i.test(cfg.candleDown || "") && cfg.candleOn ? cfg.candleDown : "#ff3355";
  box.querySelectorAll(".mp").forEach((el, i) => { const c = M.css(cfg.moodLook || "glow", i ? dn : up, 0.75 * (+cfg.reactStrength || 0.6) + 0.2, i ? -1 : 1);
    const g = el.querySelector("i"); g.style.boxShadow = c.shadow; g.style.background = c.bg; g.style.opacity = String(c.op); });
  if (!box.dataset.bg) { box.dataset.bg = "1"; try { if (WickedSkins[cfg.skin]) box.querySelectorAll(".mp canvas").forEach((cv) => { const s = makeSkin(cfg.skin, cv.getContext("2d")); s.resize(cv.width, cv.height); s.frame(3, 0.016); }); } catch {} }
}
$("reactStrength").oninput = (e) => { set({ reactStrength: +e.target.value }); $("reactStrengthOut").textContent = Math.round(+e.target.value * 100) + "%"; drawMoodPreview(); };

// ---------- session skins ----------
const SESSIONS = [["asia", "Asia", "6pm–3am"], ["london", "London", "3am–8am"], ["ny", "New York", "8am–5pm"], ["off", "After-hours", "5–6pm, weekends"]];
function nowSession() {   // same rules as content.js
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", hour: "numeric", hourCycle: "h23", weekday: "short" }).formatToParts(new Date()).map((p) => [p.type, p.value]));
  const h = +parts.hour, day = parts.weekday;
  if (day === "Sat" || (day === "Sun" && h < 18) || (day === "Fri" && h >= 17)) return "off";
  if (h >= 18 || h < 3) return "asia"; if (h < 8) return "london"; if (h < 17) return "ny"; return "off";
}
function syncSessions() {
  $("sessionOn").checked = cfg.sessionOn;
  const box = $("sessionRows"); box.innerHTML = ""; const now = nowSession();
  const options = `<option value="">Your normal skin</option>` + Object.entries(WickedSkins).map(([id, sk]) => `<option value="${id}">${esc(sk.name)}</option>`).join("");
  for (const [key, label, hours] of SESSIONS) {
    const row = document.createElement("div"); row.className = "row";
    row.innerHTML = `<span>${label}${key === now ? ' <b class="now">now</b>' : ""}<br><small class="hint" style="margin:0">${hours}</small></span><select class="field">${options}</select>`;
    const sel = row.querySelector("select"); sel.value = (cfg.sessionSkins || {})[key] || "";
    sel.onchange = () => { set({ sessionSkins: { ...cfg.sessionSkins, [key]: sel.value }, sessionOn: true }); $("sessionOn").checked = true; };
    box.appendChild(row);
  }
}
$("sessionOn").onchange = (e) => set({ sessionOn: e.target.checked });

// ---------- symbol skins (a wallpaper per ticker) ----------
// Unlike sessions (fixed 4), symbols are open-ended, so you add rows. "Add current" grabs the chart's symbol.
function skinOptions(sel) {
  const opts = `<option value="">Your normal skin</option>` +
    `<optgroup label="Skins">` + Object.entries(WickedSkins).map(([id, sk]) => `<option value="${id}">${esc(sk.name)}</option>`).join("") + `</optgroup>` +
    (cfg.media.filter((m) => !m.pending).length ? `<optgroup label="Your uploads">` + cfg.media.filter((m) => !m.pending).map((m) => `<option value="media:${m.id}">${esc(m.name)}</option>`).join("") + `</optgroup>` : "");
  return opts;
}
function syncSymbols() {
  $("symbolOn").checked = cfg.symbolOn;
  const box = $("symbolRows"); if (!box) return; box.innerHTML = "";
  const map = cfg.symbolSkins || {}, keys = Object.keys(map);
  if (!keys.length) box.insertAdjacentHTML("beforeend", `<p class="hint" style="margin:4px 0">No tickers yet. Add one below (e.g. BTCUSDT, NQ, AAPL) and pick its wallpaper.</p>`);
  for (const sym of keys) {
    const row = document.createElement("div"); row.className = "row";
    row.innerHTML = `<span>${esc(sym)}</span><select class="field">${skinOptions()}</select><button class="x" title="Remove">${ICON_X}</button>`;
    const selEl = row.querySelector("select"); selEl.value = map[sym] || "";
    selEl.onchange = () => { set({ symbolSkins: { ...cfg.symbolSkins, [sym]: selEl.value }, symbolOn: true }); $("symbolOn").checked = true; };
    row.querySelector(".x").onclick = () => { const m = { ...cfg.symbolSkins }; delete m[sym]; set({ symbolSkins: m }); syncSymbols(); };
    box.appendChild(row);
  }
}
async function addSymbol(sym) {
  sym = (sym || "").trim().toUpperCase().replace(/\s+/g, "");
  if (!sym) return;
  if ((cfg.symbolSkins || {})[sym] !== undefined) { $("symbolInput").value = ""; return; }
  set({ symbolSkins: { ...cfg.symbolSkins, [sym]: "" }, symbolOn: true });
  $("symbolInput").value = ""; syncSymbols();
}
$("symbolOn").onchange = (e) => set({ symbolOn: e.target.checked });
$("symbolAdd").onclick = () => addSymbol($("symbolInput").value);
$("symbolInput").onkeydown = (e) => { if (e.key === "Enter") addSymbol($("symbolInput").value); };
$("symbolCurrent").onclick = async () => {
  const r = await tabMsg({ ws: "symbol" });
  if (r && r.symbol) addSymbol(r.symbol); else hint && hint("Open a TradingView chart to grab its symbol.");
};

// ---------- multi-chart layouts ----------
// "Stretch" = one wallpaper across the layout, "Each chart" = a copy per chart, "Mix" = a skin per chart.
// Chart 1 is top-left, then left to right, row by row. Chart 1 always shows your main skin.
let chartCount = 0;          // charts on the current tab (0 = unknown)
let target = "all";          // where a skin goes when you click it: "all" or a chart number
const MULTI_HINT = {
  span: "One wallpaper stretched across your whole layout.",
  each: "Every chart gets its own copy of your skin.",
  mix: "A different skin on each chart. Pick a chart, then click a skin.",
};
const mainSrc = () => (cfg.skin === "media" ? "media:" + cfg.mediaId : cfg.skin);
const chartN = () => Math.min(16, Math.max(chartCount, 2, ...Object.keys(cfg.chartSkins || {}).map(Number).filter((n) => n > 0)));
function currentSrc() {
  if (typeof target === "number" && target > 1) return (cfg.chartSkins || {})[target] || mainSrc();
  return mainSrc();
}
function srcName(src) {
  if (!src) return "";
  if (src.startsWith("media:")) { const m = cfg.media.find((x) => x.id === src.slice(6)); return m ? m.name : "Upload"; }
  return WickedSkins[src] ? WickedSkins[src].name : src;
}
function pickSource(src) {
  const asMain = src.startsWith("media:") ? { skin: "media", mediaId: src.slice(6) } : { skin: src };
  if (target === "all") set({ ...asMain, chartSkins: {}, ...(cfg.multi === "mix" ? { multi: "each" } : {}) });
  else if (target === 1) {
    // only chart 1 should change: charts still following chart 1 keep the skin they show now
    const keep = { ...(cfg.chartSkins || {}) };
    for (let n = 2; n <= chartN(); n++) if (!keep[n]) keep[n] = mainSrc();
    set({ ...asMain, chartSkins: keep, multi: "mix" });
  } else set({ chartSkins: { ...(cfg.chartSkins || {}), [target]: src }, multi: "mix" });
  renderSkins(); renderMedia(); syncTune(); syncCharts();
  if (target === "all" || target === 1) autoMatchPick();          // the main wallpaper changed
}
async function activeTab() {
  if (!EXT_MODE || IS_TAB || !chrome.tabs) return null;
  try { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); return tab && /^https?:/.test(tab.url || "") ? tab : null; } catch { return null; }
}
async function tabMsg(msg) {
  const tab = await activeTab(); if (!tab) return null;
  return new Promise((res) => { try { chrome.tabs.sendMessage(tab.id, msg, { frameId: 0 }, (r) => { void chrome.runtime.lastError; res(r || null); }); } catch { res(null); } });
}
// Snapshot: the owning instance (top frame on tradingview.com) answers. We message the top frame; the content
// script only replies from the owning, non-stood-down instance. (Broadcast-to-all-frames would need extra
// permissions we deliberately don't ask for, to keep the listing lean.)
async function tabMsgAnyFrame(msg) { return tabMsg(msg); }
async function detectCharts() {
  const r = await tabMsg({ ws: "layout" });
  if (r && r.count !== chartCount) { chartCount = r.count | 0; syncCharts(); }
}
const flashNumbers = (n) => tabMsg({ ws: "numbers", n }).then((r) => { if (r && r.count !== chartCount) { chartCount = r.count | 0; syncCharts(); } });
function renderPickers() {
  const show = chartCount > 1 || cfg.multi === "mix";
  document.querySelectorAll(".chartpick").forEach((box) => {
    box.hidden = !show; box.innerHTML = "";
    if (!show) return;
    box.insertAdjacentHTML("beforeend", `<span>Apply to</span>`);
    for (const t of ["all", ...Array.from({ length: chartN() }, (_, i) => i + 1)]) {
      const b = document.createElement("button");
      b.className = "chip" + (target === t ? " on" : "");
      b.textContent = t === "all" ? "All charts" : "Chart " + t;
      if (t !== "all") b.title = t === 1 ? "Top-left chart: " + srcName(mainSrc()) : srcName((cfg.chartSkins || {})[t] || mainSrc());
      b.onclick = () => { target = t; if (t !== "all") flashNumbers(t); renderSkins(); renderMedia(); renderPickers(); };
      box.appendChild(b);
    }
  });
}
function syncCharts() {
  seg("multi", [["span", "Stretch"], ["each", "Each chart"], ["mix", "Mix"]], () => cfg.multi || "span", (v) => {
    set({ multi: v }); if (v !== "mix" && typeof target === "number") target = "all"; syncCharts(); renderSkins(); renderMedia();
  });
  $("multiHint").textContent = MULTI_HINT[cfg.multi] || MULTI_HINT.span;
  // the colours of charts 2, 3, 4...: like chart 1, each matching its own wallpaper, or your own per chart
  const ccNow = () => (cfg.chartColors === "auto" || !cfg.chartColors ? (cfg.matchOnPick || cfg.wallMatch ? "wallpaper" : "same") : cfg.chartColors);
  seg("chartColors", [["same", "Same as chart 1"], ["wallpaper", "Match each wallpaper"], ["custom", "Style each chart"]], ccNow, (v) => { set({ chartColors: v }); if (v !== "custom") styleChartTo(1); syncCharts(); });
  $("chartColorsHint").textContent = ccNow() === "wallpaper" ? "Charts with their own wallpaper (Mix) take candles, indicator and zone colours, the skin accent and text tints from it. Chart 1 keeps yours."
    : ccNow() === "custom" ? "Style each chart on its own: pick a chart at the top of the Chart tab, then change candles, indicators, lines, text and the price scale for that chart only." : "Every chart uses your Chart settings.";
  renderChartBar();
  $("chartsFound").textContent = chartCount > 1 ? `${chartCount} charts on this tab.` : chartCount === 1 ? "1 chart on this tab. Open a multi-chart layout to use these." : "";
  const rows = $("chartRows"); rows.innerHTML = "";
  if (cfg.multi === "mix") {
    const opts = `<option value="">Same as chart 1</option><optgroup label="Skins">` +
      Object.entries(WickedSkins).map(([id, sk]) => `<option value="${id}">${esc(sk.name)}</option>`).join("") + `</optgroup>` +
      (cfg.media.filter((m) => !m.pending).length ? `<optgroup label="Your uploads">` + cfg.media.filter((m) => !m.pending).map((m) => `<option value="media:${m.id}">${esc(m.name)}</option>`).join("") + `</optgroup>` : "");
    for (let n = 1; n <= chartN(); n++) {
      const row = document.createElement("div"); row.className = "row";
      if (n === 1) { row.innerHTML = `<span>Chart 1</span><small class="hint" style="margin:0">${esc(srcName(mainSrc()))} (your main skin)</small>`; rows.appendChild(row); continue; }
      row.innerHTML = `<span>Chart ${n}</span><select class="field">${opts}</select>`;
      const sel = row.querySelector("select"); sel.value = (cfg.chartSkins || {})[n] || "";
      sel.onchange = () => {
        const next = { ...(cfg.chartSkins || {}) }; if (sel.value) next[n] = sel.value; else delete next[n];
        set({ chartSkins: next }); renderPickers();
      };
      sel.onfocus = () => flashNumbers(n);
      rows.appendChild(row);
    }
  }
  renderPickers();
}
// the "Styling: Chart 1 | Chart 2 ..." bar at the top of the Style tab (Style each chart)
function styleChartTo(n) {
  if (n === styleChart) return;
  if (baseStyle) Object.assign(cfg, baseStyle);                                     // back to your own (chart 1) values
  baseStyle = null; styleChart = n;
  if (n > 1) { baseStyle = Object.fromEntries([...PER_CHART_KEYS].map((k) => [k, cfg[k]])); Object.assign(cfg, (cfg.chartStyle || {})[n] || {}); flashNumbers(n); }
  refreshAll();
}
function renderChartBar() {
  const bar = $("styleChartBar"); if (!bar) return;
  const on = cfg.chartColors === "custom" && chartN() > 1;
  bar.hidden = !on; if (!on) { if (styleChart > 1) styleChartTo(1); return; }
  bar.innerHTML = "";
  const lab = document.createElement("span"); lab.className = "scb-l"; lab.textContent = "Styling"; bar.appendChild(lab);
  for (let n = 1; n <= chartN(); n++) {
    const b = document.createElement("button"); b.className = "chip" + (n === styleChart ? " on" : ""); b.type = "button";
    const own = n > 1 && Object.keys((cfg.chartStyle || {})[n] || {}).length;
    b.textContent = `Chart ${n}${own ? " \u2022" : ""}`; b.title = n === 1 ? "Your main style" : own ? "Has its own style" : "Same as chart 1 until you change something";
    b.onclick = () => { styleChartTo(n); renderChartBar(); };
    bar.appendChild(b);
  }
  if (styleChart > 1) {
    const r = document.createElement("button"); r.className = "link"; r.type = "button"; r.textContent = `Make chart ${styleChart} like chart 1`;
    r.onclick = () => { const n = styleChart, all = { ...(cfg.chartStyle || {}) }, before = cfg.chartStyle; delete all[n];
      chrome.storage.local.set({ chartStyle: all }); cfg.chartStyle = all; Object.assign(cfg, baseStyle); styleChart = 1; baseStyle = null; styleChartTo(n);
      toast(`Chart ${n} is styled like chart 1 again.`, () => { chrome.storage.local.set({ chartStyle: before }); cfg.chartStyle = before; const m = styleChart; Object.assign(cfg, baseStyle || {}); styleChart = 1; baseStyle = null; styleChartTo(m); }); };
    bar.appendChild(r);
    const hint = document.createElement("small"); hint.className = "hint"; hint.textContent = `Changes in this tab now apply to chart ${styleChart} only.`; bar.appendChild(hint);
  }
}
$("showNums").onclick = () => flashNumbers(typeof target === "number" ? target : 0);

// ---------- watermark (logo + name) ----------
function syncPnl() {
  $("pnlShow").checked = !!cfg.pnlShow;
  seg("pnlStyle", [["color", "Colour"], ["rainbow", "Rainbow"]], () => cfg.pnlStyle || "color", (v) => { set({ pnlStyle: v, pnlShow: true }); $("pnlShow").checked = true; syncPnl(); });
  $("pnlColsRow").hidden = cfg.pnlStyle === "rainbow";
  $("pnlUp").value = cfg.pnlUp || cfg.candleUp || "#00e08a"; $("pnlDown").value = cfg.pnlDown || cfg.candleDown || "#ff3355";
  seg("pnlBack", [["none", "None"], ["glass", "Glass"], ["solid", "Solid"]], () => cfg.pnlBack || "glass", (v) => set({ pnlBack: v }));
  seg("pnlSize", [[0, "S"], [1, "M"], [2, "L"]], () => (+cfg.pnlSize || 1), (v) => set({ pnlSize: v }));
  seg("pnlPos", [["tl", cornerIcon(2.5, 2.5)], ["tc", cornerIcon(5.5, 2.5)], ["tr", cornerIcon(8.5, 2.5)], ["bl", cornerIcon(2.5, 6.5)], ["br", cornerIcon(8.5, 6.5)]],
    () => cfg.pnlPos || "tc", (v) => set({ pnlPos: v }));
}
$("pnlShow").onchange = (e) => set({ pnlShow: e.target.checked });
$("pnlUp").oninput = (e) => set({ pnlUp: e.target.value });
$("pnlDown").oninput = (e) => set({ pnlDown: e.target.value });

// ---------- trade brackets (fully recolour the broker's TP / Stop / entry pills) ----------
// Each colour is Keep (leave TradingView's) or Custom (any colour). The number can also be Profit/Loss (green/red).
function bkOn() { set({ bracketOn: true }); $("bracketOn").checked = true; syncBracket(); }
function syncBracket() {
  $("bracketOn").checked = !!cfg.bracketOn;
  seg("bracketSize", [[0, "Normal"], [1, "Large"], [2, "XL"], [3, "Huge"]], () => (+cfg.bracketSize || 0), (v) => { set({ bracketSize: v }); bkOn(); });

  // Box colour: Keep | Custom
  seg("bracketFillMode", [["keep", "Keep"], ["custom", "Custom"]], () => (cfg.bracketFill ? "custom" : "keep"),
    (v) => { set({ bracketFill: v === "custom" ? ($("bracketFill").value || "#1e2130") : "" }); bkOn(); });
  $("bracketFill").value = cfg.bracketFill || "#1e2130"; $("bracketFill").hidden = !cfg.bracketFill;

  // Number colour: Keep | Custom | Profit/Loss
  const textMode = (cfg.bracketProfit || cfg.bracketLoss) ? "pl" : (cfg.bracketText ? "custom" : "keep");
  seg("bracketTextMode", [["keep", "Keep"], ["custom", "Custom"], ["pl", "Profit/Loss"]], () => textMode, (v) => {
    if (v === "keep") set({ bracketText: "", bracketProfit: "", bracketLoss: "" });
    else if (v === "custom") set({ bracketText: $("bracketText").value || "#ffffff", bracketProfit: "", bracketLoss: "" });
    else set({ bracketText: "", bracketProfit: $("bracketProfit").value || cfg.candleUp || "#00e08a", bracketLoss: $("bracketLoss").value || cfg.candleDown || "#ff3355" });
    bkOn();
  });
  $("bracketText").value = cfg.bracketText || "#ffffff"; $("bracketText").hidden = textMode !== "custom";
  $("bracketPLRow").hidden = textMode !== "pl";
  seg("bracketQtyMode", [["keep", "Keep"], ["custom", "Custom"]], () => (cfg.bracketQty ? "custom" : "keep"),
    (v) => { set({ bracketQty: v === "custom" ? ($("bracketQty").value || "#ffd166") : "" }); bkOn(); });
  $("bracketQty").value = cfg.bracketQty || "#ffd166"; $("bracketQty").hidden = !cfg.bracketQty;
  $("bracketProfit").value = cfg.bracketProfit || cfg.candleUp || "#00e08a";
  $("bracketLoss").value = cfg.bracketLoss || cfg.candleDown || "#ff3355";

  // Outline: Keep | Custom (+ width)
  seg("bracketBorderMode", [["keep", "Keep"], ["custom", "Custom"]], () => (cfg.bracketBorderColor ? "custom" : "keep"),
    (v) => { set({ bracketBorderColor: v === "custom" ? ($("bracketBorderColor").value || "#4094e8") : "", bracketBorderW: v === "custom" && !cfg.bracketBorderW ? 1 : cfg.bracketBorderW }); bkOn(); });
  $("bracketBorderColor").value = cfg.bracketBorderColor || "#4094e8"; $("bracketBorderColor").hidden = !cfg.bracketBorderColor;
  $("bracketBorderWRow").hidden = !cfg.bracketBorderColor;
  seg("bracketBorderW", [[0, "Thin"], [1, "Medium"], [2, "Thick"], [3, "Thicker"]], () => (+cfg.bracketBorderW || 0), (v) => { set({ bracketBorderW: v }); bkOn(); });

  // Level line: Keep | Custom (+ width)
  seg("bracketLineMode", [["keep", "Keep"], ["custom", "Custom"]], () => (cfg.bracketLineColor ? "custom" : "keep"),
    (v) => { set({ bracketLineColor: v === "custom" ? ($("bracketLineColor").value || "#4094e8") : "", bracketLineW: v === "custom" && !cfg.bracketLineW ? 1 : cfg.bracketLineW }); bkOn(); });
  $("bracketLineColor").value = cfg.bracketLineColor || "#4094e8"; $("bracketLineColor").hidden = !cfg.bracketLineColor;
  $("bracketLineWRow").hidden = !cfg.bracketLineColor;
  seg("bracketLineW", [[0, "Thin"], [1, "Medium"], [2, "Thick"], [3, "Thicker"]], () => (+cfg.bracketLineW || 0), (v) => { set({ bracketLineW: v }); bkOn(); });
}
$("bracketOn").onchange = (e) => set({ bracketOn: e.target.checked });
// One tap: big number on a dark box, profit green / loss red, thicker level line — readable on any wallpaper.
$("bracketEasy").onclick = () => {
  set({ bracketOn: true, bracketSize: 2, bracketBack: "solid", bracketFill: "", bracketText: "",
    bracketProfit: "#19e68c", bracketLoss: "#ff4d5e", bracketBorderColor: "", bracketBorderW: 1, bracketLineColor: "", bracketLineW: 1 });
  syncBracket(); toast && toast("TP / Stop / P&L: big, dark box, green/red numbers");
};
$("bracketFill").oninput = (e) => { set({ bracketFill: e.target.value }); bkOn(); };
$("bracketText").oninput = (e) => { set({ bracketText: e.target.value, bracketProfit: "", bracketLoss: "" }); bkOn(); };
$("bracketProfit").oninput = (e) => { set({ bracketProfit: e.target.value, bracketText: "", bracketOn: true }); };
$("bracketLoss").oninput = (e) => { set({ bracketLoss: e.target.value, bracketText: "", bracketOn: true }); };
$("bracketBorderColor").oninput = (e) => { set({ bracketBorderColor: e.target.value, bracketBorderW: cfg.bracketBorderW || 1 }); bkOn(); };
$("bracketLineColor").oninput = (e) => { set({ bracketLineColor: e.target.value, bracketLineW: cfg.bracketLineW || 1 }); bkOn(); };

// Diagnose: read, from the TradingView tab's page, which pills the hook actually caught — shown right here so the
// user never needs the console. If it caught pills but they didn't restyle, that tells us it's a styling bug; if
// it caught nothing, the pills draw in a way we don't yet detect (and we show what text IS on the chart).
if ($("bracketDiag")) $("bracketDiag").onclick = async () => {
  const out = $("bracketDiagOut");
  out.style.display = ""; out.textContent = "Looking at your chart…";
  if (!EXT_MODE || IS_TAB || !chrome.tabs || !chrome.scripting) { out.textContent = "Open this on a TradingView chart tab to diagnose."; return; }
  let tab; try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch {}
  if (!tab || !/^https?:/.test(tab.url || "")) { out.textContent = "Open your TradingView chart, then click again."; return; }
  // make sure brackets + debug are on so the hook is recording
  set({ bracketOn: true, bracketDebug: true }); $("bracketOn").checked = true;
  try {
    // 1) install a one-shot probe in the page that samples in-chart text (and reset its buffer each run)
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true }, world: "MAIN",
      func: () => {
        try {
          const C = CanvasRenderingContext2D.prototype;
          window.__bdDiagSeen = []; window.__bdDiagWhere = {};
          // where is each number drawn? pane = the chart, overlay = another canvas in the chart area,
          // axis = price/time scale, hidden = a canvas not on the page (drawn once, pasted later), other = elsewhere
          const where = (c) => { try { if (!c || !c.isConnected) return "hidden"; if (c.closest("[class*=price-axis],[class*=time-axis]")) return "axis";
            if (c.closest(".chart-markup-table")) return "pane"; if (c.closest(".chart-container, .layout__area--center")) return "overlay"; return "other"; } catch { return "hidden"; } };
          const note = (t, font, align, c) => {
            const s = String(t); if (!/[0-9]/.test(s) || !window.__bdDiagSeen) return;
            const w = where(c); window.__bdDiagWhere[w] = (window.__bdDiagWhere[w] || 0) + 1;
            if (w === "axis" && window.__bdDiagSeen.filter((x) => x.w === "axis").length >= 3) return;   // a few scale labels are enough
            const key = s.slice(0, 16) + font + w;
            if (window.__bdDiagSeen.length < 40 && !window.__bdDiagSeen.some((x) => x.k === key)) window.__bdDiagSeen.push({ k: key, t: s.slice(0, 16), f: font, a: align, w });
          };
          if (!window.__bdDiagProbe) {
            window.__bdDiagProbe = 1; const o = C.fillText;
            C.fillText = function (t) { try { note(t, this.font, this.textAlign, this.canvas); } catch {} return o.apply(this, arguments); };
            if (typeof OffscreenCanvasRenderingContext2D !== "undefined") { const OP = OffscreenCanvasRenderingContext2D.prototype, oo = OP.fillText;
              OP.fillText = function (t) { try { note(t, this.font, this.textAlign, null); } catch {} return oo.apply(this, arguments); }; }
            const di = C.drawImage;
            C.drawImage = function (img) { try { if (img && img.tagName === "CANVAS" && !img.isConnected && this.canvas && this.canvas.isConnected) { const w = where(this.canvas); window.__bdDiagWhere["pasted-" + w] = (window.__bdDiagWhere["pasted-" + w] || 0) + 1; } } catch {} return di.apply(this, arguments); };
          }        } catch {}
      },
    });
    // nudge the chart so it repaints into our probe (TradingView's own soft redraw), then wait a beat
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, world: "MAIN", func: () => { try { document.dispatchEvent(new Event("bd-softrepaint")); window.dispatchEvent(new Event("resize")); } catch {} } }).catch(() => {});
    await new Promise((r) => setTimeout(r, 2200));
    // 2) read what the hook caught + what the probe saw (across all frames; pick the richest result)
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true }, world: "MAIN",
      func: () => {
        const d = window.__bdBracketDebug;
        // Which chart engine is this? Advanced Charts has TradingViewApi + .chart-markup-table; Lightweight Charts
        // has a .tv-lightweight-charts wrapper (and/or a LightweightCharts global) and no TradingViewApi.
        let engine = "unknown";
        try {
          const adv = !!(window.TradingViewApi || window.tradingViewApi || document.querySelector(".chart-markup-table, .chart-container"));
          const lw = !!(window.LightweightCharts || document.querySelector(".tv-lightweight-charts, [class*='lightweight']"))
            || [...document.querySelectorAll("canvas")].some((c) => c.parentElement && /lightweight|tv-lw|lw-chart/i.test(c.parentElement.className || ""));
          if (adv) engine = "advanced";
          else if (lw) engine = "lightweight";
        } catch {}
        const canvases = (() => { try { return [...document.querySelectorAll("canvas")].filter((c) => { const r = c.getBoundingClientRect(); return r.width > 150 && r.height > 120; }).length; } catch { return 0; } })();
        // facts about a Lightweight-Charts style page (read-only): is our adapter running, is the wallpaper mounted, and what
        // sits between the wallpaper and the screen (an opaque box there is what hides it)
        let lw = null, layer = null, stack = [];
        try { lw = window.__bdLwInfo ? window.__bdLwInfo() : null; } catch {}
        try {
          const l = document.getElementById("bd-layer");
          if (l) { const r = l.getBoundingClientRect(); layer = { inside: l.parentElement ? l.parentElement.tagName.toLowerCase() + (l.parentElement.id ? "#" + l.parentElement.id : "") : "", w: Math.round(r.width), h: Math.round(r.height), embedded: l.classList.contains("bd-embedded") }; }
          const cv = [...document.querySelectorAll("canvas")].filter((c) => { const r = c.getBoundingClientRect(); return r.width > 250 && r.height > 150; }).sort((a, b) => b.width * b.height - a.width * a.height)[0];
          if (cv) { const r = cv.getBoundingClientRect(); let e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2), n = 0;
            while (e && n++ < 7) { const bg = getComputedStyle(e).backgroundColor; stack.push(e.tagName.toLowerCase() + (e.id ? "#" + e.id : "") + (typeof e.className === "string" && e.className ? "." + e.className.split(" ")[0].slice(0, 24) : "") + (bg && !/rgba?\(0, 0, 0, 0\)|transparent/.test(bg) ? " [" + bg + "]" : "")); e = e.parentElement; } }
        } catch {}
        // labels made of page elements (HTML) over the chart, instead of canvas drawing
        const dom = [];
        try { const area = document.querySelector(".chart-container, .layout__area--center"); const ar = area && area.getBoundingClientRect();
          if (ar) for (const e of area.querySelectorAll("div, span")) { if (e.children.length || dom.length >= 6) continue; const t = (e.textContent || "").trim();
            if (!/^[+\-\u2212]?\s*[$\u20ac\u00a3]?\s*[\d,.]+/.test(t) || t.length > 16) continue; const r = e.getBoundingClientRect();
            if (r.width > 4 && r.height > 6 && r.height < 40 && r.left >= ar.left && r.right <= ar.right - 40) dom.push(t + " [" + getComputedStyle(e).font.slice(0, 40) + "]"); } } catch {}
        return { hooked: !!window.__bdHooked, ver: window.__bdHookVer || null, caught: d ? d.samples : null, onChart: window.__bdDiagSeen || [], where: window.__bdDiagWhere || {},
          paths: window.__bdBracketPaths || null, dom, engine, canvases, lw, layer, stack, frame: location.hostname };
      },
    });
    const score = (x) => x && x.result ? ((x.result.caught ? x.result.caught.length * 100 : 0) + (x.result.onChart ? x.result.onChart.length : 0) + (x.result.engine && x.result.engine !== "unknown" ? 5 : 0) + (x.result.hooked ? 1 : 0)) : -1;
    const best = (results || []).sort((a, b) => score(b) - score(a))[0];
    const r = best && best.result;
    if (!r) { out.textContent = "Couldn't read the chart. Make sure Priism Skins is on for this tab."; return; }
    // Lightweight Charts (custom apps like nq.vision): wallpaper + candle colours are supported; there are no broker pills.
    if (r.engine === "lightweight" || (r.lw && r.lw.active)) {
      const L = r.lw;
      const facts = [
        `adapter ${L && L.active ? "ON" : "NOT running"}`,
        `wallpaper ${r.layer ? (r.layer.embedded ? "mounted inside the chart box" : "mounted behind the page") + ` (${r.layer.w}\u00D7${r.layer.h})` : "NOT mounted"}`,
        L && L.candles ? `candle colours set (${L.candles.up}/${L.candles.down})` : "candle colours: not enabled (Style \u2192 Candles)",
        L && L.sides ? `${L.sides.length} candle colours known, learned: ${L.learned.map((x) => x[0] + " " + x[1]).join(", ") || "none yet"}` : "",
        L && L.mono && L.mono.length ? `candles found by shape: ${L.mono.map((x) => x[0] + " " + x[1]).join(", ")}` : "",
        `${r.canvases} chart canvas(es)`,
        L && L.drawCalls ? `draws: ${L.drawCalls.fillRect || 0} rect, ${L.drawCalls.fill || 0} path, ${L.drawCalls.pathLook || 0} path-looks, ${L.drawCalls.lines || 0} lines` : "",
        L && L.lastTally && L.lastTally.length ? `most drawn: ${L.lastTally.slice(0, 4).map((x) => x[0] + "\u00D7" + x[1]).join(", ")}` : "",
        r.stack && r.stack.length ? `over the chart: ${r.stack.join(" < ")}` : "",
      ].filter(Boolean).join(" \u00B7 ");
      out.textContent = `Lightweight Charts detected. Wallpaper and candle colours are supported here (broker pills are not, that chart has none). ${facts}. If something isn't showing, copy this whole message and send it to me.`;
      return;
    }
    if (!r.hooked && r.engine !== "advanced") {
      out.textContent = `No TradingView chart detected on this page${r.canvases ? ` (${r.canvases} canvas chart(s), but not one I recognise)` : ""}. ${r.stack && r.stack.length ? `Over the chart: ${r.stack.join(" < ")}. ` : ""}Copy this and send it to me.`;
      return;
    }
    if (!r.hooked) { out.textContent = "The skin engine isn't active on this tab yet. Turn Priism Skins on here, let the chart load, then click again."; return; }
    if (r.caught && r.caught.length) {
      const list = r.caught.slice(0, 6).map((s) => `“${s.text}” (${s.font}${s.box ? "" : ", no box"})`).join("; ");
      out.textContent = `Caught ${r.caught.length} pill(s): ${list}. If these aren't restyling, tell me and paste this text.`;
    } else if (r.paths && (r.paths.pasted.length || r.paths.hidden.length)) {
      const p = r.paths;
      out.textContent = `Your labels are drawn once and pasted onto the chart; restyling now handles that${p.pasted.length ? ` (${p.pasted.length} styled: ${p.pasted.slice(0, 4).map((x) => "\u201c" + x.t + "\u201d").join(", ")})` : ""}. If they still look unchanged, copy this and send it to me. Site: ${r.frame}. Seen: ${JSON.stringify(r.where)}.`;
    } else if ((r.onChart && r.onChart.length) || (r.dom && r.dom.length)) {
      const nonAxis = (r.onChart || []).filter((s) => s.w !== "axis");
      const list = (nonAxis.length ? nonAxis : r.onChart || []).slice(0, 8).map((s) => `\u201c${s.t}\u201d [${s.w}, ${s.f}]`).join("; ");
      out.textContent = `No pills matched yet. Site: ${r.frame}. Numbers drawn: ${JSON.stringify(r.where)}. ${list ? "Samples: " + list + "." : ""}${r.dom && r.dom.length ? " Labels made of page elements: " + r.dom.join("; ") + "." : ""} Keep a trade or order open, click Diagnose again, then copy this and send it to me.`;
    } else {
      out.textContent = "No chart text seen yet. Make sure a position/order is open on the chart, wait a moment, then click again.";
    }
  } catch (e) { out.textContent = "Diagnose failed: " + (e && e.message ? e.message : "unknown") + ". Send me a screenshot of the pills instead."; }
};

function syncWatermark() {
  $("wmOn").checked = cfg.wmOn;
  $("wmText").value = cfg.wmText || "";
  seg("wmStyle", [["corner", "Corner"], ["tiled", "Tiled"]], () => cfg.wmStyle, (v) => { set({ wmStyle: v, wmOn: true }); $("wmOn").checked = true; syncWatermark(); });
  const tiled = cfg.wmStyle === "tiled";
  $("wmPosRow").hidden = tiled;
  $("wmDriftRow").hidden = tiled;
  seg("wmPos", [["tl", cornerIcon(2.5, 2.5)], ["tr", cornerIcon(8.5, 2.5)], ["center", cornerIcon(5.5, 4.5)], ["bl", cornerIcon(2.5, 6.5)], ["br", cornerIcon(8.5, 6.5)]],
    () => cfg.wmPos, (v) => { set({ wmPos: v, wmOn: true }); $("wmOn").checked = true; });
  seg("wmDrift", [[false, "Fixed"], [true, "Drift"]], () => !!cfg.wmDrift, (v) => set({ wmDrift: v }));
  $("wmOpacity").value = cfg.wmOpacity; $("wmOpacityOut").textContent = Math.round(cfg.wmOpacity * 100) + "%";
}
$("wmOn").onchange = (e) => set({ wmOn: e.target.checked });
$("wmText").oninput = (e) => set({ wmText: e.target.value.slice(0, 40), wmOn: cfg.wmOn || !!e.target.value });
$("wmOpacity").oninput = (e) => { set({ wmOpacity: +e.target.value }); $("wmOpacityOut").textContent = Math.round(+e.target.value * 100) + "%"; };

const ADJUST_KEYS = ["opacity","overOpacity","dim","blur","vividness","tint","speed","fps","res","fit","posX","posY","powerSaver","paused","bw","layer","sides","leftBar","uiFont","uiSize","uiAccent","react","reactStrength","moodLook","moodRange","moodPulse","lensZoom","lensSize","musicParts","musicFeel","musicSens","vignette","calm"];
const STYLE_KEYS = [...CHART_KEYS, "atmoFx","atmoTrail","atmoAura","atmoColor","atmoCustom","atmoOpacity","atmoLen","atmoFade","zoneFx","candleOn","candleUp","candleDown","candleGlow","candlePreset","candleLook","candleClosedLook","candleFxCore","candleFxEdge","candleFxAmt","shiftSpeed","lineGlow","scaleText","scaleGlow","scaleBold","scaleBg","scaleBgColor","scaleLabels","scaleSize","scaleFont","bracketOn","bracketSize","bracketBack","bracketFill","bracketText","bracketProfit","bracketLoss","bracketBorderColor","bracketBorderW","bracketLineColor","bracketLineW"];
$("reset").onclick = () => applyWithUndo(Object.fromEntries(ADJUST_KEYS.map((k) => [k, DEFAULTS[k]])), "Adjustments reset.");
$("resetStyle").onclick = () => applyWithUndo(Object.fromEntries(STYLE_KEYS.map((k) => [k, DEFAULTS[k]])), "Style reset.");

// ---------- other sites (prop-firm platforms with TradingView charts, e.g. TopstepX) ----------
// Looks at the page you're on; if it has a TradingView-style chart, offers to turn on there.
const BUILT_IN = /(^|\.)tradingview\.com$/;
// "Check this page": what Priism sees in every frame of the tab (is it on there, which copy, the charts, and anything on
// the page that changes colours, like a CSS filter the platform puts on its charts). Plain words, plus a copyable report.
async function checkPage(tab, host) {
  const out = $("pageCheckOut"); out.hidden = false; out.textContent = "Checking\u2026";
  let rs = [];
  try { rs = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => {
    const h = document.documentElement, owner = (h.getAttribute("data-bd-owner") || "").split("|");
    const charts = [...document.querySelectorAll(".chart-container, .tv-lightweight-charts, [data-bd-lwroot]")].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 150 && r.height > 100; });
    const filters = new Set();   // colour-changing CSS on the chart or anything around it
    const look = (el) => { for (let e = el; e && e.nodeType === 1; e = e.parentElement) { const cs = getComputedStyle(e);
      for (const p of ["filter", "backdropFilter", "mixBlendMode"]) { const v = cs[p]; if (v && v !== "none" && v !== "normal") filters.add(`${e.tagName.toLowerCase()}${e.id ? "#" + e.id : ""} ${p}: ${v}`.slice(0, 120)); } } };
    charts.slice(0, 4).forEach(look); look(document.body);
    let fx = null; try { fx = JSON.parse(h.getAttribute("data-ws-fx") || "null"); } catch {}
    return { url: location.origin, top: window === window.top, on: h.classList.contains("bd-on"), owner: owner[0] || "", ver: owner[1] || "",
      charts: charts.length, theme: (h.className.match(/theme-\w+/) || [""])[0], filters: [...filters].slice(0, 6), fx: !!fx, hz: h.getAttribute("data-bd-q") || "" };
  } }); } catch (e) { out.textContent = "Couldn't check this page: " + (e.message || e); return; }
  const frames = rs.map((r) => r.result).filter(Boolean), withCharts = frames.filter((f) => f.charts), me = chrome.runtime.id;
  const lines = [];
  if (!withCharts.length) lines.push("No chart found on this page yet. Open a chart, then check again.");
  for (const f of withCharts) {
    const where = f.top ? host : new URL(f.url).host;
    if (!f.on) lines.push(`\u2716 Priism isn't running on the chart (${where}). Tap Turn off, then Turn on here again, and allow it.`);
    else if (f.owner && f.owner !== me) lines.push(`\u2716 Another copy of Priism (v${f.ver}) is drawing this chart, so your settings here don't reach it. Remove the extra copy in chrome://extensions.`);
    else lines.push(`\u2714 Priism is on the chart (${f.charts} chart${f.charts > 1 ? "s" : ""}, ${where}).`);
    if (f.filters.length) lines.push(`\u26a0 The platform changes colours on its charts with a filter, which tints the wallpaper and your colours too: ${f.filters.join("; ")}`);
  }
  const report = "Priism " + chrome.runtime.getManifest().version + " on " + host + "\n" + JSON.stringify(frames);
  out.innerHTML = `<b>This page</b><ul style="margin:6px 0;padding-left:16px">${lines.map((l) => `<li>${esc(l)}</li>`).join("")}</ul><button class="link" id="pageCheckCopy">Copy the details (to send to support)</button>`;
  $("pageCheckCopy").onclick = async () => { const ok = await copyText(report); $("pageCheckCopy").textContent = ok ? "Copied" : "Couldn't copy"; };
}
async function siteBar() {
  if (!EXT_MODE || IS_TAB || !chrome.tabs || !chrome.scripting) return;
  const bar = $("siteBar");
  let tab; try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch { return; }
  if (!tab || !/^https?:/.test(tab.url || "")) return;
  const url = new URL(tab.url), origin = url.origin, host = url.hostname.replace(/^www\./, "");
  if (BUILT_IN.test(url.hostname)) return;                       // always on there
  const show = (cls, title, hintText, btn, onClick) => {
    bar.hidden = false; bar.className = "sitebar" + (cls ? " " + cls : "");
    $("siteTitle").textContent = title; $("siteHint").textContent = hintText;
    $("siteBtn").textContent = btn; $("siteBtn").onclick = onClick;
  };
  const enabled = await WickedSites.find(origin);
  if (enabled) {
    $("pageCheck").hidden = false; $("pageCheck").onclick = () => checkPage(tab, host);
    // a Lightweight Charts platform (lw.js marks it): hide the options that only style TradingView's own interface
    chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => document.documentElement.getAttribute("data-bd-lw") === "on" })
      .then((rs) => { if (rs.some((r) => r.result)) document.body.classList.add("lw-page"); }).catch(() => {});
    return show("on", `On for ${host}`, "Wallpaper, candles, candle looks and chart lines (Chart tab) work here. The TradingView tab styles TradingView's own panels and menus; this platform's own layout around the chart stays as it is.", "Turn off", async () => {
      await WickedSites.disable(enabled.origin); chrome.tabs.reload(tab.id); window.close();
    });
  }
  // Detect a chart: in the page, in same-origin chart iframes, or by an iframe that loads a charting library.
  let found = { chart: false, frames: [] };
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const SEL = ".chart-markup-table, .chart-container";
      let chart = !!document.querySelector(SEL); const frames = new Set();
      for (const f of document.querySelectorAll("iframe")) {
        try { if (f.contentDocument && f.contentDocument.querySelector(SEL)) chart = true; } catch {}
        const src = f.src || "";
        if (/charting_library|tradingview|tv[-_]?chart/i.test(src) || /^tradingview_/i.test(f.id || "") || /tradingview/i.test(f.name || "")) {
          chart = true;
          try { const o = new URL(src, location.href).origin; if (/^https?:/.test(o) && o !== location.origin) frames.add(o); } catch {}
        }
      }
      if (window.TradingView || window.tvWidget) chart = true;
      return { chart, frames: [...frames] };
    } });
    found = res.result || found;
  } catch {}
  const turnOn = async () => {
    const origins = [origin, ...found.frames];
    // Chrome's permission prompt often closes this panel before the answer comes back, which is why it used to take
    // two clicks. So the background worker is told what we're turning on, and finishes the job itself if we're gone.
    await chrome.storage.local.set({ pendingSite: { origin, frames: found.frames, tabId: tab.id, t: Date.now() } });
    const ok = await chrome.permissions.request({ origins: origins.map((o) => o + "/*") });  // Chrome shows its prompt here
    if (!ok) { chrome.storage.local.remove("pendingSite"); $("siteHint").textContent = "Not turned on: Chrome's permission was declined."; return; }
    await chrome.storage.local.remove("pendingSite");
    await WickedSites.enable(origin, found.frames);
    chrome.tabs.reload(tab.id); window.close();
  };
  if (found.chart) {
    show("", `Chart found on ${host}`, "Chrome will ask to let Priism Skins \u201cread and change\u201d this site. That's Chrome's standard wording for drawing on a page; it only paints the chart and never reads your account or orders.", "Turn on here", turnOn);
  } else {
    show("", `No TradingView chart found on ${host}`, "Open a chart on this site first, or turn it on anyway if the chart loads later.", "Turn on anyway", turnOn);
  }
}

// ---------- updates ----------
// Store installs are updated by Chrome automatically; we just say what's new afterwards.
// Zip / "Load unpacked" installs can't auto-update, so we check GitHub Releases (max every 6 h) and offer the download.
const REPO = "arcuto29/wicked-skins";
const RELEASES = `https://github.com/${REPO}/releases`;
const STORE_URL = "https://chromewebstore.google.com/detail/priism-skins-for-tradingv/ilmoloilbeblmgkanbiekhdegagfdloa";
// this copy's version: the extension's manifest, or the desktop app's (its preload passes it in)
const APP_VER = (() => { try { const v = chrome.runtime.getManifest().version; if (v) return v; } catch {}
  return (window.wickedStore && window.wickedStore.app && window.wickedStore.app.version) || ""; })();
const newer = (a, b) => { const x = a.split(".").map(Number), y = b.split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
function notice(title, hintText, linkText, href, onClose) {
  const n = $("notice"); n.hidden = false;
  $("noticeTitle").textContent = title; $("noticeHint").textContent = hintText;
  $("noticeLink").textContent = linkText; $("noticeLink").href = href;
  $("noticeClose").innerHTML = ICON_X; $("noticeClose").onclick = () => { n.hidden = true; onClose && onClose(); };
}
function deskUpdates() {
  const a = window.wickedStore && window.wickedStore.app; if (!a || IS_TAB) return;
  const offer = (p) => {
    if (!p || !p.version || !newer(p.version, APP_VER) || PriismUpdateCard.isOpen()) return;
    if (sessionStorage.getItem("updLater") === p.version) return;          // "Not now": not again until the app restarts
    PriismUpdateCard.show({ mode: "ready", from: APP_VER, to: p.version, primary: "Restart & update",
      lead: "Downloaded and ready. Priism restarts in a few seconds and reopens your chart tabs where you left them.",
      foot: "Not now? It installs by itself next time you close Priism.",
      onPrimary: () => a.install(), onLater: () => sessionStorage.setItem("updLater", p.version) });
  };
  a.pending().then(offer).catch(() => {});
  a.onReady(offer);
}
async function updates() {
  if (!EXT_MODE || IS_TAB) return;
  const me = chrome.runtime.getManifest().version;
  if (window.WickedMigrate) await WickedMigrate.run().catch(() => {});
  // Another copy of the extension drew on a chart recently (content.js reports it).
  const { dupSeen } = await chrome.storage.local.get("dupSeen");
  if (dupSeen && Date.now() - dupSeen < 3 * 86400e3) {
    notice("Two copies of Priism Skins are installed", `Remove the older one so they don't fight (keep version ${me}). It's under chrome://extensions.`,
      "Open extensions", "#", () => chrome.storage.local.remove("dupSeen"));
    $("noticeLink").onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: "chrome://extensions" }); };
    return;
  }
  // after an update the "Updated" card says what's new (onboarding below), so the old one-line notice just clears
  const { justUpdated } = await chrome.storage.local.get("justUpdated");
  if (justUpdated) chrome.storage.local.remove("justUpdated");
  // Store installs: Chrome downloads updates by itself. When one is waiting (bg.js hears onUpdateAvailable), offer
  // to apply it now; bg.js then refreshes the open charts in place, so TradingView never reloads.
  if ("update_url" in chrome.runtime.getManifest()) {
    const { updateReady: u, updAsk } = await chrome.storage.local.get(["updateReady", "updAsk"]);
    if (u && u.version && newer(u.version, me)) {
      if (!(updAsk && updAsk.v === u.version && Date.now() - updAsk.at < 12 * 3600e3) && !PriismUpdateCard.isOpen())
        PriismUpdateCard.show({ mode: "ready", from: me, to: u.version,
          foot: "Your TradingView tabs stay open. No page refresh.",
          onPrimary: () => { chrome.storage.local.remove("updateReady"); chrome.runtime.reload(); },
          onLater: () => chrome.storage.local.set({ updAsk: { v: u.version, at: Date.now() } }) });
      return;
    }
    // ask Chrome to look for an update now and then (it also checks by itself every few hours)
    const { updPoke } = await chrome.storage.local.get("updPoke");
    if (!updPoke || Date.now() - updPoke > 3 * 3600e3) {
      chrome.storage.local.set({ updPoke: Date.now() });
      try { const r = chrome.runtime.requestUpdateCheck && chrome.runtime.requestUpdateCheck(); if (r && r.catch) r.catch(() => {}); } catch {}
    }
    return;
  }
  // (the Chrome Web Store adds update_url to the manifest of store installs; zip/unpacked installs, below, don't have it)
  const { updCheck } = await chrome.storage.local.get("updCheck");
  let latest = updCheck && Date.now() - updCheck.at < 6 * 3600e3 ? updCheck.latest : null;
  if (!latest) {
    try {
      const r = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, { headers: { Accept: "application/vnd.github+json" } });
      if (r.ok) latest = String((await r.json()).tag_name || "").replace(/^v/, "");
    } catch {}
    if (latest) chrome.storage.local.set({ updCheck: { at: Date.now(), latest } });
  }
  if (latest && newer(latest, me)) {
    // the easiest fix is the store copy, which updates itself from then on (remove this copy afterwards)
    notice(`Update available: ${latest}`, "Get Priism Skins from the Chrome Web Store and it updates itself from now on (then remove this copy in chrome://extensions). Or download the new zip and reload it as before.",
      "Chrome Web Store", STORE_URL);
  }
}

// ---------- plans: an invite code or a Pro licence key, or Free (src/pass.js, src/invite.js) ----------
// No plan yet: the gate covers the panel (and content.js draws nothing). Free (when it's open): the panel works, and
// what's Pro shows a PRO tag and asks you to upgrade instead. The code / key is re-checked now and then (bg.js daily,
// here when the panel opens if it's been a day). The chart holds Pro settings back on Free by itself (content.js);
// the locks here just say so instead of letting a control seem to do nothing.
const storeUrl = () => (PP && PP.STORE_URL) || (window.WORKSHOP_CONFIG && WORKSHOP_CONFIG.storeUrl) || "";
function openStore() { const u = storeUrl(); if (!u) { toast("The Priism Pro store opens soon."); return; } try { if (EXT_MODE && chrome.tabs) chrome.tabs.create({ url: u }); else window.open(u, "_blank"); } catch { window.open(u, "_blank"); } }
function proOnly(what) { toast(`${what} ${/s$/.test(what) ? "are" : "is"} part of Priism Pro.`, openStore, "Get Pro"); }
// Pro parts of the panel on Free: whole tabs, sections and rows (made inert, with a PRO chip that explains)
const PRO_TABS = ["tab-interface", "tab-trading", "tab-capture", "tab-workshop", "tab-loadouts", "tab-media"];
const PRO_GRPS = ["wallopts", "motion", "charts", "sessions", "symbols", "candlefx", "chart", "scale", "patterns", "lens"];
const PRO_ROWS = ["candleLook", "closedRow", "shiftRow", "candleWick", "candleBorder", "candleBorderW", "candleHollow", "candleWickW", "candleBodyW", "partsPreview", "atmoAura", "vignetteAt", "smartDim", "matchAll", "styleChartBar", "autoMatch", "keepBg"];
function proLock(el, what) {
  if (!el || el.classList.contains("pro-locked")) return;
  el.classList.add("pro-locked"); el.inert = true;
  const chip = document.createElement("button"); chip.className = "pro-chip"; chip.type = "button"; chip.textContent = "PRO";
  chip.title = "Part of Priism Pro"; chip.onclick = () => proOnly(what || "This");
  el.before(chip);
}
function applyLocks() {
  document.querySelectorAll(".pro-chip").forEach((c) => c.remove());
  document.querySelectorAll(".pro-locked").forEach((el) => { el.classList.remove("pro-locked"); el.inert = false; });
  document.body.classList.toggle("plan-free", PLAN === "free");
  if (PLAN !== "free") return;
  for (const id of PRO_TABS) { const t = $(id); if (t) for (const el of [...t.children]) proLock(el, "This tab"); }
  for (const g of PRO_GRPS) document.querySelectorAll(`details.grp[data-grp="${g}"]`).forEach((el) => proLock(el, (el.querySelector("summary") || {}).textContent || "This"));
  for (const id of PRO_ROWS) { const el = $(id); if (el) proLock(el.closest(".row") || el, "This"); }
  document.querySelectorAll("#sliders .row[data-key]").forEach((r) => { if (PP.isPro(r.dataset.key)) proLock(r, "This"); });
}
// cards that are drawn again and again (wallpapers, looks, Candle FX mixes, your saved candles): one listener
document.addEventListener("click", (e) => {
  if (PLAN !== "free") return;
  const c = e.target.closest && e.target.closest("#skinCards .card.pro, #quickLooks .card, #candleCards .fxmixcard, #candleCards .card.preset.mine, #candleCards .card.preset.save");
  if (!c) return;
  e.preventDefault(); e.stopImmediatePropagation();
  proOnly(c.closest("#skinCards") ? "Every wallpaper" : c.closest("#quickLooks") ? "Looks" : "Candle FX and saved styles");
}, true);
async function readPlan() {
  const s = await new Promise((r) => chrome.storage.local.get({ invite: null, pass: "", deviceId: "" }, r));
  const info = PP ? await PP.verify(s.pass, s.deviceId) : null;
  PLAN = PP ? PP.planOf(info, s.invite) : PriismInvite.isOk(s.invite) ? "pro" : "none";
  planInfo = { info, invite: s.invite };
  return s.invite;
}
function renderPlan() {
  const box = $("planBox"); if (!box) return;
  const inv = planInfo && planInfo.invite, info = planInfo && planInfo.info, life = (info && info.plan === "lifetime") || (inv && inv.plan === "lifetime");
  const until = (info && info.until) || (inv && inv.until), invite = info ? info.src === "invite" : inv && !inv.manage;
  const when = until ? new Date(until).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "";
  $("planName").textContent = PLAN === "pro" ? (life ? "Priism Pro \u00B7 Lifetime" : invite ? "Priism Pro \u00B7 invite" : "Priism Pro") : PLAN === "free" ? "Priism Free" : "No plan";
  $("planHint").textContent = PLAN === "pro" ? (life ? "Yours for good, with every update." : when ? `Renews ${when}.` : "Everything is unlocked.")
    : `6 wallpapers and candle colours, with the Priism watermark. Pro unlocks all ${Object.keys(WickedSkins).length} wallpapers, Signature looks, candle styles and FX, zones, the TradingView tab, trading tools and clips.`;
  $("planGet").hidden = PLAN === "pro"; $("planKey").hidden = PLAN === "pro";
  $("planManage").hidden = !(inv && inv.manage); $("planManage").onclick = () => { try { chrome.tabs.create({ url: inv.manage }); } catch { window.open(inv.manage, "_blank"); } };
  $("planOut").hidden = !(inv && inv.code);
  $("proBar").hidden = PLAN !== "free";
}
async function inviteGate() {
  if (!window.PriismInvite) return;
  const gate = $("inviteGate");
  const show = async (force) => {
    const was = PLAN, inv = await readPlan();
    gate.hidden = PLAN !== "none" && !force; $("igClose").hidden = PLAN === "none";
    applyLocks(); renderPlan();
    if (PLAN !== was) setTimeout(() => { try { renderSkins(); renderQuick(); } catch {} }, 0);   // PRO tags on / off
    if (!gate.hidden) {
      const why = inv && inv.status === "revoked" ? "This code has been turned off. Enter a new one, or get Priism Pro."
        : inv && inv.status === "expired" ? "Your Priism Pro membership has ended. Renew it on Whop, or enter another key."
        : inv && inv.status === "invalid" ? "Your code or key isn't valid any more. Enter a new one." : "Enter your Priism Pro licence key or an invite code.";
      $("igLead").textContent = why; setTimeout(() => $("igCode").focus(), 50);
    }
  };
  await show();
  const { invite } = await new Promise((r) => chrome.storage.local.get({ invite: null }, r));
  if (invite && invite.code) PriismInvite.recheck(false).then(() => show()).catch(() => {});
  const go = async () => {
    const code = $("igCode").value.trim(), msg = $("igMsg");
    if (code.replace(/[^A-Za-z0-9]/g, "").length < 6) { msg.className = "hint bad"; msg.textContent = "That doesn't look like a licence key or invite code."; return; }
    $("igGo").disabled = true; msg.className = "hint"; msg.textContent = "Checking\u2026";
    const r = await PriismInvite.redeem(code);
    $("igGo").disabled = false;
    if (r.ok) { msg.textContent = ""; $("igCode").value = ""; await show(); toast(r.plan === "lifetime" ? "Priism Pro Lifetime is unlocked. Enjoy!" : "Priism Pro is unlocked. Enjoy!"); return; }
    msg.className = "hint bad";
    msg.textContent = r.status === "invalid" ? "That code or key isn't right. Check it and try again." : r.status === "revoked" ? "That code has been turned off."
      : r.status === "expired" ? "That membership has ended. Renew it on Whop to unlock Pro again."
      : r.status === "full" ? "That code or key is already used on its maximum number of devices. With a Pro key, sign out on one of them first (Settings \u203a Plan)." : "Couldn't reach the server. Check your internet and try again.";
  };
  $("igGo").onclick = go; $("igCode").onkeydown = (e) => { if (e.key === "Enter") go(); };
  $("igGet").onclick = openStore; $("igClose").onclick = () => (gate.hidden = true);
  $("planGet").onclick = openStore; $("proBarGet").onclick = openStore;
  $("planKey").onclick = $("proBarKey").onclick = () => show(true);
  $("planOut").onclick = async () => { if (!confirm("Sign out of Priism Pro on this device? This frees it for another device; you can enter your key again any time.")) return;
    await PriismInvite.release(); await show(); toast("Signed out on this device."); };
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && (ch.invite || ch.pass)) show(); }); } catch {}
}
inviteGate();

// ---------- master switch + boot ----------
$("enabled").onchange = (e) => { set({ enabled: e.target.checked }); $("status").textContent = e.target.checked ? "On" : "Off"; };
chrome.storage.local.get(DEFAULTS, (stored) => {
  cfg = { ...DEFAULTS, ...stored };
  $("enabled").checked = cfg.enabled; $("status").textContent = cfg.enabled ? "On" : "Off";
  renderChartStyle(); syncPanels(); syncPatterns(); syncTradePanel(); syncSkinView(); syncShortcuts(); syncTimer(); syncExtras();
  if (+cfg.clipLen) clipSecs = [5, 10, 30, 60, 120].includes(+cfg.clipLen) ? +cfg.clipLen : clipSecs;
  renderSkins(); renderMedia(); renderLoadouts(); syncTune(); renderCandles(); syncWatermark(); renderQuick(); initWorkshop(); syncSessions(); syncSymbols(); syncCharts(); syncPnl(); syncBracket(); syncGoal(); renderJournal(); if ($("clipMode")) syncClipMode();
  siteBar();
  deskCard(); if (DESK && !IS_TAB) { setupDesk(); renderSkins(); renderQuick(); }
  detectCharts();
  updates(); deskUpdates();
  const q = new URLSearchParams(location.search);
  if (q.get("page")) {
    document.body.classList.add("page");
    const pg = q.get("page") === "media" ? "skins" : q.get("page");          // Uploads now lives in Skins > My uploads
    if (q.get("page") === "media") { skinView = "mine"; localStorage.setItem("skinView", "mine"); }
    const b = document.querySelector(`#nav button[data-tab="${pg}"]`); b && b.click(); if (q.get("page") === "media") syncSkinView();
    if (q.has("pick")) hint("Click “Add video / image” or drop files here.");
    convertPending();
  }
});

// ---------- Find a setting: search every section of every tab, jump straight to it ----------
(function finder() {
  const inp = $("finder"), out = $("finderOut"); if (!inp) return;
  const TAB_NAME = {}; document.querySelectorAll("#nav [data-tab]").forEach((b) => (TAB_NAME[b.dataset.tab] = b.textContent.trim()));
  function index() {
    const items = [];
    document.querySelectorAll("main section").forEach((sec) => {
      const tab = sec.id.replace("tab-", "");
      sec.querySelectorAll("details.grp").forEach((d) => {
        const title = (d.querySelector("summary") || {}).textContent || "";
        const words = [title, ...[...d.querySelectorAll(".row > span:first-child, .hint, .cpart-h b, .looklabel, label")].map((e) => e.textContent)].join(" ");
        items.push({ tab, el: d, title: title.trim(), words: words.toLowerCase() });
        d.querySelectorAll(".row > span:first-child, .cpart-h b").forEach((r) => items.push({ tab, el: d, row: r, title: title.trim() + " \u203a " + r.textContent.trim(), words: (r.textContent + " " + title).toLowerCase() }));
      });
    });
    return items;
  }
  const go = (it) => {
    const b = document.querySelector(`#nav [data-tab="${it.tab}"]`); if (b) b.click();
    const view = { viewTune: "tune", viewWalls: "walls", viewLooks: "looks", "tab-media": "mine" }[(it.el.closest("#viewTune, #viewWalls, #viewLooks, #tab-media") || {}).id];
    if (view && typeof skinView !== "undefined" && skinView !== view) { skinView = view; localStorage.setItem("skinView", view); syncSkinView(); }
    it.el.open = true;
    const target = it.row ? it.row.closest(".row, .cpart") || it.el : it.el;
    setTimeout(() => { target.scrollIntoView({ block: "center", behavior: "smooth" }); target.classList.add("found"); setTimeout(() => target.classList.remove("found"), 1600); }, 60);
    inp.value = ""; out.hidden = true;
  };
  inp.oninput = () => {
    const q = inp.value.trim().toLowerCase(); out.innerHTML = "";
    if (q.length < 2) { out.hidden = true; return; }
    // best first: a setting whose own name starts with / contains the words, then section names, then descriptions
    const score = (it) => { const own = (it.row ? it.row.textContent : it.title).trim().toLowerCase();
      return own.startsWith(q) ? 4 : own.includes(q) ? 3 : it.title.toLowerCase().includes(q) ? 2 : 1; };
    const seen = new Set(), hits = index().filter((it) => it.words.includes(q)).map((it) => ({ it, s: score(it) })).sort((a, b) => b.s - a.s)
      .map((x) => x.it).filter((it) => !seen.has(it.title) && seen.add(it.title)).slice(0, 8);
    if (!hits.length) { out.innerHTML = '<div class="fx none">No setting called that. Try another word.</div>'; out.hidden = false; return; }
    for (const it of hits) { const b = document.createElement("button"); b.className = "fx"; b.innerHTML = `<b></b><small></small>`;
      b.querySelector("b").textContent = it.title; b.querySelector("small").textContent = TAB_NAME[it.tab] || it.tab; b.onclick = () => go(it); out.appendChild(b); }
    out.hidden = false;
  };
  inp.onkeydown = (e) => { if (e.key === "Enter") { const f = out.querySelector("button.fx"); if (f) f.click(); } if (e.key === "Escape") { inp.value = ""; out.hidden = true; } };
})();

// ---------- welcome tour (first install) + "what's new" (once after each update) ----------
const WHATS_NEW = ["Trading comes first: Auto quality watches how fast your clicks get through and holds effects still at the order ticket and while you\u2019re in a trade", "TopstepX, topstep.com and nq.vision: turn Priism on from the page in one click (works in app windows too)", "Markers in any colour: signal arrows, trade arrows and app markers, even Rainbow or Gradient (Chart \u203a Lines, zones & labels)", "Signature wallpapers: Imperial, Eclipse, Orion, Glacier, Void, Blood Moon and more (Wallpaper \u203a Looks \u203a Signature)", "Tidier settings: each option is in one place now, and your saved looks were updated to match", "Live candle atmosphere: smoke, a light trail and an aura at the live candle (Chart \u203a Candle FX)", "Price and zones: zones react as price gets near, touches or enters them (Chart \u203a Lines, zones & labels)", "8 candle materials, in the look grid under Materials (Chart \u203a Candles)", "Zones light up when price is in them (Chart \u203a Lines, zones & labels \u203a Price in a zone)",
  "Style the Buy / Sell buttons and the order ticket (TradingView \u203a Trade panel)",
  "Glass, Neon and Aurora edges for TradingView's panels and windows (TradingView \u203a Bars & panels)",
  "A zoom lens for your chart: press Alt+Shift+Z (Settings \u203a Magnifier)",
  "A tidier panel: Wallpaper, Chart, TradingView, Trading, Capture, Workshop, My looks and Settings. Wallpaper settings are under Wallpaper \u203a Adjust",
  "Report a bug right from the panel (Settings \u203a Report a bug)",
  "30 more candle colours, including Synth, Pastel, Luxe and Easy to read (Chart \u203a Candles)",
  "Galaxy, Holo, Stars and Twinkle for the chart frame and the interface skin",
  "nq.vision-style charts: the price and time scales look like TradingView's now",
  "Sharpness up to 4K (Wallpaper \u203a Adjust \u203a Picture)",
  "10 new effects for any wallpaper, some move with your music (Wallpaper \u203a Adjust \u203a This wallpaper)",
  "Music: in time with the beat, and the wallpaper, frame and interface skin can move with it",
  "Live mood: new looks (Glow, Horizon, Outline), Recent move, Move sensitivity, a glow per chart",
  "Your chart can move with your music (Trading \u203a Live mood \u203a Music)",
  "Rain, storms, snow and more over any wallpaper (Wallpaper \u203a Adjust \u203a This wallpaper \u203a Effect)",
  "12 more fonts and 10 new candle looks",
  "Recolour any wallpaper to your colours, plus its own settings (Wallpaper \u203a Adjust \u203a This wallpaper)",
  "Candle parts: wick and border colours, hollow candles, widths (Chart \u203a Candles)",
  "Auto-match: every wallpaper you pick sets everything to match it (Wallpaper \u203a Wallpapers)",
  "4 new wallpapers: Trading Floor, Market Wall, Midnight Moon and Twinkle (OLED)",
  "Match everything now matches it all, with your own wallpapers too",
  "Softer zones so you see the price inside them (Chart \u203a Lines, zones & labels \u203a Zone fill)",
  "Your own Gradient colours",
  "A cleaner look everywhere: chart cards, clip editor, Workshop",
  "A cleaner panel in true black, with slimmer sliders",
  "Wallpapers show their quality (4K, 1080p\u2026) and OLED, with an OLED filter (Wallpaper \u203a OLED)",
  "A Webb space photo pack in the Workshop, up to 4K",
  "Black & white wallpapers (Wallpaper \u203a Adjust \u203a Picture \u203a Colour)",
  "Match everything now colours your indicators and zones from your wallpaper\u2019s own colours",
  "Clips and snapshots include your uploaded wallpaper",
  "Chart text: your indicators\u2019 labels in any colour, with an outline, and black text is always readable (Chart \u203a Lines, zones & labels)",
  "Zones look like neon boxes: a glowing edge, price still visible inside. Plus a calmer Gradient next to Rainbow (Chart \u203a Lines, zones & labels)",
  "Priism is invite only now: enter your invite code once in the panel",
  "Rainbow and the other indicator colours now reach your zones too (bands, boxes, prints)",
  "Style your own drawings too: colour, rainbow and glow for rectangles and lines you draw (Chart \u203a Lines, zones & labels)",
  "Style the legend: colour and a backing for indicator names and values, so they read on any wallpaper (Chart \u203a Lines, zones & labels)",
  "O H L C letters are readable on dark wallpapers",
  "Customise each indicator: its own colour, glow, width, or hide it, zones included (Chart \u203a Lines, zones & labels \u203a Each indicator)",
  "Live mood works on nq.vision and prop-firm platforms",
  "nq.vision: the text over the chart no longer flickers",
  "\u201cCheck this page\u201d: see why something looks wrong on a platform (top of the panel)",
  "nq.vision: charts resize cleanly when you drag the lines between them",
  "Multi-chart layouts: the wallpaper follows each chart instantly while you drag the dividers",
  "Indicator colours: Rainbow, your candle or wallpaper colours, or any colour, plus glow (Chart \u203a Lines, zones & labels)",
  "nq.vision: the wallpaper stays while you drag the chart",
  "Fixed: indicator Settings / Pine Editor sometimes not opening until a refresh",
  "Two copies installed? The one you use now always shows your background",
  "nq.vision: every 2- and 3-chart layout gets your wallpaper and colours, at any window size",
  "Publish your saved looks to the Workshop, and see your shares with their status (My looks \u203a Publish, Workshop \u203a Mine)",
  "Glow at the pointer in any colour (Chart \u203a Lines, zones & labels \u203a Crosshair \u203a Glow colour)",
  "2 new Wow wallpapers: Cozy Room (a sleeping cat by a rainy window) and Tokyo Rooftop (neon, rain and a passing train)",
  "An \u201cUpdate ready\u201d card: see what\u2019s new and update in one tap (your charts stay open)",
  "4 new Wow wallpapers: Koi Pond, Rain on Glass, Ringed Giant and Deep Blue, each with its own look (Wallpaper › Wow)",
  "Christmas pack: Christmas Eve, Tree Lights, Winter Village and Northern Noel, plus Hallows Night (Wallpaper › Seasonal)",
  "Match everything: one tap sets your whole chart to your wallpaper's colours (top of Style)",
  "Recordings are now MP4, and can include music playing on your computer (Capture › Clip › Sound)",
  "\u201cDone for today\u201d: a calm reminder the instant you reach your max loss (Trading › Daily goal & limit)",
  "Desktop app: TradingView in tabs, opens with your last layouts and keeps you signed in",
  "Smoother charts: wallpapers are now drawn in the background, leaving TradingView's thread free",
  "nq.vision and other Lightweight Charts platforms: panels, watchlist, ticker, timeframes, crosshair glow, line glow, price scale, brackets, streamer mode and Live mood",
  "TradingView's light theme is readable over your wallpaper, and one tap switches to dark",
  "Candle looks now work on more Lightweight Charts platforms (like nq.vision)",
  "Style your ticker: colour, size, font and glow for the symbol name (Chart › Lines, zones & labels)",
  "Trading sounds: a chime at your goal, a warning near your max loss, a ping before the session opens or closes",
  "New Nebula wallpaper: glowing gas clouds and bright stars (Wallpaper › Cosmos)",
  "Streamer mode: show P&L as ticks, points or dollars, and the order panel stays usable",
  "Trade brackets: give the lot size its own colour",
  "One click to turn on a platform, and no page refresh needed after an update",
  "Live mood is back: a soft glow around your chart that follows your P&L or the day's move (Trading)",
  "Desktop app: a full-window design, and sign in to your real TradingView account in the chart window",
  "Sound in clips: your voice, your computer's sound (music, videos), or both (Capture › Clip)",
  "Streamer mode hides your money on screen and in recordings (Capture, or Alt+Shift+P)"];
(function onboarding() {
  const ver = APP_VER;
  const seen = localStorage.getItem("seenVer");
  if (!seen) {
    localStorage.setItem("seenVer", ver || "1");
    // A hands-on tour: each step can do the thing for you (never a blocking overlay, Skip any time).
    const go = (tab) => { const b = document.querySelector(`#nav button[data-tab="${tab}"]`); if (b) b.click(); };
    const wow = QUICK_LOOKS.filter((q) => groupOf(q) === "Wow" && WickedSkins[q.skin]);
    const steps = [
      ["Pick a look", "One tap puts a matching wallpaper, candles and glow on your chart. Undo is one tap too.",
        ["Try a Wow look", () => { const q = wow[(Math.random() * wow.length) | 0]; if (q) applyWithUndo({ enabled: true, skin: q.skin, candleClosedLook: "", ...q.set }, `Look: ${q.name}`); }]],
      ["Make it yours", "Style has 16 candle looks, your candle colours, chart lines and the ticker. TradingView styles its own panels and menus.",
        ["Open Chart", () => go("candles")]],
      ["Your platform too", "Trade on a prop firm platform or another charting site (TopstepX, nq.vision…)? Open it, then tap Turn on here at the top of this panel.", null],
      ["Find anything", "Type in \u201cFind any setting\u201d at the top to jump straight to it. Alt+Shift+W on the chart turns everything on or off.", null],
    ];
    // a friendly card at the top (never a blocking overlay)
    let i = 0; const el = $("news"); if (!el) return;
    const draw = () => { const act = steps[i][2];
      el.innerHTML = `<b>Welcome! ${steps[i][0]}</b><p class="hint" style="color:#cfd5e2;margin:2px 0 10px">${steps[i][1]}</p>
      ${act ? `<button class="primary keep" data-a="do" style="width:100%;margin:0 0 10px">${esc(act[0])}</button>` : ""}
      <div class="tour-bar"><div class="dots">${steps.map((_, j) => `<i class="${j === i ? "on" : ""}"></i>`).join("")}</div>
      <div><button class="link" data-a="skip" style="margin:0 8px 0 0">Skip</button><button class="${act ? "" : "primary"}" data-a="next">${i < steps.length - 1 ? "Next" : "Let's go"}</button></div></div>`;
      el.hidden = false;
      if (act) el.querySelector("[data-a=do]").onclick = () => { act[1](); if (++i >= steps.length) el.hidden = true; else draw(); };
      el.querySelector("[data-a=skip]").onclick = () => { el.hidden = true; };
      el.querySelector("[data-a=next]").onclick = () => { if (++i >= steps.length) el.hidden = true; else draw(); }; };
    draw();
    return;
  }
  if (ver && seen !== ver && !IS_TAB) {
    // once after each update: the version you came from, the one you're on, and its headlines
    const ok = () => localStorage.setItem("seenVer", ver);
    const from = /^\d+\.\d+\.\d+$/.test(seen) && newer(ver, seen) ? seen : "";
    setTimeout(() => { if (!PriismUpdateCard.isOpen()) PriismUpdateCard.show({ mode: "updated", from, to: ver, items: WHATS_NEW.slice(0, 4), onPrimary: ok, onLater: ok }); else ok(); }, 350);
  }
})();

// ---------- keep it uncluttered: a switched-off section shows just its title and one line ----------
// (switch it on and its options appear). Candles stay open: picking a candle look is how most people start.
function syncOffGroups() {
  document.querySelectorAll("details.grp").forEach((d) => {
    const sw = d.querySelector(":scope > summary .switch input");
    d.classList.toggle("is-off", !!sw && !sw.checked && d.dataset.grp !== "candles");
  });
}
document.addEventListener("change", () => setTimeout(syncOffGroups, 0), true);
document.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("button")) setTimeout(syncOffGroups, 30); }, true);
syncOffGroups(); setTimeout(syncOffGroups, 300);

// ---------- Report a bug (Settings): sent to the Priism backend, only the owner can read it (website › Workshop) ----------
(function bugReport() {
  const btn = $("bugSend"); if (!btn) return;
  const msg = (t) => { $("bugMsg").textContent = t; };
  btn.onclick = async () => {
    const text = $("bugText").value.trim(); if (text.length < 3) return msg("Write a few words about what went wrong.");
    const c = window.WORKSHOP_CONFIG || {}; if (!c.url || !c.anonKey) return msg("Reports can't be sent from this copy.");
    let host = ""; try { const [t] = await new Promise((r) => chrome.tabs.query({ active: true, lastFocusedWindow: true }, r)); host = t && t.url ? new URL(t.url).hostname : ""; } catch {}
    const app = window.wickedStore ? "desktop" : window.PriismNative ? "android" : "extension";
    const keep = ["skin", "react", "candleOn", "candleLook", "candleClosedLook", "res", "fps", "powerSaver", "layer", "multi", "chartColors", "frameOn", "barPatOn", "panelMode", "sides", "leftBar", "zoneShape", "indMode", "scaleBg"];
    const info = $("bugInfo").checked ? { v: APP_VER, app, host, ua: navigator.userAgent.slice(0, 160), screen: `${screen.width}x${screen.height}@${devicePixelRatio || 1}`,
      settings: Object.fromEntries(keep.map((k) => [k, cfg[k]])) } : { v: APP_VER, app };
    btn.disabled = true; msg("Sending…");
    try {
      const device = window.PriismInvite ? await PriismInvite.deviceId() : "";
      const r = await fetch(c.url.replace(/\/$/, "") + "/rest/v1/rpc/report_bug", { method: "POST", headers: { apikey: c.anonKey, Authorization: "Bearer " + c.anonKey, "Content-Type": "application/json" },
        body: JSON.stringify({ p_message: text, p_contact: $("bugContact").value.trim(), p_info: info, p_device: device }) });
      const v = r.ok ? await r.json() : "offline";
      if (v === "ok") { $("bugText").value = ""; msg("Sent. Thanks for telling us."); }
      else if (v === "slow") msg("You've sent a few already. Try again in an hour.");
      else if (v === "invalid") msg("Couldn't send it. Check your text, then try again.");
      else msg("Couldn't reach the server. Check your connection and try again.");
    } catch { msg("Couldn't reach the server. Check your connection and try again."); }
    btn.disabled = false;
  };
})();
