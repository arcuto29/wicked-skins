/* Runs in the PAGE's JS world (manifest "world": "MAIN"; the desktop app injects it too).
   TradingView paints the chart inside <canvas>, so CSS alone can't restyle it. This hook:
     1. Background: when Priism Skins is on, turns the full-pane background fill into a clear,
        so the skin shows through. Candles, grid, axes and drawings are untouched.
     2. Light theme: lightens dark axis text so it stays readable on dark skins.
     3. Candle colours: remaps TradingView's default up/down colours to the chosen ones,
        with an optional glow.
     4. Glow on indicator / drawing / price lines, and price-scale styling (text colour, glow,
        bold, background, label colours).
   Settings arrive via attributes on <html> (class "bd-on", data-ws-candles + data-ws-fx JSON).
   Nothing is read or sent anywhere; this only changes how things are drawn. */
(function () {
  // Bump HOOK_VERSION whenever this file learns something new. A newer hook still installs if an older one is
  // already on the page (e.g. two copies of the extension installed), so new settings always work.
  const HOOK_VERSION = 40;
  if (window.__bdHooked && (window.__bdHookVer || 1) >= HOOK_VERSION) return;
  const olderHook = !!window.__bdHooked;
  window.__bdHooked = true;
  window.__bdHookVer = HOOK_VERSION;
  // Redraw state, declared first: when a newer copy goes into a chart that's already open (Priism updated in the
  // background), the chart's colours are known at once and a redraw is asked for while this file is still setting
  // up. Declared lower down, that threw ("softRaf before initialization"), stopped the setup halfway and left
  // TradingView drawing through half-installed code until you reloaded (windows like indicator Settings or the Pine
  // Editor could then fail to open).
  let softRaf = 0, hardT = 0;
  const stats = (window.__bdStats = window.__bdStats || { soft: 0, hard: 0 });
  // An older copy of the extension already wrapped the canvas API. Put the browser's own untouched functions back
  // (taken from a fresh hidden frame), so the old wrappers are cut out and only this version draws.
  if (olderHook) {
    try {
      const f = document.createElement("iframe"); f.style.display = "none";
      (document.documentElement || document.head || document.body).appendChild(f);
      const N = f.contentWindow.CanvasRenderingContext2D.prototype, P = CanvasRenderingContext2D.prototype;
      for (const m of ["fillText", "fillRect", "fill", "stroke", "beginPath", "moveTo", "lineTo", "strokeRect"]) P[m] = N[m];
      for (const prop of ["fillStyle", "strokeStyle"]) Object.defineProperty(P, prop, Object.getOwnPropertyDescriptor(N, prop));
      f.remove();
    } catch {}
  }

  // <html> can be missing when this runs very early (desktop app preload), so always look it up lazily.
  const EMPTY = { classList: { contains: () => false }, getAttribute: () => null };
  const htmlEl = () => document.documentElement || EMPTY;
  const proto = CanvasRenderingContext2D.prototype;

  // ---------- settings ----------
  let on = htmlEl().classList.contains("bd-on");
  let candles = null; // { up:[r,g,b], down:[r,g,b], upHex, downHex, glow }
  const remapCacheMain = new Map();

  const hexToRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));

  // every candle look lives in candlelooks.js (shared with lw.js and the panel previews)
  const lookIds = () => (window.__bdCandleLooks && window.__bdCandleLooks.IDS) || ["solid", "neon", "prism", "shift"];
  function readCandles() {
    remapCacheMain.clear();
    candles = parseCandles(htmlEl().getAttribute("data-ws-candles"));
    try { const L = window.__bdCandleLooks; if (L && L.spot && !(candles && (candles.A || candles.Z))) L.spot.clear(); } catch {}
    try { if (candles && window.__bdCandleLooks && window.__bdCandleLooks.priceLine) window.__bdCandleLooks.priceLine.setCols([candles.upHex, candles.downHex]); } catch {}
  }
  function parseCandles(raw) {
    let out = null;
    try {
      const c = raw ? JSON.parse(raw) : null;
      if (c && /^#[0-9a-f]{6}$/i.test(c.up) && /^#[0-9a-f]{6}$/i.test(c.down)) {
        out = { up: hexToRgb(c.up), down: hexToRgb(c.down), upHex: c.up.toLowerCase(), downHex: c.down.toLowerCase(),
          glow: Math.max(0, Math.min(1, +c.glow || 0)), look: lookIds().includes(c.look) ? c.look : "solid",
          // Closed candles' own look ("" = the same as the live candle). Not with Cycle (that one moves the whole chart's colours).
          closed: lookIds().includes(c.closed) && c.closed !== "shift" && c.closed !== c.look && c.look !== "shift" ? c.closed : "",
          P: window.__bdCandleLooks && window.__bdCandleLooks.parts ? window.__bdCandleLooks.parts(c.parts) : null, lite: !!c.lite,
          F: window.__bdCandleLooks && window.__bdCandleLooks.fx ? window.__bdCandleLooks.fx(c.fx) : null,   // Candle FX light layers
          A: !!(c.spot && c.spot.live), Z: !!(c.spot && c.spot.zones) };   // where the live candle / zones are (for the atmosphere, zone lights)   // wick / border / hollow / widths
      }
    } catch { out = null; }
    return out;
  }
  readCandles();

  // Line glow + price scale styling
  const FX0 = { lineGlow: 0, scaleText: "", scaleGlow: 0, scaleBold: false, scaleBg: "auto", scaleBgColor: "#0b1320", scaleLabels: false,
    scaleSize: 0, scaleFont: "default",
    // Bracket pills = the broker's on-chart TP / Stop / entry / P&L boxes (drawn by TradingView, "bold Npx Verdana").
    // We can fully recolour every part, at draw time (the API can't reach these). All colours are "" = keep as-is.
    //   bracketSize 0..3  px bigger text
    //   bracketFill       box background colour      ("" keep; else any hex)
    //   bracketText       number colour              ("" keep/auto; a single colour for all pills)
    //   bracketProfit/Loss  +/- number colours        (override bracketText by sign; green/red style)
    //   bracketBorderColor  box outline colour        ("" keep)   + bracketBorderW 0..3 thickness
    //   bracketLineColor    level-line colour         ("" keep)   + bracketLineW   0..3 thickness
    //   bracketBack keep|glass|solid  box opacity (only when bracketFill is "", to strengthen TradingView's box)
    bracketOn: false, bracketSize: 0, bracketBack: "keep",
    bracketFill: "", bracketText: "", bracketProfit: "", bracketLoss: "",
    bracketBorderColor: "", bracketBorderW: 0, bracketLineColor: "", bracketLineW: 0,
    bracketDebug: false,
    privacy: false,           // Streamer mode: the numbers in TradingView's trade labels are drawn as dots
    // what Streamer mode does to the P&L in those labels: hide = every number becomes dots; ticks = money becomes dots,
    // TradingView's tick / % values stay; points = like ticks, but "+8 ticks" is shown as "+2 pts" (needs tickSize);
    // show = labels untouched (only the panels are blurred)
    privacyPnl: "hide", tickSize: 0,
    bracketQty: "",           // colour of the lot size / quantity pill ("" = like the other numbers)
    // Indicator colours: own (TradingView's / the platform's) | rainbow | candles | wallpaper | custom (+ indColor)
    indMode: "own", indColor: "", indCustom: {}, drawOn: false, txtMode: "own", txtColor: "", txtOutline: 0, txtSize: 0, wallColors: [],
    zoneFill: 0.12, zoneDim: false, indGrad: [], zoneShape: "square", zoneBorder: "line", zoneStyle: "flat", zoneReact: "off", markMode: "own", markColor: "",
    // Chart styling (each part: off = TradingView's own). Colour "" = the skin's colour; "candle" = your up-candle colour.
    gridOn: false, gridColor: "", gridAlpha: 0.35, gridW: 0, gridStyle: "dotted",
    chOn: false, chColor: "", chW: 0, chStyle: "dashed", chGlow: false, chGlowColor: "", chLabels: false,
    plOn: false, plColor: "", plW: 0, plStyle: "dotted",
    sbOn: false, sbColor: "", sbW: 0, sbStyle: "dashed",          // session breaks (vertical lines between sessions)
    axOn: false, axColor: "", axW: 0, axStyle: "solid",           // the border lines of the price / time scales
    accent: "",
    bg: null, busy: false, prof: [], profs: [] };
  let fx = { ...FX0 };
  const colOpt = (v) => (v === "candle" || /^#[0-9a-f]{6}$/i.test(v || "") ? v : "");
  // Each indicator's own settings, by its colour: { "r,g,b": { c: "#hex" | "rainbow" | "", g: glow 0..1, w: width 0..3, h: hide, s: zone shape } }
  function cleanCustom(m) {
    const out = {}; if (!m || typeof m !== "object") return out;
    for (const [k, e] of Object.entries(m).slice(0, 40)) {
      if (!/^\d{1,3},\d{1,3},\d{1,3}$/.test(k) || !e || typeof e !== "object") continue;
      const c = e.c === "rainbow" || e.c === "gradient" || /^#[0-9a-f]{6}$/i.test(e.c || "") ? e.c : "";
      const g = e.g === undefined || e.g === null || e.g === "" ? undefined : Math.max(0, Math.min(1, +e.g || 0));
      out[k] = { c, g, w: Math.max(0, Math.min(3, +e.w || 0)), h: !!e.h, s: ["square", "rounded", "pill", "oval"].includes(e.s) ? e.s : "",   // this zone's own shape / border / style ("" = like all zones)
        b: ["line", "dashed", "double", "glow", "none"].includes(e.b) ? e.b : "", y: ["flat", "fade", "shine", "glass", "hollow"].includes(e.y) ? e.y : "" };
    }
    return out;
  }
  // the font's CSS family, sent by content.js (it loads Priism's bundled fonts); only safe characters
  const famOf = (f) => (typeof f.scaleFamily === "string" && /^[A-Za-z0-9 ,"'\-]{1,200}$/.test(f.scaleFamily) ? f.scaleFamily : "");
  function parseFx(raw) {
    try {
      const f = raw ? JSON.parse(raw) : {};
      return {
        lineGlow: Math.max(0, Math.min(1, +f.lineGlow || 0)),
        scaleText: /^#[0-9a-f]{6}$/i.test(f.scaleText || "") ? f.scaleText : "",
        scaleGlow: Math.max(0, Math.min(1, +f.scaleGlow || 0)),
        scaleBold: !!f.scaleBold,
        scaleBg: ["auto", "glass", "color", "default"].includes(f.scaleBg) ? f.scaleBg : "auto",
        scaleBgColor: /^#[0-9a-f]{6}$/i.test(f.scaleBgColor || "") ? f.scaleBgColor : "#0b1320",
        scaleSize: Math.max(0, Math.min(2, +f.scaleSize || 0)),
        scaleFont: /^[a-z]{1,16}$/.test(f.scaleFont || "") ? f.scaleFont : "default", scaleFamily: famOf(f), fontTick: +f.fontTick || 0, lite: !!f.lite,
        scaleLabels: !!f.scaleLabels,
        bracketOn: !!f.bracketOn,
        bracketSize: Math.max(0, Math.min(3, +f.bracketSize || 0)),
        bracketBack: ["keep", "glass", "solid"].includes(f.bracketBack) ? f.bracketBack : "keep",
        bracketFill: /^#[0-9a-f]{6}$/i.test(f.bracketFill || "") ? f.bracketFill : "",
        bracketText: /^#[0-9a-f]{6}$/i.test(f.bracketText || "") ? f.bracketText : "",
        bracketProfit: /^#[0-9a-f]{6}$/i.test(f.bracketProfit || "") ? f.bracketProfit : "",
        bracketLoss: /^#[0-9a-f]{6}$/i.test(f.bracketLoss || "") ? f.bracketLoss : "",
        bracketBorderColor: /^#[0-9a-f]{6}$/i.test(f.bracketBorderColor || "") ? f.bracketBorderColor : "",
        bracketBorderW: Math.max(0, Math.min(3, +f.bracketBorderW || 0)),
        bracketLineColor: /^#[0-9a-f]{6}$/i.test(f.bracketLineColor || "") ? f.bracketLineColor : "",
        bracketLineW: Math.max(0, Math.min(3, +f.bracketLineW || 0)),
        bracketDebug: !!f.bracketDebug, privacy: !!f.privacy,
        privacyPnl: ["hide", "ticks", "points", "show"].includes(f.privacyPnl) ? f.privacyPnl : "hide",
        tickSize: Math.max(0, +f.tickSize || 0),
        bracketQty: /^#[0-9a-f]{6}$/i.test(f.bracketQty || "") ? f.bracketQty : "",
        gridOn: !!f.gridOn, gridColor: colOpt(f.gridColor), gridAlpha: Math.max(0.03, Math.min(1, f.gridAlpha === undefined ? 0.35 : +f.gridAlpha || 0)),
        gridW: Math.max(0, Math.min(2, +f.gridW || 0)), gridStyle: ["solid", "dotted", "dashed", "none"].includes(f.gridStyle) ? f.gridStyle : "dotted",
        chOn: !!f.chOn, chColor: colOpt(f.chColor), chW: Math.max(0, Math.min(2, +f.chW || 0)),
        chStyle: ["solid", "dotted", "dashed"].includes(f.chStyle) ? f.chStyle : "dashed", chGlow: !!f.chGlow, chGlowColor: colOpt(f.chGlowColor), chLabels: !!f.chLabels,
        plOn: !!f.plOn, plColor: colOpt(f.plColor), plW: Math.max(0, Math.min(2, +f.plW || 0)),
        plStyle: ["solid", "dotted", "dashed"].includes(f.plStyle) ? f.plStyle : "dotted",
        sbOn: !!f.sbOn, sbColor: colOpt(f.sbColor), sbW: Math.max(0, Math.min(2, +f.sbW || 0)), sbStyle: ["solid", "dotted", "dashed", "none"].includes(f.sbStyle) ? f.sbStyle : "dashed",
        axOn: !!f.axOn, axColor: colOpt(f.axColor), axW: Math.max(0, Math.min(2, +f.axW || 0)), axStyle: ["solid", "none"].includes(f.axStyle) ? f.axStyle : "solid",
        markMode: ["own", "rainbow", "gradient", "candles", "wallpaper", "custom"].includes(f.markMode) ? f.markMode : "own", markColor: /^#[0-9a-f]{6}$/i.test(f.markColor || "") ? f.markColor : "",
        indMode: ["own", "rainbow", "gradient", "candles", "wallpaper", "custom"].includes(f.indMode) ? f.indMode : "own", indColor: /^#[0-9a-f]{6}$/i.test(f.indColor || "") ? f.indColor : "",
        indCustom: cleanCustom(f.indCustom), drawOn: !!f.drawOn,
        zoneFill: Math.max(0.04, Math.min(0.45, +f.zoneFill || 0.12)), zoneDim: !!f.zoneDim,
        zoneReact: ["glow", "strong", "edge", "spotlight", "shimmer"].includes(f.zoneReact) ? f.zoneReact : "off", zoneShape: ["square", "rounded", "pill", "oval"].includes(f.zoneShape) ? f.zoneShape : "square", zoneBorder: ["line", "dashed", "double", "glow", "none"].includes(f.zoneBorder) ? f.zoneBorder : "line", zoneStyle: ["flat", "fade", "shine", "glass", "hollow"].includes(f.zoneStyle) ? f.zoneStyle : "flat",
        indGrad: Array.isArray(f.indGrad) ? f.indGrad.filter((x) => /^#[0-9a-f]{6}$/i.test(x)).slice(0, 3) : [],
        txtMode: ["readable", "custom", "candle"].includes(f.txtMode) ? f.txtMode : "own", txtColor: /^#[0-9a-f]{6}$/i.test(f.txtColor || "") ? f.txtColor : "", txtOutline: Math.max(0, Math.min(2, +f.txtOutline || 0)), txtSize: Math.max(0, Math.min(2, +f.txtSize || 0)),
        accent: /^#[0-9a-f]{6}$/i.test(f.accent || "") ? f.accent : "",
        wallColors: Array.isArray(f.wallColors) ? f.wallColors.filter((x) => /^#[0-9a-f]{6}$/i.test(x)).slice(0, 5) : [],
        bg: f.bg === "dark" || f.bg === "light" ? f.bg : null,   // measured brightness of the wallpaper (content.js)
        busy: !!f.busy,                                           // wallpaper has lots of contrast behind the scale
        prof: Array.isArray(f.prof) ? f.prof.slice(0, 18).map(Number) : [],  // brightness behind the price scale, top->bottom
        // one profile per chart (multi-chart layouts): { l, t, r, b } = the chart's box on screen, p = profile
        profs: Array.isArray(f.profs) ? f.profs.slice(0, 16).filter((q) => q && Array.isArray(q.p))
          .map((q) => ({ l: +q.l || 0, t: +q.t || 0, r: +q.r || 0, b: +q.b || 0, p: q.p.slice(0, 18).map(Number) })) : [],
      };
    } catch { return { ...FX0 }; }
  }
  function readFx() {
    fx = parseFx(htmlEl().getAttribute("data-ws-fx"));
    remapCacheMain.clear();
    window.__bdLite = !!fx.lite || !!(candles && candles.lite);
    const sig = JSON.stringify([fx.lineGlow, fx.scaleText, fx.scaleGlow, fx.scaleBold, fx.scaleBg, fx.scaleBgColor, fx.scaleLabels, fx.scaleSize, fx.scaleFont, fx.scaleFamily, fx.fontTick, fx.lite,
      fx.bracketOn, fx.bracketSize, fx.bracketBack, fx.bracketFill, fx.bracketText, fx.bracketProfit, fx.bracketLoss,
      fx.bracketBorderColor, fx.bracketBorderW, fx.bracketLineColor, fx.bracketLineW, fx.privacy, fx.privacyPnl, fx.tickSize, fx.bracketQty,
      fx.indMode, fx.indColor, fx.markMode, fx.markColor, JSON.stringify(fx.indCustom), fx.wallColors.join(""), fx.zoneFill, fx.zoneDim, fx.zoneShape, fx.zoneBorder, fx.zoneStyle, fx.zoneReact, fx.indGrad.join(""), fx.drawOn, fx.txtMode, fx.txtColor, fx.txtOutline, fx.txtSize, fx.gridOn, fx.gridColor, fx.gridAlpha, fx.gridW, fx.gridStyle, fx.chOn, fx.chColor, fx.chW, fx.chStyle, fx.chGlow, fx.chGlowColor, fx.chLabels, fx.plOn, fx.plColor, fx.plW, fx.plStyle, fx.sbOn, fx.sbColor, fx.sbW, fx.sbStyle, fx.axOn, fx.axColor, fx.axW, fx.axStyle, fx.accent]);
    if (window.__bdCandleLooks && window.__bdCandleLooks.setWallColors) window.__bdCandleLooks.setWallColors(fx.wallColors, fx.bg);
    const userChanged = sig !== fxSig; fxSig = sig;
    return userChanged;
  }
  let fxSig = "", lastToneSig = "";
  function toneSig() {
    const t = (p) => (p || []).map((v) => (v > 0.46 ? "L" : "d")).join("");
    return (fx.bg || "") + (fx.busy ? "b" : "") + "|" + t(fx.prof) + "|" + (fx.profs || []).map((q) => t(q.p)).join(",");
  }
  readFx();

  const settingsObserver = new MutationObserver((muts) => {
    let redraw = false, rebuild = false, toneOnly = true;
    for (const m of muts) {
      if (m.attributeName === "class") { const was = on; on = htmlEl().classList.contains("bd-on"); if (was !== on) { rebuild = true; toneOnly = false; } }
      if (m.attributeName === "data-ws-candles") { const before = candles ? candles.upHex + candles.downHex : ""; readCandles(); redraw = true; toneOnly = false;
        if ((candles ? candles.upHex + candles.downHex : "") !== before) rebuild = true; }   // new colours: volume bars are cached by TradingView
      if (m.attributeName === "data-ws-fx") {
        // your settings changed -> redraw; the wallpaper's brightness drifted -> redraw ONLY if the scale text has to
        // flip between light and dark somewhere (an idle chart used to redraw every ~2s for nothing: a periodic hitch)
        const user = readFx(), ts = toneSig();
        if (user || ts !== lastToneSig) redraw = true;
        if (user) toneOnly = false;
        lastToneSig = ts;
      }
    }
    if (rebuild) forceRepaint(false); else if (redraw) forceRepaint(true, toneOnly);
  });
  (function watchSettings() {
    const el = document.documentElement;
    if (!el) return setTimeout(watchSettings, 5);            // wait for the page's <html>
    settingsObserver.observe(el, { attributes: true, attributeFilter: ["class", "data-ws-candles", "data-ws-fx"] });
    on = el.classList.contains("bd-on"); readCandles(); readFx();
  })();

  // ---------- candle colour remap (fillStyle / strokeStyle setters) ----------
  // We recolour the candles TradingView actually draws. To know WHICH colours are candles we
  // read the chart's own candle settings (read-only, never written): your custom colours,
  // hollow candles, Heikin Ashi, bars... TradingView's defaults are always included as a fallback
  // (they also cover the default Volume bars).
  const scratch0 = document.createElement("canvas").getContext("2d");
  const origFillDesc = Object.getOwnPropertyDescriptor(proto, "fillStyle");
  function rgbKey(v) {                      // any CSS colour -> { key:"r,g,b", a:alpha } or null
    if (typeof v !== "string") return null;
    origFillDesc.set.call(scratch0, "#000"); origFillDesc.set.call(scratch0, v);
    const n = origFillDesc.get.call(scratch0);
    if (n[0] === "#") return { key: [1, 3, 5].map((i) => parseInt(n.slice(i, i + 2), 16)).join(","), a: null };
    const m = n.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    return m ? { key: m[1] + "," + m[2] + "," + m[3], a: m[4] === undefined ? null : m[4] } : null;
  }
  const DEFAULT_SIDES = [["#089981", "up"], ["#26a69a", "up"], ["#f23645", "down"], ["#ef5350", "down"]];
  let sides = new Map();                    // "r,g,b" -> "up" | "down"
  let sidesSig = "";
  const UP_KEYS = ["upColor", "borderUpColor", "wickUpColor"];
  const DOWN_KEYS = ["downColor", "borderDownColor", "wickDownColor"];
  const KIND = { upColor: "body", downColor: "body", borderUpColor: "border", borderDownColor: "border", wickUpColor: "wick", wickDownColor: "wick" };
  const STYLES = ["candleStyle", "hollowCandleStyle", "haStyle", "barStyle", "volCandlesStyle", "hlcBarsStyle"];

  // The colours of your drawings (rectangles, the Long / Short position tool, fib fills…), so "all indicators" colours
  // never repaint them: they're yours, not an indicator's.
  let drawCols = new Map();   // colour key -> drawing name ("Rectangle"), for drawings on this chart
  // The chart's API: tradingview.com (TradingViewApi), TradingView's charting library inside its frame (tradingViewApi)
  // or the page that embeds it (tvWidget, like nq.vision).
  const chartApi = () => { for (const w of [window.TradingViewApi, window.tradingViewApi]) if (w && typeof w.activeChart === "function") return w;
    try { if (parent !== window && parent.tvWidget && typeof parent.tvWidget.activeChart === "function") return parent.tvWidget; } catch {} return null; };
  // Names for "Each indicator": where TradingView's internals are reachable (tradingview.com), each indicator's plot
  // colours -> its title ("MA (20, close)"), so the panel can say which line is which. Your drawings are named too
  // ("Rectangle (your drawing)"). Elsewhere lines go by colour.
  setInterval(() => {
    const L = window.__bdCandleLooks; if (!L || !L.setNames || document.hidden) return;
    const m = new Map();
    try {
      const api = window.TradingViewApi || {}, a = api._activeChartWidgetWV, cw = a && a.value() && a.value()._chartWidget, model = cw && cw.model().model();
      const ac = api.activeChart && api.activeChart(), ids = ac && ac.getAllStudies ? ac.getAllStudies().map((x) => x.id) : [];
      const srcs = ids.length && model && model.dataSourceForId ? ids.map((i) => model.dataSourceForId(i)).filter(Boolean) : (model && model.dataSources ? model.dataSources() : []);
      for (const src of srcs) {
        let title = ""; try { title = src.title ? src.title() : ""; } catch {}
        if (!title || !src.properties) continue;
        let st = null; try { st = src.properties().childs().styles; } catch {}
        const ch = st && st.childs ? st.childs() : null; if (!ch) continue;
        for (const k of Object.keys(ch)) { if (k[0] === "_") continue;
          try { const col = ch[k].childs().color.value(), r = L.keyOf(col); if (r && !m.has(r.k)) m.set(r.k, title.slice(0, 28) + (Object.keys(ch).filter((x) => x[0] !== "_").length > 1 ? " \u00b7 " + k : "")); } catch {} }
      }
    } catch {}
    // your drawings (for the names, and in case one changed colour without being looked up while drawn)
    try {
      const was = [...drawCols.keys()].join("|"), d = scanDrawings();
      if (d) { if ([...d.keys()].join("|") !== was && on) forceRepaint(true);   // e.g. one was deleted: redraw once, listed right
        for (const [k, name] of d) if (!m.has(k)) m.set(k, name.slice(0, 24) + " (your drawing)"); }
    } catch {}
    if (m.size) L.setNames(m);
  }, 3000);
  // Your drawings: the line / fill colours of each one (not its text colour, which isn't drawn as a shape), read from
  // the chart. -> the new list (also kept in drawCols), or null if the chart can't be asked.
  let drawSig = "", drawMiss = new Set(), drawAt = -1e9, drawSigFrame = -1;
  const drawApi = () => { const api = chartApi(), ac = api && api.activeChart && api.activeChart(); return ac && ac.getAllShapes ? ac : null; };
  const shapesSig = (sh) => sh.length + ":" + (sh.length ? sh[0].id + "/" + sh[sh.length - 1].id : "");
  function scanDrawings() {
    const L = window.__bdCandleLooks, ac = drawApi(); if (!L || !L.keyOf || !ac) return null;
    const d = new Map();
    const walk = (o, n, name) => { if (!o || n > 4) return; for (const k in o) { if (/text|font/i.test(k)) continue; const v = o[k];
      if (typeof v === "string") { const r = L.keyOf(v); if (r && !d.has(r.k)) d.set(r.k, name); } else if (v && typeof v === "object") walk(v, n + 1, name); } };
    let all; try { all = ac.getAllShapes(); } catch { return null; }
    for (const sh of all.slice(0, 300)) { const name = String(sh.name || "drawing").replace(/^LineTool/, "").replace(/_/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase().replace(/^./, (c) => c.toUpperCase());
      try { walk(ac.getShapeById(sh.id).getProperties(), 0, name); } catch {} }
    drawCols = d; drawSig = shapesSig(all); drawMiss = new Set(); drawAt = performance.now();
    return d;
  }
  // Is this colour one of your drawings'? Asked while the line is being drawn. The list above alone was up to 3 s old,
  // so a drawing that came back (switching back to its symbol or timeframe, undo, a layout) or a new one was drawn in
  // its own colour first and switched to yours only when the list caught up: a flash. Now a colour the list doesn't
  // have is checked against the chart right then: once a frame, a quick look at which drawings there are (the list is
  // read again if they changed), and a colour never looked up before reads the list again (at most every 250 ms). A
  // colour that isn't a drawing's is remembered as such until the drawings change, so this costs nothing per line.
  function drawColHas(k) {
    if (drawCols.has(k)) return true;
    if (drawSigFrame !== frameNo) {
      drawSigFrame = frameNo;
      const ac = drawApi(); let sig = drawSig; try { if (ac) sig = shapesSig(ac.getAllShapes()); } catch {}
      if (sig !== drawSig) { scanDrawings(); if (drawCols.has(k)) return true; }
    }
    if (drawMiss.has(k)) return false;
    if (performance.now() - drawAt < 250) return false;          // looked up a moment ago: ask again next frame
    scanDrawings();
    if (drawCols.has(k)) return true;
    if (drawMiss.size < 500) drawMiss.add(k);
    return false;
  }
  function chartWidgets() {
    const api = window.TradingViewApi || window.tradingViewApi, out = [];
    try { const a = api && api._activeChartWidgetWV && api._activeChartWidgetWV.value(); if (a) out.push(a); } catch {}
    try { // multi-chart layouts
      const n = api && api.chartsCount ? api.chartsCount() : 0;
      for (let i = 0; i < n; i++) { const w = api.chart(i); if (w && !out.includes(w)) out.push(w); }
    } catch {}
    // platforms built on TradingView's charting library (the trading terminal, prop-firm platforms): the widget object
    // (often in the page that holds the chart's frame)
    if (!out.length) try { let tw = null; try { tw = window.tvWidget || (window.parent !== window && window.parent.tvWidget) || null; } catch {}
      const n = tw && tw.chartsCount ? tw.chartsCount() : tw ? 1 : 0;
      for (let i = 0; i < n; i++) { const w = n > 1 && tw.chart ? tw.chart(i) : tw.activeChart(); if (w && !out.includes(w)) out.push(w); } } catch {}
    return out;
  }
  // Closed candles: where is the newest bar of the data, on this canvas? From the chart's own model (follows scrolling,
  // zoom, timeframe and replay; each chart of a layout on its own). Device px, null = off screen, undefined = unknown.
  // (read fresh at every pass end, a few times per paint: TradingView can paint twice in one frame while it scrolls,
  // so a position remembered for the frame would be stale for the second paint)
  // canvas px per CSS px (read once a frame: reading layout mid-paint can force the browser to lay the page out again)
  const scaleMemo = new WeakMap();
  const scaleOf = (c) => { const m = scaleMemo.get(c); if (m && m.f === frameNo) return m.k; const r = c.getBoundingClientRect(), k = r.width ? c.width / r.width : 1; scaleMemo.set(c, { f: frameNo, k }); return k; };
  function newestBarX(c) {
    let v;
    try { // (.chart-markup-table is nested: match the chart whose main table holds this canvas)
      if (c.closest && c.closest(".chart-markup-table")) for (const w of chartWidgets()) { const cw = w._chartWidget || w; if (!cw || !cw._elMainTable || !cw._elMainTable.contains(c) || !cw.model) continue;
        const mm = cw.model(), m = mm.model ? mm.model() : mm, ts = m.timeScale(), li = m.mainSeries().bars().lastIndex();
        if (li === null || li === undefined) break;
        const k = scaleOf(c), x = ts.indexToCoordinate(li) * k, sp = ts.barSpacing() * k;
        v = x + sp / 2 < 0 || x - sp / 2 > c.width ? null : x; break; } } catch { v = undefined; }   // off screen only once the whole bar is
    return v;
  }
  try { if (window.__bdCandleLooks && window.__bdCandleLooks.live && window.__bdCandleLooks.live.setHint) window.__bdCandleLooks.live.setHint(newestBarX); } catch {}
  let scaleTextKey = null; // "r,g,b" of TradingView's axis label colour
  function learnSides() {
    const found = [];
    try {
      const w = chartWidgets()[0], cw = w && (w._chartWidget || w);
      const props = cw && (cw.model().model ? cw.model().model().properties() : cw.properties());
      const sp = props && props.childs().scalesProperties.childs();
      const r = sp && rgbKey(sp.textColor.value());
      scaleTextKey = r ? r.key : null;
    } catch {}
    for (const w of chartWidgets()) {
      try {
        const p = (w._chartWidget || w).model().mainSeries().properties().childs();
        for (const st of STYLES) {
          const cs = p[st] && p[st].childs && p[st].childs();
          if (!cs) continue;
          for (const k of UP_KEYS) if (cs[k]) found.push([cs[k].value(), "up", KIND[k]]);
          for (const k of DOWN_KEYS) if (cs[k]) found.push([cs[k].value(), "down", KIND[k]]);
        }
      } catch {}
    }
    // A colour can be used by both sides (e.g. black borders on every candle + black down bodies).
    // Resolve by priority: body colour > border > wick > TradingView defaults.
    // Only a colour that is the BODY of both sides (or only a shared border/wick) is left alone.
    const RANK = { body: 3, border: 2, wick: 1, def: 0 };
    const best = new Map(); // key -> { side, rank, tie }
    for (const [c, side, kind] of [...DEFAULT_SIDES.map(([c, s]) => [c, s, "def"]), ...found]) {
      const r = rgbKey(c);
      if (!r) continue;
      const rank = RANK[kind], cur = best.get(r.key);
      if (!cur || rank > cur.rank) best.set(r.key, { side, rank, tie: false });
      else if (rank === cur.rank && side !== cur.side) cur.tie = true;
    }
    if (!found.length) for (const [c, side] of learnedFromDrawing()) {        // no API: use what we saw drawn
      const r = rgbKey(c); if (r && !best.has(r.key)) best.set(r.key, { side, rank: RANK.body, tie: false });
    }
    const next = new Map();
    for (const [k, v] of best) if (!v.tie) next.set(k, v.side);
    const sig = [...next].sort().join("|");
    if (sig !== sidesSig) {
      sides = next; sidesSig = sig; remapCacheMain.clear();
      if (candles) forceRepaint(false);
    }
  }
  // Fallback for platforms without TradingView's internal API: the two most-drawn small, opaque,
  // colourful fills in the chart are the candles. Greener one = up, the other = down.
  const tally = new Map();
  // Is this fill an indicator's zone? (not a candle, not the background, at least a few px across). Notes it for the
  // panel and returns your settings for it (Each indicator), or null to draw it as it is.
  function zoneFor(ctx, w, h, x, y) {
    const L = window.__bdCandleLooks; if (!L || !L.zone) return null;
    const c = ctx.canvas; let W, H;
    if (w === 1e4) { const b = pathBox.get(ctx); if (!b) return null; W = b.x1 - b.x0; H = b.y1 - b.y0; }   // a path: its drawn box
    else { const t = ctx.getTransform(); W = Math.abs(w * (t.a || 1)); H = Math.abs(h * (t.d || 1)); }
    if (W < 16 || H < 3 || W * H < 200 || (W >= c.width * 0.95 && H >= c.height * 0.95)) return null;   // too small, or the whole pane (background)
    const orig = String(ctx.__bdFill !== undefined ? ctx.__bdFill : ctx.fillStyle), r = L.keyOf(orig); if (!r) return null;
    const dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1;
    if (r.a >= 0.95 && H / dpr >= 8 && H / dpr <= 40 && W / dpr <= 460) return null;   // a solid label box (price tags, order pills, session labels), not a zone
    if (sides.has(r.k) || (candles && (r.k === candles.up.join(",") || r.k === candles.down.join(",")))) return null;   // candles / volume
    L.noteSeen(orig, "zone");
    // Zone lights (content.js draws them behind the chart): where this see-through box is
    if (candles && candles.Z && L.spot && r.a < 0.9 && H < c.height * 0.9 && H >= 4 && W >= 16) {
      const t = ctx.getTransform(), b = w === 1e4 ? pathBox.get(ctx) : null;
      const X = b ? b.x0 : Math.min(x, x + w) * (t.a || 1) + t.e, Y = b ? b.y0 : Math.min(y, y + h) * (t.d || 1) + t.f;
      L.spot.zone(c, X, Y, W, H, r.k);
    }
    // its own settings (Each indicator), or the all-indicators colour: your drawings (a rectangle, the Long / Short
    // tool) only with "Your drawings: Style them too"; greys stay grey like grey lines do
    const notDraw = fx.drawOn || !drawColHas(r.k);   // (a drawing of yours: only with "Style them too")
    const own = fx.indCustom && fx.indCustom[r.k], all = fx.indMode !== "own" && notDraw && glowable(`rgb(${r.k})`);
    const dim = fx.zoneDim && r.a < 0.9 && notDraw;   // Dim all zones (your drawings only with "Style them too")
    // the Glow slider (Indicators) also glows zones left in their own colours, on their edge (drawings with "Style them too")
    const glowOwn = fx.lineGlow > 0 && r.a < 0.9 && H < c.height * 0.9 && W >= 16 && H >= 4 && notDraw && glowable(`rgb(${r.k})`);
    const shaped = zoneStyled(ctx) && (w !== 1e4 || !!rectPath(ctx)) && r.a < 0.9 && notDraw   // shape / border only
      && H >= 8 * dpr && W >= 24 * dpr && !stackedCols.has(r.k + "|" + r.a);                                      // (not slivers, not the position tool)
    // price is in this zone right now (Price in a zone: Glow), and it's a box, not full-height shading
    let hot = 0, at = null;
    if (fx.zoneReact && fx.zoneReact !== "off" && r.a < 0.9 && H < c.height * 0.9 && L.zoneHot) {
      const t = ctx.getTransform(), b = w === 1e4 ? pathBox.get(ctx) : null;
      const X = b ? b.x0 : Math.min(x, x + w) * (t.a || 1) + t.e, Y = b ? b.y0 : Math.min(y, y + h) * (t.d || 1) + t.f;
      hot = isFinite(X) && isFinite(Y) ? L.zoneHot(c, X, Y, W, H) : 0; at = { ctx, X, Y, W, H }; if (hot) zoneAnimAt = performance.now();
    }
    const heat = (z) => (hot && z ? L.zoneHeat(z, fx.zoneReact, at) : z);
    if (!own && !all && !dim && !shaped && !hot && !glowOwn) return null;
    if (!own && !all && !dim) { const zo = L.zoneOwn(orig); if (zo && !(H < c.height * 0.9)) zo.e = null; if (zo && glowOwn) zo.glow = fx.lineGlow; return heat(zo); }
    const z = L.zone(orig, { mode: all ? fx.indMode : "own", color: fx.indColor, up: candles && candles.upHex, down: candles && candles.downHex, accent: fx.accent, custom: fx.indCustom, glow: fx.lineGlow, zoneFill: fx.zoneFill, dim, grad: fx.indGrad }, ctx);
    // the neon edge only on boxes / bands, not full-height shading (a session background, bgcolor) or slivers
    if (z && z.e && !(H < c.height * 0.9 && W >= 6 && H >= 3)) z.e = null;
    return heat(z);
  }
  // An indicator's LEVEL line (prints, pivots, session levels): straight horizontal lines in a solid stroke. Never the
  // grid (TradingView's grid colour, or any grey when that isn't known), the crosshair (top canvas), the dotted price
  // line (candle colour + dashed), or an order / position line: those always have a solid price tag on the same row.
  const labelRows = new WeakMap();   // canvas -> [{ y, t }] centres (device px) of solid tags drawn on it lately
  // The rows of the tags drawn in the latest paint that drew any (a line is usually drawn before this paint's tags, so
  // that's the previous paint's), however long ago that was: a still chart repaints rarely. (Rows used to be kept for 20 s, so a tag
  // that moved (dragging the price scale, an order line moving) left a trail of rows behind it, and any level line
  // that crossed the trail went back to its own colour.)
  function noteLabelRow(ctx, yDev) {
    const c = ctx.canvas; let a = labelRows.get(c); if (!a) { a = []; a.last = -1; a.prev = -1; labelRows.set(c, a); }
    if (frameNo !== a.last) { a.prev = a.last; a.last = frameNo; for (let j = a.length - 1; j >= 0; j--) if (a[j].f < a.prev) a.splice(j, 1); }
    const i = a.findIndex((e) => Math.abs(e.y - yDev) <= 3);
    if (i >= 0) a[i] = { y: yDev, f: frameNo }; else { a.push({ y: yDev, f: frameNo }); if (a.length > 60) a.shift(); }
  }
  const onLabelRow = (c, yDev) => { const a = labelRows.get(c); if (!a) return false;
    for (const e of a) if (e.f === a.last && Math.abs(e.y - yDev) <= 6) return true; return false; };
  function levelLine(ctx, c, cur) {
    const z = hzs.get(ctx); if (!z || !z.ok || !z.n || z.y === null || isTop(c) || ctx.getLineDash().length) return false;
    const r = rgbKey(cur); if (!r) return false;
    const grid = knownLines().grid; if (grid.size ? grid.has(r.key) : greyish(cur)) return false;
    if (onLabelRow(c, z.y)) return false;
    // By colour: once a colour has been a level it stays one (no flashing back as lines move or as more levels appear);
    // the price-tag check above still runs on every draw, row by row.
    // A colour not known as a level yet is drawn as it is and decided once this paint is over: no price tag on its row
    // by then (an order line's tag is painted just after its line) = an indicator's level. It's one from then on, and
    // this line is drawn again in your style right away, before the browser shows the frame. (It used to stay in its
    // own colour for ~1 s and then have the whole chart redrawn: a flash of the original colour on every new level,
    // every time a chart opened.)
    const key = r.key, st = levelFirst.get(key);
    if (st === true) return true;
    if (st === undefined) { if (levelFirst.size > 300) levelFirst.delete(levelFirst.keys().next().value); levelFirst.set(key, false); }
    notePendLevel(ctx, c, z, cur, key);
    return false;
  }
  const levelFirst = new Map();   // "r,g,b" -> true once a level line in that colour was seen with no tag on its row
  let levelPend = null;           // this paint's lines in a colour not known as a level yet
  function notePendLevel(ctx, c, z, cur, key) {
    if (!levelPend) { levelPend = []; queueMicrotask(settleLevels); }
    if (levelPend.length >= 40) return;
    const b = pathBox.get(ctx), t = ctx.getTransform(), k = Math.hypot(t.a, t.b) || 1;
    levelPend.push({ ctx, c, y: z.y, key, cur, one: z.n === 1, x0: b ? b.x0 : null, x1: b ? b.x1 : null, lw: ctx.lineWidth * k, alpha: ctx.globalAlpha, cap: ctx.lineCap, comp: ctx.globalCompositeOperation });
  }
  function settleLevels() {
    const list = levelPend; levelPend = null; if (!list || !on) return;
    for (const e of list) {
      if (onLabelRow(e.c, e.y)) continue;                       // a tag on its row: an order / position line, left as it is
      levelFirst.set(e.key, true);
      // drawn again only if your settings change it (else it's already right), and only a single straight line
      const changes = (fx.indMode !== "own" && glowable(e.cur)) || (fx.indCustom && fx.indCustom[e.key]) || fx.lineGlow > 0;
      if (!changes || !e.one || e.x0 === null || e.x1 - e.x0 < 2) continue;
      const g = e.ctx; g.save();
      try { g.setTransform(1, 0, 0, 1, 0, 0); strokeDesc.set.call(g, e.cur); g.lineWidth = e.lw; g.setLineDash([]); g.globalAlpha = e.alpha; g.lineCap = e.cap; g.globalCompositeOperation = e.comp;
        const p = new Path2D(); p.moveTo(e.x0, e.y); p.lineTo(e.x1, e.y);
        proto.stroke.call(g, p);                                  // through the hook: it's styled like any indicator line
      } catch {} finally { g.restore(); }
    }
  }
  // solid boxes drawn on the chart lately (an indicator's label, a table cell): text drawn inside one keeps its colours
  const solidBoxes = new WeakMap();   // ctx -> [{ x0, y0, x1, y1, t }] in device px
  function noteSolidBox(ctx, x0, y0, x1, y1) {
    let a = solidBoxes.get(ctx); if (!a) { a = []; solidBoxes.set(ctx, a); }
    a.push({ x0: Math.min(x0, x1), y0: Math.min(y0, y1), x1: Math.max(x0, x1), y1: Math.max(y0, y1), t: performance.now() }); if (a.length > 40) a.shift();
  }
  function inSolidBox(ctx, x, y) {
    const a = solidBoxes.get(ctx); if (!a || !a.length) return false;
    const t = ctx.getTransform(), X = (x || 0) * (t.a || 1) + t.e, Y = (y || 0) * (t.d || 1) + t.f, now = performance.now();
    for (let i = a.length - 1; i >= 0; i--) { const b = a[i]; if (now - b.t > 150) break; if (X >= b.x0 - 2 && X <= b.x1 + 2 && Y >= b.y0 - 2 && Y <= b.y1 + 2) return true; }
    return false;
  }
  const origStrokeText = proto.strokeText;
  // TradingView draws some indicator text (Pivot Points' R1 / P / S1 …) ONCE into a hidden canvas and pastes that
  // picture onto the chart. Remember the text written into hidden canvases (only canvases holding nothing but text);
  // when one is pasted onto the chart, paste a restyled copy instead, built once per change (cheap to paste).
  const hiddenText = new WeakMap();   // hidden canvas -> { ops: [...], mixed, w, h, ver }
  function hiddenOf(c) { let h = hiddenText.get(c);
    if (!h || h.w !== c.width || h.h !== c.height) { h = { ops: [], mixed: false, w: c.width, h: c.height, ver: (h ? h.ver : 0) + 1 }; hiddenText.set(c, h); } return h; }
  function noteHiddenText(ctx, a) { const c = ctx.canvas; if (c.width > 800 || c.height > 4000) return; const h = hiddenOf(c);
    if (h.ops.length > 300) { h.mixed = true; return; }
    h.ops.push({ a: a.slice(), font: ctx.font, fill: String(origFillDesc.get.call(ctx)), align: ctx.textAlign, base: ctx.textBaseline, tf: ctx.getTransform() }); h.ver++; }
  function noteHiddenOther(ctx) { const c = ctx.canvas; if (c && !c.isConnected) { const h = hiddenText.get(c); if (h && !h.mixed) { h.mixed = true; h.ver++; } } }
  function noteHiddenClear(ctx, x, y, w, h0) { const c = ctx.canvas; if (!c || c.isConnected) return; const t = ctx.getTransform();
    if (Math.abs(w * (t.a || 1)) >= c.width - 1 && Math.abs(h0 * (t.d || 1)) >= c.height - 1) { const h = hiddenOf(c); h.ops = []; h.mixed = false; h.ver++; } }
  const styledCopies = new WeakMap();  // hidden canvas -> { key, canvas }
  function styledCopy(img) {
    const h = hiddenText.get(img); if (!h || h.mixed || !h.ops.length || h.w !== img.width || h.h !== img.height) return null;
    const L = window.__bdCandleLooks; if (!L || !L.chartText) return null;
    const o = { mode: fx.txtMode, color: fx.txtColor, outline: fx.txtOutline, size: 0, bg: fx.bg || "dark", up: candles && candles.upHex };   // (no size change: the picture has a fixed size)
    const key = h.ver + "|" + JSON.stringify(o), s0 = styledCopies.get(img); if (s0 && s0.key === key) return s0.canvas;
    const cv = (s0 && s0.canvas) || document.createElement("canvas"); cv.width = img.width; cv.height = img.height;
    const g = cv.getContext("2d"), k = txtK(g); let changed = false;
    for (const op of h.ops) { g.setTransform(op.tf); g.font = op.font; origFillDesc.set.call(g, op.fill); g.textAlign = op.align; g.textBaseline = op.base;
      if (L.chartText(g, k, op.a, o)) changed = true; else origText.apply(g, op.a); }
    const out = changed ? cv : null; styledCopies.set(img, { key, canvas: out || cv }); if (!changed) styledCopies.set(img, { key, canvas: null }); return out;
  }
  const txtK = (ctx) => ({ fill: (v) => origFillDesc.set.call(ctx, v), stroke: (v) => strokeDesc.set.call(ctx, v),
    text: (...a) => origText.apply(ctx, a), strokeText: (...a) => origStrokeText.apply(ctx, a) });
  // draw a zone: its fill (glowing only if it has no edge), then its neon edge with the glow. stroke = draws the edge.
  function drawZone(ctx, z, fill, stroke) {
    const pF = ctx.fillStyle, pSB = ctx.shadowBlur, pSC = ctx.shadowColor;
    origFillDesc.set.call(ctx, z.f); if (z.glow > 0 && !z.e) { ctx.shadowColor = z.g; ctx.shadowBlur = 3 + z.glow * 22; }
    const r = fill(); origFillDesc.set.call(ctx, pF); ctx.shadowBlur = pSB; ctx.shadowColor = pSC;
    if (z.e) {
      const pS = strokeDesc.get.call(ctx), pW = ctx.lineWidth, pD = ctx.getLineDash(), sx = ctx.getTransform().a || 1;
      strokeDesc.set.call(ctx, z.e); ctx.lineWidth = Math.max(1, (typeof devicePixelRatio === "number" && devicePixelRatio) || 1) / sx; ctx.setLineDash([]);
      if (z.glow > 0) { ctx.shadowColor = z.g; ctx.shadowBlur = 3 + z.glow * 18; }
      stroke();
      strokeDesc.set.call(ctx, pS); ctx.lineWidth = pW; ctx.setLineDash(pD); ctx.shadowBlur = pSB; ctx.shadowColor = pSC;
    }
    return r;
  }
  function noteFill(col) { if (typeof col === "string" && tally.size < 300) tally.set(col, (tally.get(col) || 0) + 1); }
  function learnedFromDrawing() {
    const cands = [...tally].filter(([c, n]) => n >= 20 && glowable(c) && !/rgba\(.*,\s*0?\.\d+\)$/.test(c)).sort((a, b) => b[1] - a[1]).slice(0, 2);
    tally.clear();
    if (cands.length < 2) return lastLearned;
    const hue = (c) => { const [R, G, B] = rgbKey(c).key.split(",").map(Number), mx = Math.max(R, G, B), mn = Math.min(R, G, B);
      if (mx === mn) return 0; let h = mx === R ? (G - B) / (mx - mn) : mx === G ? 2 + (B - R) / (mx - mn) : 4 + (R - G) / (mx - mn); return (h * 60 + 360) % 360; };
    const d = (c) => Math.min(Math.abs(hue(c) - 140), 360 - Math.abs(hue(c) - 140)); // distance from green
    const [a, b] = cands.map(([c]) => c);
    lastLearned = d(a) <= d(b) ? [[a, "up"], [b, "down"]] : [[b, "up"], [a, "down"]];
    return lastLearned;
  }
  let lastLearned = [];
  learnSides();
  setInterval(learnSides, 2000); // cheap: picks up chart/style/colour changes the user makes

  // Only recolour inside chart panes, never on the price/time axes (keeps label text intact).
  const paneCache = new WeakMap();
  function isPane(canvas) {
    if (!canvas) return false;
    let v = paneCache.get(canvas);
    if (v === undefined) {
      v = !!(canvas.closest && canvas.closest(".chart-markup-table") && !canvas.closest(".price-axis, .time-axis, [class*='price-axis'], [class*='time-axis']"));
      paneCache.set(canvas, v);
    }
    return v;
  }

  function remap(v) {
    if (!candles || typeof v !== "string") return v;
    const remapCache = candles.cache || remapCacheMain;    // each chart its own (charts can have their own colours)
    let out = remapCache.get(v);
    if (out !== undefined) return out;
    out = v;
    const r = rgbKey(v);
    // see-through fills in the candle colour that aren't candles: the Long / Short position tool's areas use
    // TradingView's own up / down colours at ~20%, and turned into your candle colours (a white box with light
    // candles). Volume (50%) and other candle parts stay recoloured.
    const side = r && !(r.a !== null && +r.a < 0.4) && sides.get(r.key);
    if (side) {
      const c = side === "up" ? candles.up : candles.down;
      out = r.a === null || r.a === "1" ? (side === "up" ? candles.upHex : candles.downHex) : `rgba(${c[0]},${c[1]},${c[2]},${r.a})`;
    }
    if (remapCache.size < 800) remapCache.set(v, out);
    return out;
  }

  const axisCache = new WeakMap();
  function isAxis(canvas) {
    if (!canvas) return false;
    let v = axisCache.get(canvas);
    if (v === undefined) {
      v = !!(canvas.closest && canvas.closest(".price-axis, .time-axis, [class*='price-axis'], [class*='time-axis']"));
      axisCache.set(canvas, v);
    }
    return v;
  }

  // Fills (candle bodies, wicks, volume, price-label badges) are recoloured as the colour is set.
  const strokeDesc = Object.getOwnPropertyDescriptor(proto, "strokeStyle");
  {
    const d = Object.getOwnPropertyDescriptor(proto, "fillStyle");
    Object.defineProperty(proto, "fillStyle", {
      configurable: true,
      enumerable: d.enumerable,
      get: d.get,
      set(v) {
        const c = this.canvas;
        this.__bdFill = v;
        d.set.call(this, candles && (isPane(c) || (fx.scaleLabels && isAxis(c))) ? remap(v) : v);
      },
    });
  }

  // Strokes are decided at stroke() time, when we know the shape of the path:
  //  - segment paths (bars, last-price line: ~1 lineTo per moveTo) get candle colours
  //  - continuous polylines (indicators: 1 moveTo + many lineTo) keep their own colour
  //  - any colourful, visible line can glow; grid (faint) and crosshair (grey) never do
  const segs = new WeakMap();
  const origBegin = proto.beginPath, origMove = proto.moveTo, origLine = proto.lineTo, origStroke = proto.stroke;
  // hz: is the path built so far only horizontal straight lines (an indicator's level lines, like prints)? y = device y
  const hzs = new WeakMap();   // ctx -> { ok, n, y, py }
  proto.beginPath = function () { segs.set(this, [0, 0]); if (on) hzs.set(this, { ok: true, n: 0, y: null, py: null }); if (on && (fx.bracketOn || styling())) lastSeg.set(this, null); if (on) pathBox.delete(this); return origBegin.call(this); };
  proto.moveTo = function (x, y) { const k = segs.get(this); if (k) k[0]++;
    if (on) { const z = hzs.get(this); if (z && z.ok) { const t = this.getTransform(); z.py = y * (t.d || 1) + t.f; if (z.y === null) z.y = z.py; } }
    if (on) growBox(this, x, y);
    if (on && (fx.bracketOn || styling())) { const t = this.getTransform(); lastSeg.set(this, { x0: x * (t.a || 1) + t.e, y0: y * (t.d || 1) + t.f, x1: null, y1: null }); }
    return origMove.call(this, x, y); };
  proto.lineTo = function (x, y) { const k = segs.get(this); if (k) k[1]++;
    if (on) { const z = hzs.get(this); if (z && z.ok) { const t = this.getTransform(), Y = y * (t.d || 1) + t.f; if (z.py === null || Math.abs(Y - z.py) > 1.5) z.ok = false; else { z.n++; z.py = Y; } } }
    if (on) growBox(this, x, y);
    if (on && (fx.bracketOn || styling())) { const s = lastSeg.get(this), t = this.getTransform(); if (s) { s.x1 = x * (t.a || 1) + t.e; s.y1 = y * (t.d || 1) + t.f; } }
    return origLine.call(this, x, y); };

  // ---------- chart styling: grid, crosshair, price line ----------
  // TradingView draws each of these as ONE straight segment across the whole pane:
  //   grid lines      — faint grey, on the pane's main canvas
  //   crosshair       — grey, on the pane's TOP canvas (the overlay it redraws as you move the pointer)
  //   last-price line — dotted, in the candle colour, horizontal, on the main canvas
  // so we tell them apart by shape + canvas + colour and restyle them at draw time.
  const styling = () => fx.gridOn || fx.chOn || fx.plOn || fx.sbOn || fx.axOn;
  const topCache = new WeakMap();
  function isTop(c) { let v = topCache.get(c); if (v === undefined) { const all = c.parentElement ? [...c.parentElement.querySelectorAll("canvas")] : []; v = all.length > 1 && all.indexOf(c) > 0; topCache.set(c, v); } return v; }
  const greyCache = new Map();
  function greyish(col) {
    let v = greyCache.get(col); if (v !== undefined) return v;
    const r = rgbKey(col); v = false;
    if (r) { const [R, G, B] = r.key.split(",").map((n) => n / 255), mx = Math.max(R, G, B), mn = Math.min(R, G, B), l = (mx + mn) / 2;
      const sat = mx === mn ? 0 : (mx - mn) / (1 - Math.abs(2 * l - 1)); v = sat < 0.2 || (r.a !== null && +r.a <= 0.3); }
    if (greyCache.size < 200) greyCache.set(col, v); return v;
  }
  function candleCol(col) { const r = rgbKey(col); if (!r) return false; if (sides.has(r.key)) return true;
    return !!candles && (r.key === candles.up.join(",") || r.key === candles.down.join(",")); }
  const DASH = { solid: [], dotted: [1, 3], dashed: [5, 5] };
  function pick(opt, cur) { return opt === "candle" ? (candles ? candles.upHex : cur) : opt || fx.accent || (candles ? candles.upHex : cur); }
  const xhair = new WeakMap();      // top canvas -> { x, y, t } of the crosshair lines drawn this frame
  // TradingView's own configured colours for each line kind (read from the chart, refreshed every few seconds).
  // Exact colour matches beat the shape heuristics: session breaks, for example, are grey dashed lines like the grid.
  let tvLines = { grid: new Set(), sb: new Set(), ch: new Set(), t: 0 };
  function knownLines() {
    const now = performance.now(); if (now - tvLines.t < 3000) return tvLines;
    const next = { grid: new Set(), sb: new Set(), ch: new Set(), t: now };
    const add = (set, v) => { try { const r = rgbKey(typeof v === "function" ? v() : v); if (r) set.add(r.key); } catch {} };
    // the charts: as everywhere else, plus TradingView's charting library (nq.vision), whose chart API is tradingViewApi
    const ws = chartWidgets();
    try { const a = window.tradingViewApi && window.tradingViewApi._activeChartWidgetWV && window.tradingViewApi._activeChartWidgetWV.value(); if (a && !ws.includes(a)) ws.push(a); } catch {}
    for (const w of ws) {
      try {
        const cw = w._chartWidget || w, m = cw.model().model ? cw.model().model() : cw.model(), P = m.properties().childs();
        const pp = P.paneProperties.childs();
        add(next.grid, pp.vertGridProperties.childs().color.value()); add(next.grid, pp.horzGridProperties.childs().color.value());
        add(next.ch, pp.crossHairProperties.childs().color.value());
        add(next.sb, P.chartEventsSourceProperties.childs().breaks.childs().color.value());
      } catch {}
    }
    tvLines = next; return tvLines;
  }
  function styleLine(ctx, c, args) {
    const k = segs.get(ctx); if (!k || k[0] !== 1 || k[1] !== 1) return false;
    const s = lastSeg.get(ctx); if (!s || s.x1 === null) return false;
    const horiz = Math.abs(s.y0 - s.y1) <= 1 && Math.abs(s.x1 - s.x0) >= c.width * 0.6;
    const vert = Math.abs(s.x0 - s.x1) <= 1 && Math.abs(s.y1 - s.y0) >= c.height * 0.6;
    if (!horiz && !vert) return false;
    const cur = strokeDesc.get.call(ctx), top = isTop(c);
    let part = null;
    if (isAxis(c)) {                                     // scale border: the edge line of a price / time scale
      const edge = vert ? Math.min(s.x0, c.width - s.x0) <= 3 : Math.min(s.y0, c.height - s.y0) <= 3;
      if (!edge || !fx.axOn) return false; part = "ax";
    }
    else if (top) { if (fx.chOn && (greyish(cur) || knownLines().ch.has((rgbKey(cur) || {}).key))) part = "ch"; }
    else if (vert && knownLines().sb.has((rgbKey(cur) || {}).key) && !knownLines().grid.has((rgbKey(cur) || {}).key)) { if (!fx.sbOn) return false; part = "sb"; }
    else if (vert && fx.sbOn && !greyish(cur) && !candleCol(cur) && ctx.getLineDash().length) part = "sb";
    else if (horiz && fx.plOn && candleCol(cur) && ctx.getLineDash().length) part = "pl";
    // the grid: where TradingView tells us its grid colour, only lines in that colour. A white / grey level an indicator
    // draws across the chart (session high, a zone's edge) must never be restyled or hidden as if it were grid.
    else if (fx.gridOn && greyish(cur) && (!knownLines().grid.size || knownLines().grid.has((rgbKey(cur) || {}).key))) part = "grid";
    if (!part) return false;
    if ((part === "grid" && fx.gridStyle === "none") || (part === "sb" && fx.sbStyle === "none") || (part === "ax" && fx.axStyle === "none")) return true;   // hidden
    const sx = ctx.getTransform().a || 1;
    const opt = part === "grid" ? [fx.gridColor, fx.gridW, fx.gridStyle] : part === "ch" ? [fx.chColor, fx.chW, fx.chStyle]
      : part === "sb" ? [fx.sbColor, fx.sbW, fx.sbStyle] : part === "ax" ? [fx.axColor, fx.axW, "solid"] : [fx.plColor, fx.plW, fx.plStyle];
    const col = pick(opt[0], cur), pS = cur, pLW = ctx.lineWidth, pD = ctx.getLineDash(), pA = ctx.globalAlpha;
    strokeDesc.set.call(ctx, col);
    ctx.lineWidth = (1 + opt[1]) / sx;
    ctx.setLineDash(DASH[opt[2]].map((d) => d * (1 + opt[1] * 0.5) / sx));
    if (part === "grid") ctx.globalAlpha = pA * fx.gridAlpha;
    origStroke.apply(ctx, args);
    strokeDesc.set.call(ctx, pS); ctx.lineWidth = pLW; ctx.setLineDash(pD); ctx.globalAlpha = pA;
    // glow at the pointer: once both crosshair lines of this frame are known, a soft light where they cross
    if (part === "ch" && fx.chGlow) {
      // each line keeps its own time: panes the pointer isn't over only draw the vertical line, and an old horizontal
      // position there would light up a second glow
      const now = performance.now(), m = xhair.get(ctx) || {};
      if (vert) { m.x = s.x0; m.xt = now; } else { m.y = s.y0; m.yt = now; }
      xhair.set(ctx, m);
      if (m.x != null && m.y != null && Math.abs((m.xt || 0) - (m.yt || 0)) < 30) {
        if (window.__bdGlowDebug) window.__bdGlowDebug.push([Math.round(m.x), Math.round(m.y), String(cur)]);   // tests
        const t = ctx.getTransform(), R = 34 * ((typeof devicePixelRatio === "number" && devicePixelRatio) || 1);
        ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
        const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, R), rgb = rgbKey(fx.chGlowColor ? pick(fx.chGlowColor, cur) : col);   // its own colour, or the crosshair's
        const k3 = rgb ? rgb.key : "255,255,255";
        g.addColorStop(0, `rgba(${k3},0.45)`); g.addColorStop(0.35, `rgba(${k3},0.14)`); g.addColorStop(1, `rgba(${k3},0)`);
        origFillDesc.set.call(ctx, g); origFillRaw.call(ctx, m.x - R, m.y - R, R * 2, R * 2);
        ctx.restore(); m.x = m.y = null; void t;
      }
    }
    return true;
  }
  const origFillRaw = proto.fillRect;

  const glowCache = new Map();
  function glowable(col) {
    let v = glowCache.get(col);
    if (v !== undefined) return v;
    const r = rgbKey(col); v = false;
    if (r && (r.a === null || +r.a >= 0.35)) {
      const [R, G, B] = r.key.split(",").map((n) => n / 255);
      const mx = Math.max(R, G, B), mn = Math.min(R, G, B), l = (mx + mn) / 2;
      const sat = mx === mn ? 0 : (mx - mn) / (1 - Math.abs(2 * l - 1));
      v = !(sat < 0.15 && l > 0.12 && l < 0.88); // greys (crosshair, borders) don't glow; white/colours do
    }
    if (glowCache.size < 400) glowCache.set(col, v);
    return v;
  }

  proto.stroke = function (path) {
    const c = this.canvas;
    if (c && !c.isConnected) noteHiddenOther(this);
    if (on && path === undefined && c && shapedBox.has(this)) { const b = rectPath(this); if (b && isShapedOutline(this, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0)) return; }
    if (on && path === undefined && c && styling() && (isPane(c) || (fx.axOn && isAxis(c))) && styleLine(this, c, arguments)) return;
    // Bracket level line: a wide, horizontal stroke sitting at a pill's height. Recolour / thicken it so the whole
    // bracket level is easy to see. Done before the candle/glow path because it can be on when those are off.
    if (on && fx.bracketOn && (fx.bracketLineColor || fx.bracketLineW > 0) && c && path === undefined && isPane(c)) {
      const s = lastSeg.get(this);
      // horizontal segment (any width) whose y lands exactly on a pill row — the pill-row match is the real filter
      // (so grid lines, which never sit on a pill row, are left alone), covering both stubs either side of the box.
      const hz = s && s.x1 !== null && Math.abs(s.y0 - s.y1) <= 1.5 && Math.abs(s.x1 - s.x0) >= 20;
      const cur0 = hz ? strokeDesc.get.call(this) : null, lk = hz ? lineKey(cur0) : null, yRow = hz ? (s.y0 + s.y1) / 2 : 0;
      if (hz && (bracketRowSign(this, yRow) !== null || knownBracketLine(this, yRow, lk, s))) {
        const sx = this.getTransform().a || 1, cur = strokeDesc.get.call(this);
        const col = fx.bracketLineColor || cur;
        const pS = cur, pLW = this.lineWidth;
        if (col !== cur) strokeDesc.set.call(this, col);
        if (fx.bracketLineW > 0) this.lineWidth = Math.max(pLW, (fx.bracketLineW + 1) / sx);
        origStroke.apply(this, arguments);
        if (col !== cur) strokeDesc.set.call(this, pS);
        this.lineWidth = pLW;
        notePendLine(this, s, cur0, lk, true);   // (its label, drawn next, tells where labels sit: see knownBracketLine)
        return;
      }
      if (hz) notePendLine(this, s, cur0, lk);   // maybe a bracket whose label comes next: see confirmPendLines
    }
    if (!on || !c || !isPane(c)) return origStroke.apply(this, arguments);
    const k = segs.get(this) || [0, 0];
    // only paths we SAW built from short segments (bars, last-price line) count as candle strokes;
    // Path2D or paths built some other way (indicators) keep their own colour
    const polyline = path !== undefined || k[0] < 1 || k[1] > k[0] * 2 + 1;
    const cur = strokeDesc.get.call(this), L = window.__bdCandleLooks;
    // an indicator line: a Path2D, or a path of 3+ segments, not in a candle colour
    // (candle wicks / borders can be Path2D in TradingView's own candle colours: those aren't indicators)
    const candleCol = typeof cur === "string" && ((candles && remap(cur) !== cur) || (() => { const r = rgbKey(cur); return !!r && sides.has(r.key); })());
    // a line of one of your drawings (a trend line, a rectangle's border): listed and styled like an indicator line,
    // but the all-indicators colour only reaches it with "Your drawings: Style them too"
    // (looked up on the chart right then only when the answer changes how it's drawn: indicator colours, Each indicator
    // or the Glow slider are on; otherwise it only names it in the panel's list, and the list of a few seconds ago does)
    const restyles = fx.indMode !== "own" || fx.lineGlow > 0 || (fx.indCustom && Object.keys(fx.indCustom).length > 0);
    const dk = typeof cur === "string" && !candleCol && (drawCols.size || restyles) ? rgbKey(cur) : null;
    const isDraw = !!dk && (restyles ? drawColHas(dk.key) : drawCols.has(dk.key));
    const indLine = (polyline && typeof cur === "string" && !candleCol && (path !== undefined || k[1] >= 3)) || (isDraw && !candleCol)
      || (path === undefined && typeof cur === "string" && !candleCol && levelLine(this, c, cur));
    if (indLine && L && L.noteSeen) L.noteSeen(cur, "line");                     // for the panel's "Each indicator" list
    const custom = fx.indCustom && Object.keys(fx.indCustom).length > 0, indOn = fx.indMode !== "own" || custom;
    if (!(candles || fx.lineGlow > 0 || indOn)) return origStroke.apply(this, arguments);
    let col = candles && !polyline ? remap(cur) : cur, gcol = col, glowAmt = fx.lineGlow, extraW = 0;
    if (indOn && indLine && (custom || glowable(cur))) {
      const r = L && L.indicator && L.indicator(this, cur, { mode: glowable(cur) && (!isDraw || fx.drawOn) ? fx.indMode : "own", color: fx.indColor, up: candles && candles.upHex, down: candles && candles.downHex, accent: fx.accent, custom: fx.indCustom, grad: fx.indGrad });
      if (r && r.hide) return;                                                    // hidden in "Each indicator"
      if (r) { col = r.s; gcol = r.g; if (r.glow !== undefined) glowAmt = r.glow; if (r.w) extraW = r.w; }
    }
    const glow = glowAmt > 0 && (glowable(gcol) || (custom && indLine));
    if (col === cur && !glow && !extraW) return origStroke.apply(this, arguments);
    const pSB = this.shadowBlur, pSC = this.shadowColor, pLW = this.lineWidth;
    if (col !== cur) strokeDesc.set.call(this, col);
    if (glow) { this.shadowColor = gcol; this.shadowBlur = 2 + glowAmt * 16; }
    if (extraW) this.lineWidth = pLW * (1 + extraW * 0.75);
    origStroke.apply(this, arguments);
    if (col !== cur) strokeDesc.set.call(this, cur);
    if (glow) { this.shadowBlur = pSB; this.shadowColor = pSC; }
    if (extraW) this.lineWidth = pLW;
  };

  // Same redraw trick as content.js: TradingView only rebuilds canvases when the chart is re-shown.
  // Redraw the chart. Two kinds: a soft redraw via TradingView's model.fullUpdate() (no blink), and a full
  // rebuild by hiding the chart for two frames (guarded by a DOM flag so two rebuilds never stack).
  function apiRepaint() {
    let done = false;
    for (const w of chartWidgets()) {
      try { const cw = w._chartWidget || w, m = cw.model().model ? cw.model().model() : cw.model(); m.fullUpdate(); done = true; } catch {}
    }
    return done;
  }
  // Redraws are made to feel instant: every change gets TradingView's own light redraw on the very next frame (no
  // blink). The heavier rebuild (hide the chart for two frames) is only needed for things TradingView caches, like
  // volume-bar colours, so it runs ONCE, after you stop changing things, instead of on every step of a colour drag.
  // A rebuild hides the charts for two frames. Never while you're holding the mouse (dragging the divider between
  // charts, a drawing, an order line) or right after the layout changed: hidden mid-resize, a chart measures itself as
  // 0 px and can stay the wrong size, showing the page behind it. It waits until you let go and things settle.
  let pointerDown = false, lastResize = 0;
  addEventListener("pointerdown", () => { pointerDown = true; }, true);
  addEventListener("pointerup", () => { pointerDown = false; lastResize = performance.now(); }, true);
  addEventListener("pointercancel", () => { pointerDown = false; }, true);
  addEventListener("resize", () => { lastResize = performance.now(); });
  try { new ResizeObserver(() => { lastResize = performance.now(); }).observe(document.documentElement); } catch {}
  (function watchCharts() {   // charts resizing inside the page (their own size, not the window's)
    try { const ro = new ResizeObserver(() => { lastResize = performance.now(); }); let seen = new WeakSet();
      setInterval(() => { for (const el of document.querySelectorAll(".chart-container")) if (!seen.has(el)) { seen.add(el); ro.observe(el); } }, 1000); } catch {}
  })();
  function hardRebuild() {
    if (pointerDown || performance.now() - lastResize < 500) { clearTimeout(hardT); hardT = setTimeout(hardRebuild, 300); return; }
    stats.hard++;
    document.querySelectorAll(".chart-container").forEach((el) => {
      if (el.dataset.bdRepaint) return;
      el.dataset.bdRepaint = "1";
      el.style.display = "none";
      requestAnimationFrame(() => requestAnimationFrame(() => { el.style.display = ""; delete el.dataset.bdRepaint; }));
    });
  }
  // toneOnly: only the wallpaper's brightness behind the scale moved (e.g. while a chart is moved or resized). On
  // platforms without TradingView's own redraw (prop firms, nq.vision) that never triggers a rebuild: they redraw
  // themselves a moment later anyway, and rebuilding on every step of a divider drag hid the charts over and over.
  // Price in a zone animates (a soft pulse, the Spotlight, the Shimmer sheen), but TradingView only redraws a still
  // chart when something changes. While a zone price is in was drawn in the last second, ask for TradingView's own
  // light redraw ~8 times a second (4 on Lite); it stops by itself when price leaves the zone. Never with reduced motion.
  let zoneAnimAt = -1e9;
  const reduceZ = (() => { try { return matchMedia("(prefers-reduced-motion: reduce)"); } catch { return { matches: false }; } })();
  // Kept light for trading: TradingView's light redraw (not a full one), at most 4 times a second, never in Lite / Power
  // saver (the zone stays lit, just still), and never right after you touched the chart (it redraws then anyway).
  let inputAt = 0; for (const t of ["pointerdown", "pointermove", "wheel", "keydown"]) addEventListener(t, () => { inputAt = performance.now(); }, { capture: true, passive: true });
  (function zoneAnim() { setTimeout(zoneAnim, 250);
    const now = performance.now();
    if (!on || !fx.zoneReact || fx.zoneReact === "off" || window.__bdLite || htmlEl().hasAttribute("data-bd-hold") || reduceZ.matches || document.hidden || now - zoneAnimAt > 1000 || now - inputAt < 300) return;
    let done = false;
    for (const w of chartWidgets()) { try { const cw = w._chartWidget || w, m0 = cw.model(), m = m0.model ? m0.model() : m0; if (m.lightUpdate) { m.lightUpdate(); done = true; } } catch {} }
    if (!done) apiRepaint(); })();
  function forceRepaint(softOnly, toneOnly) {
    if (!softRaf) softRaf = requestAnimationFrame(() => {
      softRaf = 0; stats.soft++;
      if (!apiRepaint() && !toneOnly) { clearTimeout(hardT); hardT = setTimeout(hardRebuild, 160); }   // no API here (some platforms): rebuild instead
    });
    if (!softOnly) { clearTimeout(hardT); hardT = setTimeout(hardRebuild, 700); }
  }
  document.addEventListener("bd-repaint", () => forceRepaint(false));   // asked for by content.js
  // asked for by content.js before it decides a position has closed: a quiet market stops the chart redrawing, so the
  // position pill (our P&L signal) would go stale even though the trade is still open. A soft redraw refreshes it, no blink.
  document.addEventListener("bd-softrepaint", () => { try { apiRepaint(); } catch {} });
  // "Use dark theme" on Priism's card: switch TradingView's own theme setting (same as its menu's Dark theme switch)
  document.addEventListener("bd-theme-dark", () => { try { window.TradingViewApi.themes().setStdTheme("dark"); } catch {} });

  // ---------- helpers ----------
  const chartCache = new WeakMap();
  function inChart(canvas) {
    let v = chartCache.get(canvas);
    if (v === undefined) {
      v = !!(canvas.closest && canvas.closest(".chart-container, .chart-markup-table"));
      chartCache.set(canvas, v);
    }
    return v;
  }

  // ---------- light theme: lighten dark text on dark skins ----------
  const origText = proto.fillText;
  const origMeasure = proto.measureText;
  const darkCache = new Map();
  const scratch = document.createElement("canvas").getContext("2d");
  function isDark(style) {
    if (typeof style !== "string") return false;
    let v = darkCache.get(style);
    if (v === undefined) {
      scratch.fillStyle = "#000"; scratch.fillStyle = style;
      const m = scratch.fillStyle.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
      const rgb = m ? [1, 2, 3].map((i) => parseInt(m[i], 16)) : (scratch.fillStyle.match(/\d+/g) || [255, 255, 255]).slice(0, 3).map(Number);
      v = 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2] < 110;
      darkCache.set(style, v);
    }
    return v;
  }
  // Auto contrast: pick light/dark text from the measured wallpaper brightness, unless the user chose a colour.
  const AUTO_TEXT = { dark: "#e9ebf2", light: "#14161f" };
  const autoHalo = (tone) => ((tone || fx.bg) === "dark" ? "rgba(0,0,0,0.85)" : "rgba(255,255,255,0.9)");
  // Which tone is right behind this label? Uses the brightness profile of the strip behind the scale.
  const rectCache = new WeakMap();
  function toneAt(ctx, y) {
    const c = ctx.canvas;
    if (!isPriceAxis(c) || (!fx.profs.length && fx.prof.length < 6)) return fx.bg;
    let rc = rectCache.get(c), now = performance.now();
    if (!rc || now - rc.t > 1000) { rc = { r: c.getBoundingClientRect(), t: now }; rectCache.set(c, rc); }
    const t = ctx.getTransform(), cssY = rc.r.top + ((y * t.d + t.f) / c.height) * rc.r.height;
    // which chart is this price scale part of? (multi-chart layouts have one scale per chart)
    const cx = (rc.r.left + rc.r.right) / 2, cy = (rc.r.top + rc.r.bottom) / 2;
    const own = fx.profs.find((q) => cx >= q.l - 2 && cx <= q.r + 2 && cy >= q.t - 2 && cy <= q.b + 2);
    let prof = fx.prof, top = 0, height = innerHeight;
    if (own) { prof = own.p; top = own.t; height = Math.max(1, own.b - own.t); }
    if (!prof || prof.length < 6) return fx.bg;
    const row = Math.max(0, Math.min(prof.length - 1, Math.floor(((cssY - top) / height) * prof.length)));
    return prof[row] > 0.46 ? "light" : "dark";   // ~equal WCAG contrast for light vs dark text here
  }
  const paCache = new WeakMap();
  function isPriceAxis(c) { let v = paCache.get(c); if (v === undefined) { v = !!(c.closest && c.closest(".price-axis, [class*='price-axis']")); paCache.set(c, v); } return v; }
  const autoOn = () => !htmlEl().classList.contains("bd-over-mode") && !!fx.bg;
  const scaleStyled = () => fx.scaleText || fx.scaleGlow > 0 || fx.scaleBold || fx.scaleSize > 0 || fx.scaleFont !== "default" || autoOn();

  function styledFont(font) {
    let f = font;
    if (fx.scaleSize > 0) f = f.replace(/(\d+(?:\.\d+)?)px/, (m, n) => (+n + fx.scaleSize * 1.5) + "px");
    if (fx.scaleFont !== "default" && fx.scaleFamily) f = f.replace(/(\d+(?:\.\d+)?px)\s+.*$/, (m, sz) => sz + " " + fx.scaleFamily);
    if (fx.scaleBold && !/\bbold\b|\b[6-9]00\b/.test(f)) f = "bold " + f;
    return f;
  }
  function isScaleLabel(style) {           // tick labels, not text on coloured price badges
    const r = rgbKey(style);
    if (!r) return false;
    if (scaleTextKey) return r.key === scaleTextKey;
    return r.key !== "255,255,255";        // fallback when the theme colour is unknown
  }
  // Position lines show your open P&L as text on the chart ("+128.40 USD", "P&L: -45.00", "$-12.50"...).
  // We read that text as it's drawn, add up every position shown in the same frame, and publish the total
  // on <html data-ws-pnl> for content.js. Nothing leaves your computer.
  const PNL_RE = /^(?:p\s*(?:&|n|\/)?\s*l\s*:?\s*)?([+\-\u2212])?\s*([$\u20ac\u00a3\u00a5])?\s*([+\-\u2212])?\s*(\d{1,3}(?:,\d{3})*|\d+)(\.\d{1,2})\s*(usd|usdt|usdc|eur|gbp|jpy|aud|cad|chf|nzd|pts|points)?$/i;
  let pnlFrame = -1, pnlSum = 0, pnlUnit = "", pnlLastWrite = 0, frameNo = 0;
  (function tick() { frameNo++; requestAnimationFrame(tick); })();
  function notePnl(text, c) {
    if (!on || typeof text !== "string" || text.length > 40 || !isPane(c)) return;
    const m = text.trim().match(PNL_RE);
    if (!m) return;
    const hasPrefix = /^p/i.test(text.trim()), sign = m[1] || m[3], cur = m[2], code = m[6];
    if (!hasPrefix && !sign && !cur && !code) return;          // a bare number: price/qty, not P&L
    const v = parseFloat((m[4] + m[5]).replace(/,/g, "")) * (sign === "-" || sign === "\u2212" ? -1 : 1);
    if (frameNo !== pnlFrame) { pnlFrame = frameNo; pnlSum = 0; }
    pnlSum += v; pnlUnit = cur || (code ? code.toUpperCase() : "");
    if (!pnlQueued) { pnlQueued = true; queueMicrotask(publishPnl); }    // once this frame's drawing is done
  }
  // Publish the P&L as soon as it changes (the daily bar and the max-loss reminder react straight away), at most
  // 10 times a second; an unchanged value is refreshed once a second so the page knows the position is still open.
  let pnlQueued = false, pnlLastVal = null, pnlTrail = 0;
  function publishPnl() {
    pnlQueued = false;
    const now = performance.now(), val = Math.round(pnlSum * 100) / 100, since = now - pnlLastWrite;
    if (val === pnlLastVal ? since < 1000 : since < 100) {
      if (val !== pnlLastVal && !pnlTrail) pnlTrail = setTimeout(() => { pnlTrail = 0; publishPnl(); }, 100 - since + 5);   // don't drop a change
      return;
    }
    pnlLastWrite = now; pnlLastVal = val;
    htmlEl().setAttribute && htmlEl().setAttribute("data-ws-pnl", JSON.stringify({ v: val, unit: pnlUnit, ts: Date.now() }));
  }

  // ---------- bracket pills (the broker's TP / Stop / entry / P&L boxes TradingView draws on the chart) ----------
  // TradingView draws each pill as a small rounded box (a fillRect ~15-28px tall, <~170px wide) and then its
  // text in "bold 9px Verdana", centered. We can't read these through the chart API (they belong to the broker's
  // trading integration, not our drawings), but they DO pass through this canvas hook, so we restyle them here:
  // a stronger box behind the text (readable on busy wallpapers), a bigger font, and optional +/- colours.
  // Every broker pill (TP, Stop, entry, quantity, P&L) draws its text in Verdana — regular chart text uses a
  // sans-serif stack, so the font is the reliable signal. The box is only used so we have something to restyle;
  // we keep its size test loose and DPR-correct so wide multi-part pills and HiDPI screens still match.
  const BRACKET_FONT = /\bVerdana\b/i;
  const lastPill = new WeakMap();
  // A pill box was just drawn (rect or rounded path), in device px. Remember it (so the number drawn next is known to
  // be a pill) and its colour (green / red boxes tell profit from loss when the number has no + / - sign).
  // Returns the fill to draw instead (your colour, or a strengthened dark box), or null to keep TradingView's.
  function notePillBox(ctx, box) {
    const own = String(ctx.fillStyle);
    lastPill.set(ctx, { used: false, t: performance.now(), box, sign: boxSign(own) });
    if (!fx.bracketOn) { pillFill.delete(ctx); return null; }          // Streamer mode only: find the labels, don't restyle them
    if (bracketLines()) confirmPendLines(ctx, box);                     // its line, drawn a moment ago in its own colour
    if (fx.bracketFill) { pillFill.set(ctx, fx.bracketFill); return fx.bracketFill; }
    if (fx.bracketBack !== "keep") {
      const r = rgbKey(own), base = [16, 19, 28], rgb = r ? r.key.split(",").map(Number) : base;
      const k = tintK(rgb), al = fx.bracketBack === "solid" ? 1 : 0.88;
      const fill = `rgba(${rgb.map((v, i) => Math.round(base[i] + (v - base[i]) * k)).join(",")},${al})`;
      pillFill.set(ctx, fill); return fill;
    }
    pillFill.delete(ctx); return null;     // box unchanged: TradingView's own text already reads on it
  }
  // Streamer mode: a label's number becomes dots (keeping roughly its width, so the label doesn't jump)
  // Streamer mode, per the chosen P&L option. Money is anything with a currency sign or code.
  const MONEY_TXT = /[$\u20ac\u00a3\u00a5\u20b9]|\b(USD|EUR|GBP|JPY|AUD|CAD|CHF|USDT|USDC)\b/i;
  const TICKS_TXT = /([+\-\u2212]?)\s*([\d][\d.,]*)\s*(ticks?|pips?)\b/i;
  function privText(t) {
    const m = fx.privacyPnl;
    if (m === "show") return t;
    if (m === "hide") return maskNum(t);
    const s = String(t);
    if (MONEY_TXT.test(s)) return maskNum(s);
    if (m === "points" && fx.tickSize > 0) return s.replace(TICKS_TXT, (all, sg, n) => {
      const v = parseFloat(n.replace(/,/g, "")) * fx.tickSize; if (!isFinite(v)) return all;
      return `${sg}${+v.toFixed(fx.tickSize < 0.01 ? 5 : fx.tickSize < 1 ? 2 : 0)} pts`; });
    return s;
  }
  // the lot size / quantity pill: a plain whole number, no sign, money or unit
  const isQty = (t) => /^\s*\d{1,5}(\s*(x|lots?|contracts?|shares?))?\s*$/i.test(String(t));
  const maskNum = (t) => { const s = String(t); return s.replace(/[+\-\u2212]?\s*[$\u20ac\u00a3\u00a5]?\s*[\d][\d.,\s]*/g, (m) => "\u2022".repeat(Math.max(3, Math.min(7, m.replace(/\D/g, "").length)))); };
  function boxSign(col) {
    const r = rgbKey(col); if (!r) return 0; const [R, G, B] = r.key.split(",").map(Number);
    if (G > R + 40 && G >= B - 20) return 1;           // green-ish box: in profit
    if (R > G + 50 && R > B + 20) return -1;           // red-ish box: in loss
    return 0;
  }
  // Each indicator has a marker of its own set up (colour / glow / hide)? Then markers are checked even with Markers: Own
  let markEachSig = "", markEachV = false;
  const markEach = () => { const sig = fx.indCustom; if (sig !== markEachSig) { markEachSig = sig; markEachV = !!(sig && Object.keys(sig).length); } return markEachV; };
  // bounding box (device px) of the path being built, so rounded pill boxes (roundRect / arcs) are recognised too
  const pathBox = new WeakMap();
  function growBox(ctx, x, y) {
    const t = ctx.getTransform(), X = x * (t.a || 1) + t.e, Y = y * (t.d || 1) + t.f;
    const b = pathBox.get(ctx); if (!b) pathBox.set(ctx, { x0: X, y0: Y, x1: X, y1: Y });
    else { if (X < b.x0) b.x0 = X; if (X > b.x1) b.x1 = X; if (Y < b.y0) b.y0 = Y; if (Y > b.y1) b.y1 = Y; }
  }
  for (const name of ["rect", "roundRect"]) {
    const o = proto[name]; if (typeof o !== "function") continue;
    proto[name] = function (x, y, w, h) { if (on) { growBox(this, x, y); growBox(this, x + w, y + h); } return o.apply(this, arguments); };
  }
  // is the path being built just one straight-sided box (a rect(), or move + 3-4 lines along a box's edges)? Rectangle
  // drawings and many zone boxes are drawn like that; those can take a zone shape (rounded / pill)
  const pathPts = new WeakMap();   // ctx -> { r: rect calls, p: [[X,Y]...] (device px), bad }
  { const ob = proto.beginPath; proto.beginPath = function () { if (on) pathPts.delete(this); return ob.call(this); }; }
  for (const name of ["moveTo", "lineTo"]) { const o = proto[name];
    proto[name] = function (x, y) { if (on) { let q = pathPts.get(this); if (!q) { q = { r: 0, p: [], bad: false }; pathPts.set(this, q); }
      if (q.p.length < 7) { const t = this.getTransform(); q.p.push([x * (t.a || 1) + t.e, y * (t.d || 1) + t.f]); } else q.bad = true; } return o.apply(this, arguments); }; }
  { const o = proto.rect; proto.rect = function () { if (on) { let q = pathPts.get(this); if (!q) { q = { r: 0, p: [], bad: false }; pathPts.set(this, q); } q.r++; } return o.apply(this, arguments); }; }
  for (const name of ["arc", "arcTo", "bezierCurveTo", "quadraticCurveTo", "ellipse", "roundRect"]) { const o = proto[name]; if (typeof o !== "function") continue;
    proto[name] = function () { if (on) { let q = pathPts.get(this); if (!q) { q = { r: 0, p: [], bad: false }; pathPts.set(this, q); } q.bad = true; } return o.apply(this, arguments); }; }
  // a zone we just drew in a shape: its own square outline (a drawing's border, drawn right after) is left out, so
  // the rounded / pill border we drew is the only one
  const shapedBox = new WeakMap();
  function noteShaped(ctx, X, Y, W, H) { shapedBox.set(ctx, { X, Y, W, H, t: performance.now() }); }
  function isShapedOutline(ctx, X, Y, W, H) {
    const s = shapedBox.get(ctx); if (!s || performance.now() - s.t > 200) return false;
    return Math.abs(X - s.X) <= 3 && Math.abs(Y - s.Y) <= 3 && Math.abs(W - s.W) <= 5 && Math.abs(H - s.H) <= 5;
  }
  // the zone being drawn may have its own shape (Each indicator), else the one for all zones
  const zoneOwnOf = (ctx) => { const m = fx.indCustom; if (!ctx || !m) return null; const L = window.__bdCandleLooks;
    const r = L && L.keyOf(String(ctx.__bdFill !== undefined ? ctx.__bdFill : ctx.fillStyle)); return (r && m[r.k]) || null; };
  const zoneSt = (ctx) => { const e = zoneOwnOf(ctx); return { shape: (e && e.s) || fx.zoneShape, border: (e && e.b) || fx.zoneBorder, style: (e && e.y) || fx.zoneStyle }; };
  const zoneStyled = (ctx) => { const z = zoneSt(ctx); return z.shape !== "square" || z.border !== "line" || z.style !== "flat"; };
  // Which zones may take a shape / border / style. Not:
  //  - thin or narrow ones (zoomed out, a dashed round border on a sliver looks messy): drawn as before;
  //  - the Long / Short position tool: its two areas touch edge to edge. Two zone boxes drawn on the same canvas in
  //    the same paint, sharing a horizontal edge, mark their colours as "stacked"; those stay square from then on
  //    (also while you drag the tool), and the chart is redrawn once so the first frame matches.
  const paintBoxes = new WeakMap(), stackedCols = new Set();
  //  - things that only appear while you drag (TradingView's stop-loss / take-profit area when you drag an order's
  //    bracket): during a drag, only zones already seen before it (your rectangle being moved) keep their shape.
  let dragging = false, dragSkipped = false; const knownCols = new Set();
  addEventListener("pointerdown", () => { dragging = true; dragSkipped = false; }, true);
  // after the drag, redraw once only if something was left square because of it (and the drag area is gone anyway)
  for (const ev of ["pointerup", "pointercancel", "blur"]) addEventListener(ev, () => { if (dragging) { dragging = false; if (dragSkipped) { dragSkipped = false; setTimeout(() => { try { forceRepaint(true); } catch {} }, 30); } } }, true);
  function shapeOK(ctx, X, Y, W, H) {
    const dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1;
    const k = keyCol(ctx); if (k && stackedCols.has(k)) return false;
    if (dragging && !(k && knownCols.has(k))) { dragSkipped = true; return false; }
    const c = ctx.canvas; let L = paintBoxes.get(c);
    if (!L) { L = []; paintBoxes.set(c, L); queueMicrotask(() => paintBoxes.delete(c)); }
    for (const b of L) {
      const sameX = Math.abs(b.X - X) <= 3 && Math.abs(b.X + b.W - X - W) <= 3, touch = Math.abs(b.Y + b.H - Y) <= 2.5 || Math.abs(Y + H - b.Y) <= 2.5;
      if (sameX && touch && k && b.k && k !== b.k) { stackedCols.add(k); stackedCols.add(b.k); if (b.shaped) setTimeout(() => { try { forceRepaint(true); } catch {} }, 0); return false; }
    }
    const ok = H >= 8 * dpr && W >= 24 * dpr;
    if (ok && k && !dragging && knownCols.size < 500) knownCols.add(k);
    L.push({ X, Y, W, H, k, shaped: ok });
    return ok;
  }
  const keyCol = (ctx) => { const r = window.__bdCandleLooks && window.__bdCandleLooks.keyOf(String(ctx.__bdFill !== undefined ? ctx.__bdFill : ctx.fillStyle)); return r ? r.k + "|" + r.a : ""; };
  function rectPath(ctx) {
    const q = pathPts.get(ctx), b = pathBox.get(ctx); if (!q || q.bad || !b) return null;
    if (q.r === 1 && !q.p.length) return b;
    if (q.r || q.p.length < 4 || q.p.length > 6) return null;
    const near = (a, v) => Math.abs(a - v) <= 1.5;
    for (const [X, Y] of q.p) if (!((near(X, b.x0) || near(X, b.x1)) && (near(Y, b.y0) || near(Y, b.y1)))) return null;
    return b;
  }
  { const o = proto.arcTo; proto.arcTo = function (x1, y1, x2, y2) { if (on) { growBox(this, x1, y1); growBox(this, x2, y2); } return o.apply(this, arguments); }; }
  { const o = proto.quadraticCurveTo; proto.quadraticCurveTo = function (cx, cy, x, y) { if (on) { growBox(this, cx, cy); growBox(this, x, y); } return o.apply(this, arguments); }; }
  // Font-independent pill test: this text sits inside the pill box drawn a moment ago (so a font change on
  // TradingView's side can't leave a restyled box with unstyled, invisible text on it).
  function textInPill(ctx, x, y) {
    const p = lastPill.get(ctx); if (!p || !p.box || performance.now() - p.t > 250) return false;
    const t = ctx.getTransform(), tx = (x || 0) * (t.a || 1) + t.e, ty = (y || 0) * (t.d || 1) + t.f, b = p.box, m = b.h * 0.6;
    return tx >= b.x - m && tx <= b.x + b.w + m && ty >= b.y - m && ty <= b.y + b.h + m;
  }   // ctx -> { used, box:{x,y,w,h} } of the last pill-shaped box drawn
  function pillBox(ctx, x, y, w, h) {
    // convert the box to CSS px: the canvas transform's scale already folds in devicePixelRatio
    const sx = ctx.getTransform().a || 1, sy = ctx.getTransform().d || 1;
    const dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1;
    const pw = Math.abs(w * sx) / dpr, ph = Math.abs(h * sy) / dpr;
    // a pill is a short, wide-ish box — generous bounds so every variant/DPI is caught (font gate does the rest)
    return ph >= 8 && ph <= 40 && pw >= 10 && pw <= 460 && pw >= ph * 0.7;
  }
  // Per-canvas list of y-centres (device px) where a pill box was drawn this frame — used to spot the bracket's
  // own horizontal "level line" (a wide stroke at a pill's height) so we can thicken / recolour the whole level.
  // Pill rows are matched by time, not frame: the level line is stroked BEFORE the pill text in the same paint
  // (so this paint's row isn't known yet when the line draws), and TradingView repaints often — so we keep the
  // rows seen in the last ~400ms and match against those. The y positions barely move between paints.
  const pillRows = new WeakMap();   // ctx -> [{ y, sign, t }]
  function notePillRow(ctx, yDev, sign) {
    let a = pillRows.get(ctx); if (!a) { a = []; pillRows.set(ctx, a); }
    const now = performance.now();
    // replace a near-duplicate row (same height) rather than growing without bound
    const i = a.findIndex((e) => Math.abs(e.y - yDev) <= 3);
    if (i >= 0) a[i] = { y: yDev, sign, t: now };
    else { a.push({ y: yDev, sign, t: now }); if (a.length > 40) a.shift(); }
  }
  function bracketRowSign(ctx, yDev, ms = 500) {     // is yDev on a recently-seen pill row? returns its +/- sign, or null
    const a = pillRows.get(ctx); if (!a) return null;
    const now = performance.now();
    for (const e of a) if (now - e.t < ms && Math.abs(e.y - yDev) <= 5) return e.sign;
    return null;
  }
  // Bracket lines in your colour from their very first frame. TradingView strokes a bracket's line BEFORE its label,
  // in the same paint, so when the line is drawn nothing says yet that it belongs to a bracket. The row match above
  // only knew it from the previous paint: on a live chart that repaints about once a second, that was too long ago
  // and the line went back to its own colour on most paints (and for a frame whenever the line moved). Now:
  //  1. a line in a colour already confirmed as a bracket's line, on a row where a label has been lately, is drawn in
  //     your colour straight away;
  //     A line that stops exactly at a known label edge counts too (labels only move up and down), so a paint that
  //     redraws just the lines on a new row (zooming, dragging the price scale) is right as well;
  //  2. a wide horizontal line that isn't known yet is drawn as it is and noted. When its label is drawn in the same
  //     paint (its box, or its text: the charting library draws the box first, then the line, then the text), on its
  //     row and with the line ending at the label's edge, the line is drawn again in your colour (under the label).
  //     The browser shows the canvas only once the paint is over, so its own colour is never seen.
  // Nothing is repainted later and nothing polls: it all happens inside the chart's own paint.
  const bracketCols = new Map();   // "r,g,b|alpha" of lines confirmed as a bracket's -> when last confirmed
  const pendLines = new WeakMap(); // ctx -> wide horizontal lines drawn in their own colour in this paint
  const lineKeys = new Map();
  const lineKey = (col) => { if (typeof col !== "string") return null; let v = lineKeys.get(col);
    if (v === undefined) { const r = rgbKey(col); v = r ? r.key + "|" + (r.a === null ? 1 : +r.a) : null; if (lineKeys.size > 300) lineKeys.clear(); lineKeys.set(col, v); } return v; };
  const bracketLines = () => on && fx.bracketOn && (fx.bracketLineColor || fx.bracketLineW > 0);
  // where labels' edges are, across (device px): a label keeps its place across the chart and only moves up and down,
  // so a line in a bracket's colour that stops exactly at one of these is that bracket's line, on whatever row
  const bracketEdges = new WeakMap();   // ctx -> [{ x, side: "end" (line ends at a label's left) | "start", t }]
  function noteEdge(ctx, x, side) {
    let a = bracketEdges.get(ctx); if (!a) { a = []; bracketEdges.set(ctx, a); }
    const now = performance.now(), i = a.findIndex((e) => e.side === side && Math.abs(e.x - x) <= 1.5);
    if (i >= 0) a[i] = { x, side, t: now }; else { a.push({ x, side, t: now }); if (a.length > 16) a.shift(); }
  }
  function knownBracketLine(ctx, yDev, lk, s) {
    const t = lk && bracketCols.get(lk), now = performance.now();
    if (!t || now - t > 60000) return false;
    if (bracketRowSign(ctx, yDev, 10000) !== null) return true;
    const a = bracketEdges.get(ctx); if (!a || !s) return false;
    const lo = Math.min(s.x0, s.x1), hi = Math.max(s.x0, s.x1);
    // (a line that sits at a label's edge but goes across the whole pane isn't a bracket's stub)
    return a.some((e) => now - e.t < 60000 && (e.side === "end" ? Math.abs(hi - e.x) <= 1.5 : Math.abs(lo - e.x) <= 1.5));
  }
  function notePendLine(ctx, s, cur, lk, done) {   // done: already drawn in your colour (only learn from its label)
    // (a line across the whole pane is never a bracket's: those stop at their label. Grid lines, levels: not noted)
    const c = ctx.canvas; if (c && Math.min(s.x0, s.x1) <= 1 && Math.max(s.x0, s.x1) >= c.width - 1) return;
    let a = pendLines.get(ctx); if (!a || a.f !== frameNo) { a = []; a.f = frameNo; pendLines.set(ctx, a); }
    if (a.length >= 32) a.shift();
    const t = ctx.getTransform(), k = Math.hypot(t.a, t.b) || 1;
    a.push({ x0: s.x0, x1: s.x1, y: (s.y0 + s.y1) / 2, lw: ctx.lineWidth * k, dash: ctx.getLineDash().map((d) => d * k), off: ctx.lineDashOffset * k,
      cap: ctx.lineCap, alpha: ctx.globalAlpha, comp: ctx.globalCompositeOperation, col: cur, lk, done: !!done, t: performance.now() });
  }
  // a label box was just drawn (device px): the lines of this paint that end at its edge, on its row, are its bracket's.
  // later = the label is a picture pasted in (drawImage): TradingView pastes those clipped to the label, so a line drawn
  // now would be clipped away. Those lines are drawn once the paint is over instead (still before the browser shows
  // the canvas), leaving out any part under a label so the labels stay on top.
  const pasted = new WeakMap();   // ctx -> { f, boxes: [...], lines: [...] } waiting for the end of this paint
  function confirmPendLines(ctx, b, later) {
    const a = pendLines.get(ctx); if (!a || !a.length || a.f !== frameNo) { if (later) notePasted(ctx, b, null); return; }
    const now = performance.now();
    for (let i = a.length - 1; i >= 0; i--) {
      const e = a[i], lo = Math.min(e.x0, e.x1), hi = Math.max(e.x0, e.x1);
      if (now - e.t > 40 || e.y < b.y - 1 || e.y > b.y + b.h + 1) continue;
      const endsAt = Math.abs(hi - b.x) <= 3, startsAt = Math.abs(lo - (b.x + b.w)) <= 3;
      if (!endsAt && !startsAt) continue;
      a.splice(i, 1);
      if (endsAt) noteEdge(ctx, hi, "end"); else noteEdge(ctx, lo, "start");
      if (e.lk) { bracketCols.set(e.lk, now); if (bracketCols.size > 24) bracketCols.delete(bracketCols.keys().next().value); }
      if (e.done) continue;
      if (later) notePasted(ctx, null, e); else redrawLine(ctx, e, e.x0, e.x1);
    }
    if (later) notePasted(ctx, b, null);
  }
  function redrawLine(ctx, e, x0, x1) {
    ctx.save();
    try {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      strokeDesc.set.call(ctx, fx.bracketLineColor || e.col);
      ctx.lineWidth = fx.bracketLineW > 0 ? Math.max(e.lw, fx.bracketLineW + 1) : e.lw;
      ctx.setLineDash(e.dash); ctx.lineDashOffset = e.off; ctx.lineCap = e.cap; ctx.globalAlpha = e.alpha; ctx.globalCompositeOperation = e.comp; ctx.shadowBlur = 0;
      const p = new Path2D(); p.moveTo(x0, e.y); p.lineTo(x1, e.y);
      origStroke.call(ctx, p);   // (a Path2D: the label's own path, maybe being built right now, stays as it is)
    } catch {} finally { ctx.restore(); }
  }
  function notePasted(ctx, box, line) {
    let q = pasted.get(ctx);
    if (!q || q.f !== frameNo) { q = { f: frameNo, boxes: [], lines: [] }; pasted.set(ctx, q);
      queueMicrotask(() => { if (pasted.get(ctx) !== q) return; pasted.delete(ctx); if (q.lines.length && on) flushPasted(ctx, q); }); }
    if (box && q.boxes.length < 40) q.boxes.push(box);
    if (line) q.lines.push(line);
  }
  function flushPasted(ctx, q) {
    for (const e of q.lines) {
      // the line's span minus every label on its row (pasted this paint): the pieces left are drawn
      let parts = [[Math.min(e.x0, e.x1), Math.max(e.x0, e.x1)]];
      for (const b of q.boxes) { if (e.y < b.y - 1 || e.y > b.y + b.h + 1) continue;
        parts = parts.flatMap(([lo, hi]) => (b.x >= hi || b.x + b.w <= lo ? [[lo, hi]] : [[lo, b.x], [b.x + b.w, hi]].filter(([u, v]) => v - u >= 1))); }
      for (const [lo, hi] of parts) e.x0 <= e.x1 ? redrawLine(ctx, e, lo, hi) : redrawLine(ctx, e, hi, lo);
    }
  }
  // minimal path geometry (just the first move + last line) so stroke() can tell a wide horizontal line apart
  const lastSeg = new WeakMap();   // ctx -> { x0, y0, x1, y1 }
  // A pill's money/price text (what the user wants to see): has a digit, and a $/currency or +/- sign, or is a bare
  // number/qty. We only *recolour* the ones that read as profit/loss (have a sign); size applies to all pills.
  const MONEY_RE = /[$€£¥]|[+\-\u2212]?\s*\d/;
  function pillSign(text) {
    const t = String(text).trim();
    if (/^[+＋]|\+\s*[$€£¥]/.test(t)) return 1;                       // +$1170.00
    if (/^[-\u2212]|[-\u2212]\s*[$€£¥]/.test(t)) return -1;           // -$133.00
    return 0;
  }
  // readable text (black or white) for a given box colour, so a recoloured/opaque box never hides its number
  function readableOn(hexOrRgb) {
    const r = rgbKey(hexOrRgb); if (!r) return null;
    const [R, G, B] = r.key.split(",").map((n) => { n /= 255; return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4); });
    return 0.2126 * R + 0.7152 * G + 0.0722 * B > 0.34 ? "#0a0e14" : "#ffffff";
  }
  function lum(v) {
    const r = rgbKey(v); if (!r) return null;
    const [R, G, B] = r.key.split(",").map((n) => { n /= 255; return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4); });
    return 0.2126 * R + 0.7152 * G + 0.0722 * B;
  }
  function lowContrast(a, b, min = 3) {    // WCAG contrast below min:1 (3 for automatic colours; your own colours get a bit more leeway)
    const A = lum(a), B = lum(b); if (A === null || B === null) return false;
    return (Math.max(A, B) + 0.05) / (Math.min(A, B) + 0.05) < min;
  }
  // how much of the label's own colour tints the dark box: light labels (white / pale) only a hint, so numbers pop
  function tintK(rgb) { const L = (0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]) / 255; return (fx.bracketBack === "solid" ? 0.22 : 0.3) * (L > 0.6 ? 0.3 : 1); }
  // which fill colour did the box end up with (what we painted, or TradingView's own)? remembered per ctx so the
  // text branch can auto-pick a readable colour when the user recoloured/strengthened the box but not the text.
  const pillFill = new WeakMap();

  // Diagnostic: when bracketDebug is on, record a small sample of the pill text we see on the real chart so we can
  // confirm the hook is catching the broker's pills. Readable from the page console as window.__bdBracketDebug.
  function noteBracketDebug(text, font, align, fill, box) {
    try {
      const d = (window.__bdBracketDebug = window.__bdBracketDebug || { note: "Priism Skins bracket debug — pills the hook caught:", samples: [] });
      const key = String(text).slice(0, 20) + "|" + font;
      if (!d.samples.some((s) => s.key === key) && d.samples.length < 20) {
        d.samples.push({ key, text: String(text).slice(0, 20), font, align, fill: String(fill).slice(0, 16), box: box ? { w: Math.round(box.w), h: Math.round(box.h) } : null });
      }
    } catch {}
  }

  // ---------- where bracket labels can live ----------
  // Usually on the chart pane's canvas. But some TradingView builds / broker setups draw trading lines on a separate
  // overlay canvas inside the chart area, or draw each label ONCE into a hidden canvas and then paste that picture onto
  // the chart (drawImage). We cover all three.
  const bcCache = new WeakMap();
  function bracketCanvas(c) {
    let v = bcCache.get(c);
    if (v === undefined) { v = isPane(c) || (!!(c.closest && c.closest(".chart-container, .layout__area--center")) && !isAxis(c)); bcCache.set(c, v); }
    return v;
  }
  const srcInfo = new WeakMap();   // hidden canvas -> { text, font, fill, box } of the label drawn into it
  function noteSrcText(c, t, font, fill) {
    const s = String(t); if (!MONEY_RE.test(s)) return;
    const o = srcInfo.get(c) || {}; o.text = o.text && o.text !== s && o.font === font ? o.text + " " + s : s; o.font = font; o.fill = String(fill); o.t = performance.now();
    if (o.text.length > 40) o.text = s;
    srcInfo.set(c, o); if (on && fx.bracketOn) diagNote("hidden", s, font);
  }
  function noteSrcBox(c, fill, w, h) { const o = srcInfo.get(c) || {}; o.box = String(fill); srcInfo.set(c, o); }
  // what the panel's Diagnose shows: labels seen on hidden canvases / pasted onto the chart (proves which path is used)
  function diagNote(kind, t, font) {
    try { const d = (window.__bdBracketPaths = window.__bdBracketPaths || { hidden: [], pasted: [], overlay: [] }), L = d[kind];
      const k = String(t).slice(0, 18); if (L.length < 12 && !L.some((x) => x.t === k)) L.push({ t: k, f: String(font || "").slice(0, 60) }); } catch {}
  }
  if (typeof OffscreenCanvasRenderingContext2D !== "undefined") {
    const OP = OffscreenCanvasRenderingContext2D.prototype, ot = OP.fillText, ofr = OP.fillRect;
    OP.fillText = function (t) { try { if (this.canvas.height <= 120) noteSrcText(this.canvas, t, this.font, this.fillStyle); } catch {} return ot.apply(this, arguments); };
    OP.fillRect = function (x, y, w, h) { try { if (this.canvas.height <= 120 && h >= 6) noteSrcBox(this.canvas, this.fillStyle, w, h); } catch {} return ofr.apply(this, arguments); };
  }
  // A pasted label: redraw it as a styled pill (box + number) instead of the cached picture.
  const origDrawImage = proto.drawImage;
  proto.drawImage = function (img, ...r) {
    const c = this.canvas;
    if (c && !c.isConnected) noteHiddenOther(this);
    if (on && c && img instanceof HTMLCanvasElement && !img.isConnected && isPane(c) && !isTop(c)) { const sc = styledCopy(img); if (sc) return origDrawImage.call(this, sc, ...r); }
    // a label picture pasted onto the chart (TradingView draws order / position tags this way): note its row, so the
    // line on that row is never taken for an indicator's level line
    if (on && c && img && isPane(c) && (img instanceof HTMLCanvasElement || (typeof OffscreenCanvas !== "undefined" && img instanceof OffscreenCanvas))) {
      const info = srcInfo.get(img);
      if (info && (info.box || info.text)) { let dy, dh; if (r.length >= 8) { dy = r[5]; dh = r[7]; } else if (r.length >= 4) { dy = r[1]; dh = r[3]; } else { dy = r[1]; dh = img.height; }
        const t = this.getTransform(), hCss = Math.abs(dh * (t.d || 1)) / ((typeof devicePixelRatio === "number" && devicePixelRatio) || 1);
        if (hCss >= 6 && hCss <= 48) noteLabelRow(this, (dy + dh / 2) * (t.d || 1) + t.f); }
    }
    if (on && (fx.bracketOn || fx.privacy) && c && img && (img instanceof HTMLCanvasElement || (typeof OffscreenCanvas !== "undefined" && img instanceof OffscreenCanvas)) && bracketCanvas(c)) {
      const info = srcInfo.get(img);
      if (info && info.text && (info.box || BRACKET_FONT.test(info.font || ""))) {
        let dx, dy, dw, dh;
        if (r.length >= 8) [, , , , dx, dy, dw, dh] = r; else if (r.length >= 4) [dx, dy, dw, dh] = r; else { [dx, dy] = r; dw = img.width; dh = img.height; }
        const t = this.getTransform(), sy = t.d || 1, dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1;
        const hCss = Math.abs(dh * sy) / dpr;
        if (hCss >= 8 && hCss <= 44) {
          diagNote("pasted", info.text, info.font);
          drawStyledPill(this, dx, dy, dw, dh, info);
          return;
        }
      }
    }
    if (on && fx.bracketOn && c && bracketCanvas(c) && !isPane(c)) { /* overlay canvas in the chart area */ }
    return origDrawImage.call(this, img, ...r);
  };
  function drawStyledPill(ctx, x, y, w, h, info) {
    const sign = pillSign(info.text), sx = ctx.getTransform().a || 1;
    if (bracketLines()) { const t = ctx.getTransform(), sy = t.d || 1;   // its line, drawn a moment ago in its own colour
      confirmPendLines(ctx, { x: Math.min(x, x + w) * sx + t.e, y: Math.min(y, y + h) * sy + t.f, w: Math.abs(w * sx), h: Math.abs(h * sy) }, true); }
    ctx.save();
    // box: your colour, or the label's own colour strengthened into a dark tinted box (same rule as drawn pills)
    let fill = fx.bracketFill;
    if (!fill) { const r = rgbKey(info.box || info.fill || "#1e2130"), base = [16, 19, 28], rgb = r ? r.key.split(",").map(Number) : base;
      const k = tintK(rgb); fill = `rgba(${rgb.map((v, i) => Math.round(base[i] + (v - base[i]) * k)).join(",")},${fx.bracketBack === "keep" ? 0.92 : 1})`; }
    origFillDesc.set.call(ctx, fill); origFillRect.call(ctx, x, y, w, h);
    if (fx.bracketBorderColor || fx.bracketBorderW > 0) { strokeDesc.set.call(ctx, fx.bracketBorderColor || info.fill || "#ffffff"); ctx.lineWidth = (fx.bracketBorderW + 1) / sx; origStrokeRectRaw.call(ctx, x, y, w, h); }
    // number: profit / loss colour, or your colour, or a readable colour for the box
    const qty = isQty(info.text);
    if (fx.privacy) info = { ...info, text: privText(info.text) };
    let col = qty && fx.bracketQty ? fx.bracketQty : sign > 0 && fx.bracketProfit ? fx.bracketProfit : sign < 0 && fx.bracketLoss ? fx.bracketLoss : fx.bracketText || "";
    if (!col || lowContrast(col, fill, fx.bracketProfit || fx.bracketLoss || fx.bracketText ? 2.2 : 3)) col = readableOn(fill) || "#ffffff";
    const basePx = +((info.font || "").match(/(\d+(?:\.\d+)?)px/) || [0, 11])[1];
    let px = basePx + fx.bracketSize, font = (info.font || "bold 11px Verdana").replace(/(\d+(?:\.\d+)?)px/, px + "px");
    ctx.font = font; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    while (px > basePx && origMeasure.call(ctx, info.text).width > w - 4 / sx) { px -= 1; ctx.font = font.replace(/\d+(?:\.\d+)?px/, px + "px"); }
    origFillDesc.set.call(ctx, col); origText.call(ctx, info.text, x + w / 2, y + h / 2, w - 2 / sx);
    ctx.restore();
    const tt = ctx.getTransform(); notePillRow(ctx, (y + h / 2) * (tt.d || 1) + tt.f, sign);
  }
  const origFillRect = proto.fillRect;

  proto.fillText = function (...a) {
    const c = this.canvas;
    if (c && !c.isConnected) noteHiddenText(this, a);
    // a marker's own text, in the marker's colour (a signal label's letters): the marker's new colour too
    { const mk = on && this.__bdMark && this.__bdMark.get(String(this.__bdFill !== undefined ? this.__bdFill : this.fillStyle)); if (mk && typeof a[0] === "string" && a[0].length <= 24 && performance.now() - mk.t < 60) { if (mk.m.hide) return;
      const pF = this.fillStyle; origFillDesc.set.call(this, mk.m.s); const r = origText.apply(this, a); origFillDesc.set.call(this, pF); return r; } }
    if (on && fx.chOn && fx.chLabels && c && isAxis(c) && isTop(c) && chLabel.get(this)) {
      const pF = this.fillStyle; origFillDesc.set.call(this, readableOn(chLabel.get(this)) || "#ffffff");
      const r = origText.apply(this, a); origFillDesc.set.call(this, pF); return r;
    }
    notePnl(a[0], c);

    // Bracket pill text: bigger + optional +/- recolour. The reliable signal is the FONT (Verdana) — every TP /
    // Stop / entry / P&L / quantity pill uses it, regular chart text doesn't. We do NOT require a preceding box:
    // some pills draw their box with roundRect / a path (not fillRect), which we can't always catch, but the text
    // still comes through here, so recolour + size always work. If we did record a box, we use it to clamp size
    // and to feed the level-line row match.
    if (c && !c.isConnected && c.height <= 120) noteSrcText(c, a[0], this.font, this.fillStyle);   // labels can be cached before we switch on   // label drawn into a hidden canvas first
    if (on && (fx.bracketOn || fx.privacy) && c && bracketCanvas(c) && MONEY_RE.test(String(a[0]))
        && (((this.textAlign === "center" || this.textAlign === "end" || this.textAlign === "right") && BRACKET_FONT.test(this.font || ""))
            || textInPill(this, a[1], a[2]))) {
      {
        const pill = lastPill.get(this);
        if (pill) pill.used = true;
        const sign = pillSign(a[0]) || (pill && pill.sign) || 0;   // "40.75" on a green box = profit
        const qty = isQty(a[0]);
        if (fx.privacy) a[0] = privText(a[0]);                        // Streamer mode: hide the amount, on screen and in recordings
        if (!fx.bracketOn) { origText.apply(this, a); return; }
        // remember this pill's row so stroke() can find the level line. Prefer the box centre; else the text's y.
        const rowY = pill && pill.box ? pill.box.y + pill.box.h / 2 : (() => { const t = this.getTransform(); return (a[2] || 0) * (t.d || 1) + t.f; })();
        if (fx.bracketDebug) noteBracketDebug(a[0], this.font, this.textAlign, String(this.fillStyle), pill && pill.box);
        notePillRow(this, rowY, sign);
        // its line: some platforms draw the label's box, then the line, then the text, so the line only exists now
        // (finished once the paint is over: text can be drawn clipped to its label)
        if (bracketLines()) {
          let bx = pill && pill.box && performance.now() - pill.t < 40 ? pill.box : null;
          if (!bx) { const t = this.getTransform(), w = origMeasure.call(this, String(a[0])).width * (t.a || 1), cx = (a[1] || 0) * (t.a || 1) + t.e;
            const al = this.textAlign, x0 = al === "center" ? cx - w / 2 : al === "right" || al === "end" ? cx - w : cx;
            bx = { x: x0 - 6, y: rowY - 9, w: w + 12, h: 18 }; }
          confirmPendLines(this, bx, true);
        }
        const pFont = this.font, pFill = this.fillStyle, sx = this.getTransform().a || 1;
        // Enlarge, but NEVER clip: TradingView centers text in a fixed-width box, so a bigger font can spill over
        // the edges and look broken ("can't see the number"). Clamp the font so the text still fits the box.
        const box = pill && pill.box;
        if (fx.bracketSize > 0) {
          let nf = pFont.replace(/(\d+(?:\.\d+)?)px/, (m, n) => (+n + fx.bracketSize) + "px");
          this.font = nf;
          if (box) {
            const avail = box.w / sx - 4;                 // room inside the box (css px)
            let w = origMeasure.call(this, String(a[0])).width;
            // shrink a step at a time until it fits (keeps the number fully visible)
            let px = +nf.match(/(\d+(?:\.\d+)?)px/)[1];
            while (w > avail && px > +pFont.match(/(\d+(?:\.\d+)?)px/)[1]) {
              px -= 1; this.font = nf.replace(/\d+(?:\.\d+)?px/, px + "px"); w = origMeasure.call(this, String(a[0])).width;
            }
            if (a[3] === undefined) a[3] = Math.max(w, avail);   // let the engine letter-squeeze if still a hair wide
          }
        }
        // text colour: profit/loss by sign, else a single custom colour, else auto-readable if we changed the box
        let col = "";
        if (qty && fx.bracketQty) col = fx.bracketQty;
        else if (sign > 0 && fx.bracketProfit) col = fx.bracketProfit;
        else if (sign < 0 && fx.bracketLoss) col = fx.bracketLoss;
        else if (fx.bracketText) col = fx.bracketText;
        // never let the number match its box: if the chosen (or TradingView's) colour is too close to the box we
        // painted, switch to black/white so TP / Stop / P&L always read
        const boxCol = pillFill.get(this);
        if (boxCol && lowContrast(col || String(pFill), boxCol, col ? 2.2 : 3)) col = readableOn(boxCol) || col;
        if (col) this.fillStyle = col;
        origText.apply(this, a);
        this.font = pFont; this.fillStyle = pFill;
        return;
      }
    }
    if (on && c && isAxis(c)) noteQuote(lastTag.get(this), a[0]);   // Live mood: the price, on platforms without it in the title
    // Live-price tags (and other price boxes): same font/weight/size as the scale, text kept inside its box.
    const tagsRecoloured = candles && fx.scaleLabels;
    if (on && c && isAxis(c) && !isScaleLabel(this.fillStyle) && (tagsRecoloured || fx.scaleFont !== "default" || fx.scaleSize > 0 || fx.scaleBold)) {
      const pFont = this.font, pF = this.fillStyle, w0 = origMeasure.call(this, String(a[0])).width;
      const nf = styledFont(pFont);
      if (nf !== pFont) { this.font = nf; if (a[3] === undefined && w0 > 0) a[3] = w0 * 1.06; }
      // text on a recoloured tag: dark on bright tags, white on dark ones
      // only the text drawn right after a price box sits on it (a price + countdown = 2 lines); later numbers are plain
      // scale labels. Remembering the box for longer turned every later number dark on dark wallpapers.
      const lt = lastTag.get(this); if (lt && --lt.left <= 0) lastTag.delete(this);
      const tag = tagsRecoloured && lt && lt.col, r = tag && rgbKey(tag);
      if (r) {
        const [R, G, B] = r.key.split(",").map((n) => { n /= 255; return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4); });
        const L = 0.2126 * R + 0.7152 * G + 0.0722 * B;
        this.fillStyle = L > 0.36 ? "#06110d" : "#ffffff";
      }
      origText.apply(this, a);
      this.font = pFont; this.fillStyle = pF;
      return;
    }
    if (on && c && isAxis(c) && scaleStyled() && isScaleLabel(this.fillStyle)) {
      const pF = this.fillStyle, pFont = this.font, pSB = this.shadowBlur, pSC = this.shadowColor;
      const tone = autoOn() ? toneAt(this, a[2]) : null;
      // a bigger or wider font must still fit the scale: give the text the room that's actually there
      if (a[3] === undefined && (fx.scaleSize > 0 || fx.scaleFont !== "default" || fx.scaleBold)) {
        const w0 = origMeasure.call(this, String(a[0])).width, sx = this.getTransform().a || 1;
        const room = this.textAlign === "left" || this.textAlign === "start" ? c.width / sx - (a[1] || 0) - 3 : w0 * 1.06;
        a[3] = Math.max(w0, room);
      }
      if (fx.scaleText) this.fillStyle = fx.scaleText;
      else if (tone) this.fillStyle = AUTO_TEXT[tone];
      const nf = styledFont(pFont); if (nf !== pFont) this.font = nf;
      if (fx.scaleGlow > 0) { this.shadowColor = this.fillStyle; this.shadowBlur = 2 + fx.scaleGlow * 12; }
      else if (tone) { this.shadowColor = autoHalo(tone); this.shadowBlur = 3; }      // halo keeps text crisp on busy art
      origText.apply(this, a);
      this.fillStyle = pF; this.font = pFont; this.shadowBlur = pSB; this.shadowColor = pSC;
      return;
    }
    // Chart text (Style > Chart text): text indicators draw on the chart. Not the crosshair overlay, and not text
    // inside a label's own solid box (that box already gives it contrast). Even on Own, black text on a dark
    // wallpaper (made for a light chart) is lightened so it can be read.
    if (on && c && isPane(c) && !isTop(c) && !inSolidBox(this, a[1], a[2])) {
      const L = window.__bdCandleLooks;
      if (L && L.chartText && L.chartText(this, txtK(this), a, { mode: fx.txtMode, color: fx.txtColor, outline: fx.txtOutline, size: fx.txtSize, bg: fx.bg || "dark", up: candles && candles.upHex })) return;
    }
    const bgDark = fx.bg ? fx.bg === "dark" : htmlEl().classList.contains("theme-light"); // before 1st measurement: old behaviour
    // (not text inside a label's own solid box on the chart: a position's black P&L on its bright green box must stay black)
    if (on && !htmlEl().classList.contains("bd-over-mode") && this.canvas && inChart(this.canvas) && isScaleLabel(this.fillStyle) &&
        (bgDark ? isDark(this.fillStyle) : !isDark(this.fillStyle)) && !(isPane(this.canvas) && inSolidBox(this, a[1], a[2]))) {
      const prev = this.fillStyle;
      this.fillStyle = bgDark ? AUTO_TEXT.dark : AUTO_TEXT.light;
      origText.apply(this, a);
      this.fillStyle = prev;
      return;
    }
    return origText.apply(this, a);
  };

  // ---------- candle looks ----------
  // prism: each candle's colour is rotated along the chart (a spectrum across the screen)
  function hueRotate(rgb, deg) {
    let [r, g, b] = rgb.map((v) => v / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    let h = 0, sat = 0;
    if (mx !== mn) {
      const d = mx - mn; sat = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60;
    }
    h = (h + deg + 360) % 360;
    const f = (n) => { const k = (n + h / 30) % 12, a = sat * Math.min(l, 1 - l); return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))); };
    return "#" + [f(0), f(8), f(4)].map((v) => v.toString(16).padStart(2, "0")).join("");
  }
  const prismCache = new Map();
  function prismColour(isUp, frac) {
    const step = Math.max(0, Math.min(31, Math.floor(frac * 32)));
    const key = (isUp ? "u" : "d") + step + (isUp ? candles.upHex : candles.downHex);
    let v = prismCache.get(key);
    if (!v) { v = hueRotate(isUp ? candles.up : candles.down, -70 + (step / 31) * 140); if (prismCache.size > 400) prismCache.clear(); prismCache.set(key, v); }
    return v;
  }

  // ---------- price tags glow with the scale glow ----------
  const origFillPath = proto.fill;
  const chLabel = new WeakMap();      // axis top canvas -> colour we gave the crosshair label box
  const lastTag = new WeakMap();   // colour of the last price box drawn on each scale canvas
  // Live mood ("Day's move") needs the price. tradingview.com puts it in the tab title; platforms that embed
  // TradingView's charts (nq.vision, prop firms) don't. There, read it from the chart's own last-price tag: the number
  // drawn on the price scale inside a box in the candle colour. Shared with lw.js's reader via data-bd-lwquote.
  let quoteAt = -1e9, quoteVal = NaN, titleHasPrice = false;
  setInterval(() => { titleHasPrice = /[\d.,]+\s*[\u25b2\u25bc]?\s*[+\-\u2212]?[\d.]+%/.test(document.title || ""); }, 2000);
  function noteQuote(lt, text) {
    if (!lt || titleHasPrice) return;   // tradingview.com: the title has it
    const r = rgbKey(lt.col); if (!r) return;
    const candleTag = sides.has(r.key) || (candles && (r.key === candles.up.join(",") || r.key === candles.down.join(",")));
    if (!candleTag) return;
    const n = parseFloat(String(text).replace(/[,\s\u2009\u202f']/g, "").replace("\u2212", "-"));
    const now = performance.now();
    if (isFinite(n) && n > 0 && (n !== quoteVal || now - quoteAt > 1000)) { quoteAt = now; quoteVal = n; htmlEl().setAttribute("data-bd-lwquote", JSON.stringify({ p: n, ts: Date.now() })); }
  }
  proto.fill = function (...a) {
    const c = this.canvas;
    if (c && !c.isConnected) noteHiddenOther(this);
    // a solid rounded tag on the chart (order / position labels): note its row, so its level line is never an indicator's
    if (on && c && a.length === 0 && isPane(c)) { const b = pathBox.get(this);
      if (b) { const dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1, w = (b.x1 - b.x0) / dpr, h = (b.y1 - b.y0) / dpr, k = rgbKey(String(this.fillStyle));
        if (h >= 8 && h <= 40 && w >= 10 && w <= 460 && k && (k.a === null || +k.a >= 0.9)) noteLabelRow(this, (b.y0 + b.y1) / 2);
        if (k && (k.a === null || +k.a >= 0.6) && b.x1 - b.x0 < c.width * 0.6 && b.y1 - b.y0 < c.height * 0.5) noteSolidBox(this, b.x0, b.y0, b.x1, b.y1); } }
    // rounded pill box (TradingView's newer trading labels draw their box as a path, not a rect)
    if (on && (fx.bracketOn || fx.privacy) && c && a.length === 0 && bracketCanvas(c)) {
      const b = pathBox.get(this);
      if (b) {
        const dpr = (typeof devicePixelRatio === "number" && devicePixelRatio) || 1, w = (b.x1 - b.x0) / dpr, h = (b.y1 - b.y0) / dpr;
        if (h >= 8 && h <= 40 && w >= 10 && w <= 460 && w >= h * 0.7 && w < c.width / dpr * 0.6) {
          const fill = notePillBox(this, { x: b.x0, y: b.y0, w: b.x1 - b.x0, h: b.y1 - b.y0 });
          if (fill) { const pF = this.fillStyle; origFillDesc.set.call(this, fill); const r = origFillPath.apply(this, a); origFillDesc.set.call(this, pF); return r; }
        }
      }
    }
    // a marker (an indicator's signal arrow / triangle / circle / label, your trade arrows): Markers colour, glow, Each indicator
    if (on && c && !a.length && isPane(c) && (fx.markMode !== "own" || markEach())) { const L = window.__bdCandleLooks;
      if (L && L.marker) { L.shapeBox.install(); const orig = String(this.__bdFill !== undefined ? this.__bdFill : this.fillStyle);
        const m = L.marker(this, orig, { mode: fx.markMode, color: fx.markColor, up: candles && candles.upHex, down: candles && candles.downHex, accent: fx.accent, custom: fx.indCustom, grad: fx.indGrad, glow: fx.lineGlow });
        if (m) { L.noteSeen(orig, "marker"); (this.__bdMark || (this.__bdMark = new Map())).set(orig, { m, t: performance.now() }); if (m.hide) return;
          const pF = this.fillStyle, pB = this.shadowBlur, pC = this.shadowColor; origFillDesc.set.call(this, m.s);
          if (m.glow > 0) { this.shadowColor = m.g; this.shadowBlur = 3 + m.glow * 14; }
          const r = origFillPath.apply(this, a); origFillDesc.set.call(this, pF); this.shadowBlur = pB; this.shadowColor = pC; return r; } } }
    // crosshair price / time labels (the boxes that follow your pointer on the scales): your crosshair colour
    if (on && fx.chOn && fx.chLabels && c && isAxis(c) && isTop(c)) {
      const col = pick(fx.chColor, String(this.fillStyle)), pF = this.fillStyle;
      origFillDesc.set.call(this, col); chLabel.set(this, col);
      const r = origFillPath.apply(this, a); origFillDesc.set.call(this, pF); return r;
    }
    if (on && c && isAxis(c)) lastTag.set(this, { col: this.fillStyle, left: 2 });
    // a filled shape on the chart that isn't a candle (a band between two lines, a box): an indicator zone
    if (on && c && isPane(c)) { const z = zoneFor(this, 1e4, 1e4); if (z) {
      if (z.hide) return;
      // a box drawn as a path (rectangle drawings, many zone boxes): it can take the zone shape / border too
      const L = window.__bdCandleLooks, b = !a.length && zoneStyled(this) && L && L.zoneBox ? rectPath(this) : null;
      if (b && b.y1 - b.y0 < c.height * 0.9 && shapeOK(this, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0)) { this.save(); this.setTransform(1, 0, 0, 1, 0, 0);
        try { if (L.zoneBox(this, zoneKit(this), b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0, z, { ...zoneSt(this), px: (typeof devicePixelRatio === "number" && devicePixelRatio) || 1 })) { noteShaped(this, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0); return; } } finally { this.restore(); } }
      return drawZone(this, z, () => origFillPath.apply(this, a), () => (a[0] && typeof a[0] === "object" ? origStroke.call(this, a[0]) : origStroke.call(this))); } }
    if (on && c && fx.scaleGlow > 0 && isAxis(c)) {
      const col = this.fillStyle;
      if (typeof col === "string" && glowable(col)) {
        const sb = this.shadowBlur, sc = this.shadowColor;
        this.shadowColor = col; this.shadowBlur = 3 + fx.scaleGlow * 16;
        origFillPath.apply(this, a);
        this.shadowBlur = sb; this.shadowColor = sc;
        return;
      }
    }
    return origFillPath.apply(this, a);
  };

  // ---------- fillRect: transparent pane background + candle looks / glow ----------
  const origFill = proto.fillRect;
  const lastBody = new WeakMap(), barW = new WeakMap();   // barW: canvas -> its candles' latest body width (device px)
  // drawing kit handed to candlelooks.js: the REAL canvas calls, so our own hooks don't re-process the look's shapes
  const lookK = { g: null, px: 1, yfrac: 0,
    fill(x, y, w, h) { origFill.call(lookK.g, x, y, w, h); },
    style(v) { origFillDesc.set.call(lookK.g, v); },
    stroke(v) { strokeDesc.set.call(lookK.g, v); },
    strokeRect(x, y, w, h) { origStrokeRectRaw.call(lookK.g, x, y, w, h); },
    fillPath() { origFillPathRaw.call(lookK.g); },
    clear(x, y, w, h) { origClearRaw.call(lookK.g, x, y, w, h); } };
  const origStrokeRectRaw = proto.strokeRect, origFillPathRaw = origFillPath, origClearRaw = proto.clearRect;
  const zoneKit = (g) => ({ begin: () => origBegin.call(g), fill: () => origFillPathRaw.call(g), stroke: () => origStroke.call(g),
    style: (v) => origFillDesc.set.call(g, v), strokeStyle: (v) => strokeDesc.set.call(g, v) });
  // were the last paint's candles wide enough to tell bodies from wicks? (wick colours / widths only then)
  let partsTrack = null;
  const tracker = () => partsTrack || (window.__bdCandleLooks && window.__bdCandleLooks.paintTracker ? (partsTrack = window.__bdCandleLooks.paintTracker(() => { try { forceRepaint(true); } catch {} })) : null);   // the untouched fill: candle looks never pass through the pill / label logic
  proto.fillRect = function (x, y, w, h) {
    const c = this.canvas;
    if (c && !c.isConnected) noteHiddenOther(this);
    // scale border: a 1px rect along the edge of the price / time scale
    if (on && fx.axOn && c && isAxis(c)) {
      const t = this.getTransform(), W = Math.abs(w * (t.a || 1)), H = Math.abs(h * (t.d || 1));
      if ((W <= 3 && H >= c.height * 0.5) || (H <= 3 && W >= c.width * 0.5)) {
        if (fx.axStyle === "none") return;
        const col = pick(fx.axColor, String(this.fillStyle)), pF = this.fillStyle, th = (1 + fx.axW) / (t.a || 1);
        origFillDesc.set.call(this, col); origFill.call(this, x, y, W <= 3 ? th : w, H <= 3 ? th : h); origFillDesc.set.call(this, pF);
        return;
      }
    }
    if (on && c && w * (this.getTransform().a || 1) <= 40 && isPane(c)) noteFill(this.__bdFill);
    if (on && c && isPane(c)) { const k = rgbKey(String(this.fillStyle)), t = this.getTransform();
      if (k && (k.a === null || +k.a >= 0.6) && Math.abs(w * (t.a || 1)) < c.width * 0.6 && Math.abs(h * (t.d || 1)) < c.height * 0.5) noteSolidBox(this, x * (t.a || 1) + t.e, y * (t.d || 1) + t.f, (x + w) * (t.a || 1) + t.e, (y + h) * (t.d || 1) + t.f); }
    if (on && c && isPane(c) && pillBox(this, x, y, w, h)) { const k = rgbKey(String(this.fillStyle)); if (k && (k.a === null || +k.a >= 0.9)) { const t = this.getTransform(); noteLabelRow(this, (y + h / 2) * (t.d || 1) + t.f); } }
    // Bracket pills: record the box so the text drawn next knows it belongs to a pill. Optionally strengthen the
    // box backing so the TP/Stop/P&L number stays readable on busy wallpapers.
    if (c && !c.isConnected && c.height <= 120 && h >= 6) noteSrcBox(c, this.fillStyle, w, h);
    if (on && (fx.bracketOn || fx.privacy) && c && bracketCanvas(c) && pillBox(this, x, y, w, h)) {
      const t = this.getTransform(), sx = t.a || 1, sy = t.d || 1;
      const fill = notePillBox(this, { x: x * sx + t.e, y: y * sy + t.f, w: Math.abs(w * sx), h: Math.abs(h * sy) });
      if (fill) { const pF = this.fillStyle; origFillDesc.set.call(this, fill); origFill.call(this, x, y, w, h); origFillDesc.set.call(this, pF); return; }
    }
    // an indicator's zone (a filled box / band on the chart that isn't a candle): Each indicator's colour / glow / hide
    if (on && c && isPane(c)) { const z = zoneFor(this, w, h, x, y); if (z) {
      if (z.hide) return;
      // a shape / border of its own (rounded, pill, dashed, double, glow): drawn as a path with the real canvas calls
      const L = window.__bdCandleLooks;
      const tz = this.getTransform(), ZX = Math.min(x, x + w) * (tz.a || 1) + tz.e, ZY = Math.min(y, y + h) * (tz.d || 1) + tz.f, ZW = Math.abs(w * (tz.a || 1)), ZH = Math.abs(h * (tz.d || 1));
      if (L && L.zoneBox && zoneStyled(this) && ZH < c.height * 0.9 && shapeOK(this, ZX, ZY, ZW, ZH)) {
        const k = zoneKit(this), t = this.getTransform();
        if (L.zoneBox(this, k, x, y, w, h, z, { ...zoneSt(this), px: 1 / (t.a || 1) })) { noteShaped(this, Math.min(x, x + w) * (t.a || 1) + t.e, Math.min(y, y + h) * (t.d || 1) + t.f, Math.abs(w * (t.a || 1)), Math.abs(h * (t.d || 1))); return; } }
      drawZone(this, z, () => origFill.call(this, x, y, w, h), () => origStrokeRectRaw.call(this, x, y, w, h)); return; } }
    if (on && c && c.width > 20 && c.height > 20) {
      const s = this.getTransform().a || 1;
      // covers (nearly) the whole canvas => it's the pane background
      if (w * s >= c.width * 0.98 && h * s >= c.height * 0.98 && inChart(c)) {
        if (isAxis(c)) return this.clearRect(x, y, w, h);   // backing is drawn by CSS (frosted glass) behind the scale
        return this.clearRect(x, y, w, h);
      }
    }
    if (candles && c && (candles.glow > 0 || (candles.look !== "solid" && candles.look !== "shift") || candles.P || candles.F || candles.A || candles.closed) && isPane(c)) {
      const fs = this.fillStyle; // already remapped, normalised to "#rrggbb" for opaque colours
      // A fill in your candle colours is a candle at any size: on any timeframe, zoomed in or out, with the price scale
      // stretched so far that bodies run past the pane's edges. (The pane's background is handled above.)
      const t = fs === candles.upHex || fs === candles.downHex ? this.getTransform() : null, sx = t ? t.a || 1 : 1, sy = t ? t.d || 1 : 1;
      if (t) {
        const L = window.__bdCandleLooks, body = w * sx >= 3;
        const cd = candles, isUp = fs === cd.upHex, look0 = L ? cd.look : (cd.look === "neon" ? "neon" : "solid");
        if (cd.A && L && L.spot) L.spot.add(c, Math.min(x, x + w) * sx + t.e, Math.abs(w * sx), y * sy + t.f, (y + h) * sy + t.f, fs, isUp);   // only noted: drawn as before
        const split = !!(L && L.live && cd.closed);   // closed candles have a look of their own
        // TradingView draws a bordered candle as an outer rect then the body inside it, both in our colour: draw the
        // look once (on the outer rect) so outlines / glass don't double up.
        const P = L ? cd.P : null, F = L ? cd.F : null, tr = P ? tracker() : null;
        if (body && (look0 !== "solid" || P || F || split)) {
          const lb = lastBody.get(this), X = x * sx + t.e, Y = y * sy + t.f, W = w * sx, H = h * sy;
          // either order: body-then-border or border-then-body (within ~2 device px on every side)
          const inside = (a, o) => a.x >= o.x - 0.5 && a.y >= o.y - 0.5 && a.x + a.w <= o.x + o.w + 0.5 && a.y + a.h <= o.y + o.h + 0.5;
          const near = (a, o) => Math.abs(a.x - o.x) <= 2.5 && Math.abs(a.y - o.y) <= 2.5 && Math.abs(a.x + a.w - o.x - o.w) <= 2.5 && Math.abs(a.y + a.h - o.y - o.h) <= 2.5;
          const cur = { x: X, y: Y, w: W, h: H };
          if (lb && lb.col === fs && near(cur, lb) && (inside(cur, lb) || inside(lb, cur))) { lastBody.delete(this); if (split) L.live.touch(); return; }
          lastBody.set(this, { x: X, y: Y, w: W, h: H, col: fs });
        }
        const g = this;
        const part = (look) => {
          let col = fs;
          if (look === "prism") col = prismColour(isUp, (x * sx) / c.width);
          const meta = L && L.META[look], glow = Math.max(cd.glow, meta ? meta.minGlow : 0);
          // details in CSS px (see scaleOf in candlelooks.js: on a 1x screen this is 1 device px, as before)
          const sc = L && L.scaleOf ? L.scaleOf(c) : { r: 1, u: 1 }, bw = Math.abs(w * sx);
          if (L && body && h * sy >= 3) barW.set(c, bw);   // (a wick's glow follows its candle's body)
          lookK.g = g; lookK.px = sc.u / sx; lookK.yfrac = c.height ? (y * sy + t.f) / c.height : 0; lookK.xfrac = c.width ? (x * sx + t.e) / c.width : 0;
          { const a = (0 - t.f) / sy, b = (c.height - t.f) / sy; lookK.vy0 = Math.min(a, b); lookK.vy1 = Math.max(a, b); }   // the visible rows, in the body's units
          g.save();
          if (split) { g.setTransform(t); g.setLineDash([]); g.shadowBlur = 0; g.globalCompositeOperation = "source-over"; }   // drawn a moment later: in the state it was asked for
          if (glow > 0) { g.shadowColor = L ? L.tone(look, col, lookK) : col; const base = 4 + glow * 22, bc = (body && h * sy >= 3 ? bw : barW.get(c) || 0) / sc.r;
            g.shadowBlur = L && L.glowBlur ? L.glowBlur(base, sc.r, bc) : base; }
          if (L && body && h * sy >= 3) { if (tr) tr.note(c, true, w * sx); P || F ? L.candle(g, look, x, y, w, h, col, isUp, lookK, P, F) : L.draw(g, look, x, y, w, h, col, isUp, lookK); }
          else {
            // a wick (or a body too thin to style): your wick colour / width only when this chart's bodies are wide enough
            // to tell them apart (zoomed far out, thin bodies keep the candle colour)
            if (tr) tr.note(c, false, 0);
            const bw = tr ? tr.bw(c) : 0, ok = P && bw >= 3 && w * sx < 3;
            const wc = L ? (ok ? L.wickOf(look, col, isUp, lookK, P) : L.wick(look, col, lookK)) : col;
            let wx = x, ww = w; if (ok && P.wickW) { const nw = Math.min(P.wickW, Math.max(1, bw - 2)) / sx; wx = x + w / 2 - nw / 2; ww = nw; }
            origFillDesc.set.call(g, wc); origFill.call(g, wx, y, ww, h);
          }
          g.restore();
        };
        if (split) { const ga = g.globalAlpha; L.live.add(g, Math.min(x, x + w) * sx + t.e, Math.abs(w * sx), (isLive) => { const pa = g.globalAlpha; g.globalAlpha = ga; part(isLive ? look0 : cd.closed); g.globalAlpha = pa; }, fs, y * sy + t.f, (y + h) * sy + t.f); }
        else part(look0);
        return;
      }
    }
    return origFill.call(this, x, y, w, h);
  };

  // ---------- bracket pill box border ----------
  // TradingView outlines each pill with a 1px strokeRect right after the box fill. When bracket styling is on we
  // restyle that outline: bolder, a glow, or a custom / profit-loss colour — so the whole pill level stands out.
  const origStrokeRect = proto.strokeRect;
  { const oc = proto.clearRect; proto.clearRect = function (x, y, w, h) { const c = this.canvas; if (c && !c.isConnected) noteHiddenClear(this, x, y, w, h); return oc.call(this, x, y, w, h); }; }
  proto.strokeRect = function (x, y, w, h) {
    const c = this.canvas;
    if (on && c && shapedBox.has(this)) { const t = this.getTransform(); if (isShapedOutline(this, Math.min(x, x + w) * (t.a || 1) + t.e, Math.min(y, y + h) * (t.d || 1) + t.f, Math.abs(w * (t.a || 1)), Math.abs(h * (t.d || 1)))) return; }
    if (c && !c.isConnected) noteHiddenOther(this);
    if (on && fx.bracketOn && (fx.bracketBorderColor || fx.bracketBorderW > 0) && c && isPane(c)) {
      const pill = lastPill.get(this), t = this.getTransform(), sx = t.a || 1;
      const bx = x * sx + t.e, by = y * (t.d || 1) + t.f, bw = Math.abs(w * sx), bh = Math.abs(h * (t.d || 1));
      // this strokeRect is the pill's outline if it sits on the box we just recorded (same place, ~same size)
      const box = pill && pill.box;
      const isPillBorder = box && Math.abs(bx - box.x) <= 3 && Math.abs(by - box.y) <= 3 && Math.abs(bw - box.w) <= 4 && Math.abs(bh - box.h) <= 4;
      if (isPillBorder) {
        const cur = strokeDesc.get.call(this);
        const col = fx.bracketBorderColor || cur;
        const pS = cur, pLW = this.lineWidth;
        if (col !== cur) strokeDesc.set.call(this, col);
        if (fx.bracketBorderW > 0) this.lineWidth = Math.max(pLW, (fx.bracketBorderW + 1) / sx);
        origStrokeRect.call(this, x, y, w, h);
        if (col !== cur) strokeDesc.set.call(this, pS);
        this.lineWidth = pLW;
        return;
      }
    }
    // the border of one of your drawings (a rectangle): the same colour / glow / width as the rest of that drawing
    if (on && c && ((fx.drawOn && fx.indMode !== "own") || (fx.indCustom && Object.keys(fx.indCustom).length)) && isPane(c)) {
      const cur = strokeDesc.get.call(this), k = typeof cur === "string" ? rgbKey(cur) : null, L = window.__bdCandleLooks;
      if (k && L && L.indicator && ((fx.drawOn && fx.indMode !== "own") || (fx.indCustom && fx.indCustom[k.key])) && drawColHas(k.key)) {
        const r = L.indicator(this, cur, { mode: fx.drawOn && glowable(cur) ? fx.indMode : "own", color: fx.indColor, up: candles && candles.upHex, down: candles && candles.downHex, accent: fx.accent, custom: fx.indCustom, grad: fx.indGrad });
        if (r && r.hide) return;
        if (r) { const pS = cur, pB = this.shadowBlur, pC = this.shadowColor, pW = this.lineWidth, gl = r.glow !== undefined ? r.glow : fx.lineGlow;
          strokeDesc.set.call(this, r.s); if (gl > 0) { this.shadowColor = r.g; this.shadowBlur = 2 + gl * 16; } if (r.w) this.lineWidth = pW * (1 + r.w * 0.75);
          origStrokeRect.call(this, x, y, w, h); strokeDesc.set.call(this, pS); this.shadowBlur = pB; this.shadowColor = pC; this.lineWidth = pW; return; }
      }
    }
    return origStrokeRect.call(this, x, y, w, h);
  };

  // ---------- each chart in a layout matched to ITS OWN wallpaper ----------
  // content.js publishes, per chart (2, 3, 4...), where it is on screen and the colours measured from its own wallpaper
  // (data-ws-charts; chart 1 = your usual colours). While TradingView draws on a chart's canvas, the candle colours,
  // the wallpaper colours (indicators / zones) and the skin accent are that chart's. Nothing changes with one chart.
  let chartCols = null, chartOfC = new WeakMap();
  function readCharts() {
    let a = null; try { a = JSON.parse(htmlEl().getAttribute("data-ws-charts") || "null"); } catch {}
    const hex = (v) => (/^#[0-9a-f]{6}$/i.test(v || "") ? v.toLowerCase() : "");
    chartCols = Array.isArray(a) && a.length > 1 ? a.slice(0, 16).map((q, i) => (i && q && typeof q.fx === "string"
      // this chart styled on its own (Style each chart): its own candles + chart styling, parsed like the main ones
      ? { l: +q.l || 0, t: +q.t || 0, r: +q.r || 0, b: +q.b || 0, full: true, cand: parseCandles(q.cand || null), fx: parseFx(q.fx), colors: [] }
      : i && q && hex(q.up) && hex(q.down)
      ? { l: +q.l || 0, t: +q.t || 0, r: +q.r || 0, b: +q.b || 0, up: hex(q.up), down: hex(q.down), accent: hex(q.accent), text: hex(q.text), colors: Array.isArray(q.colors) ? q.colors.map(hex).filter(Boolean).slice(0, 5) : [] }
      : i ? null : { l: +(q && q.l) || 0, t: +(q && q.t) || 0, r: +(q && q.r) || 0, b: +(q && q.b) || 0, main: true })) : null;
    if (chartCols && !chartCols.some((q, i) => i && q)) chartCols = null;
    chartOfC = new WeakMap();
  }
  function chartFor(c) {
    if (!chartCols || !c || !c.isConnected) return null;
    let e = chartOfC.get(c); const now = performance.now();
    if (!e || now - e.t > 1500) {
      const r = c.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2; let i = -1;
      chartCols.forEach((q, k) => { if (q && x >= q.l && x <= q.r && y >= q.t && y <= q.b) i = k; });
      e = { t: now, i }; chartOfC.set(c, e);
    }
    const q = e.i > 0 ? chartCols[e.i] : null; if (!q || q.main) return null;
    if (q.full) { if (q.cand && !q.cand.cache) q.cand.cache = new Map(); return q; }
    if (!candles) return null;
    if (!q.cand || q.base !== candles) { q.base = candles; q.cand = { ...candles, up: hexToRgb(q.up), down: hexToRgb(q.down), upHex: q.up, downHex: q.down, cache: new Map() }; }
    return q;
  }
  const withChart = (fn) => function (...a) {
    const q = chartCols ? chartFor(this.canvas) : null;
    if (!q) return fn.apply(this, a);
    const L = window.__bdCandleLooks;
    if (q.full) {                                          // a fully styled chart: swap the whole style while it draws
      const pc = candles, pf = fx; candles = q.cand; fx = q.fx; if (L && L.setWallColors) L.setWallColors(fx.wallColors, fx.bg);
      try { return fn.apply(this, a); } finally { candles = pc; fx = pf; if (L && L.setWallColors) L.setWallColors(fx.wallColors, fx.bg); }
    }
    const pc = candles, pa = fx.accent, pt = fx.txtColor;
    candles = q.cand; if (q.accent) fx.accent = q.accent; if (q.text && fx.txtMode === "custom") fx.txtColor = q.text; if (L && L.setWallColors && q.colors.length >= 2) L.setWallColors(q.colors);
    try { return fn.apply(this, a); }
    finally { candles = pc; fx.accent = pa; fx.txtColor = pt; if (L && L.setWallColors && q.colors.length >= 2) L.setWallColors(fx.wallColors, fx.bg); }
  };
  for (const name of ["fillRect", "strokeRect", "fill", "stroke", "fillText", "strokeText"]) if (typeof proto[name] === "function") proto[name] = withChart(proto[name]);
  for (const prop of ["fillStyle", "strokeStyle"]) {
    const d = Object.getOwnPropertyDescriptor(proto, prop);
    if (d && d.set) Object.defineProperty(proto, prop, { configurable: true, enumerable: d.enumerable, get: d.get, set: withChart(d.set) });
  }
  readCharts();
  new MutationObserver(() => { readCharts(); try { forceRepaint(true); } catch {} }).observe(document.documentElement || document, { attributes: true, attributeFilter: ["data-ws-charts"] });
})();

// ---------- Tradovate: its charts are drawn with WebGL, into one canvas the size of the window ----------
// Each chart's dark background is a scissored clear in opaque black (its own colour). With Priism on, that one clear is
// made see-through (same clear, alpha 0), so the wallpaper Priism places behind each chart shows; candles, grid and
// prices are drawn by Tradovate on top as always. Nothing else in its drawing is touched. The cleared boxes are also
// where its charts are: published on <html data-bd-tdv-panes> (CSS px) so content.js can put a wallpaper under each.
(function tradovateGl() {
  if (window.__bdTdvGl || !/(^|\.)tradovate\.com$/.test(location.hostname) || window !== window.top) return;
  window.__bdTdvGl = true;
  const H = document.documentElement;
  let on = false;
  const readOn = () => { const c = H.classList; on = c.contains("bd-on") && c.contains("bd-tdv") && !c.contains("bd-over-mode") && !c.contains("bd-focus"); };
  new MutationObserver(readOn).observe(H, { attributes: true, attributeFilter: ["class"] }); readOn();
  const seen = new Map();          // "x,y,w,h" (GL px) -> last time a chart background was cleared there
  let pubT = 0, lastPub = "", glCanvas = null;
  function publish() {
    pubT = 0;
    const now = performance.now(), cv = glCanvas; if (!cv || !cv.isConnected) return;
    const boxes = [...seen].filter(([, t]) => now - t < 1500).map(([k]) => k.split(",").map(Number));
    for (const [k, t] of seen) if (now - t >= 1500) seen.delete(k);
    // the charts themselves: the outermost boxes (a chart's own panes and price scale sit inside its box)
    const outer = boxes.filter((b) => !boxes.some((o) => o !== b && o[0] <= b[0] && o[1] <= b[1] && o[0] + o[2] >= b[0] + b[2] && o[1] + o[3] >= b[1] + b[3] && (o[2] > b[2] || o[3] > b[3])));
    const r = cv.getBoundingClientRect(), kx = cv.width / Math.max(1, r.width), ky = cv.height / Math.max(1, r.height);
    const css = outer.map(([x, y, w, h]) => [r.left + x / kx, r.top + (cv.height - y - h) / ky, w / kx, h / ky].map((v) => Math.round(v * 10) / 10))
      .filter(([, , w, h]) => w >= 120 && h >= 80).sort((a, b) => (Math.abs(a[1] - b[1]) > 20 ? a[1] - b[1] : a[0] - b[0])).slice(0, 12);
    const s = JSON.stringify(css);
    if (s !== lastPub) { lastPub = s; H.setAttribute("data-bd-tdv-panes", s); }
  }
  for (const K of [window.WebGL2RenderingContext, window.WebGLRenderingContext]) {
    if (!K) continue;
    const P = K.prototype, oCC = P.clearColor, oClear = P.clear, cc = new WeakMap();
    P.clearColor = function (r, g, b, a) { cc.set(this, [r, g, b, a]); return oCC.call(this, r, g, b, a); };
    P.clear = function (mask) {
      const c = cc.get(this), cv = this.canvas;
      // an opaque dark clear inside a scissor box, on the page's big canvas = one chart's background
      if (c && c[3] >= 0.99 && (mask & 0x4000) && 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2] < 0.3 && cv && cv.width >= 400 && this.isEnabled(this.SCISSOR_TEST)) {
        const b = this.getParameter(this.SCISSOR_BOX);
        if (b && b[2] < cv.width * 0.98 && b[2] >= 60 && b[3] >= 40) {
          glCanvas = cv; seen.set(b[0] + "," + b[1] + "," + b[2] + "," + b[3], performance.now());
          if (!pubT) pubT = setTimeout(publish, 400);
          if (on) { oCC.call(this, 0, 0, 0, 0); const res = oClear.call(this, mask); oCC.call(this, c[0], c[1], c[2], c[3]); return res; }
        }
      }
      return oClear.call(this, mask);
    };
  }
  addEventListener("resize", () => { seen.clear(); lastPub = ""; }, { passive: true });
})();
