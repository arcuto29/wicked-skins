/**
 * "Not protected" notice (ISOLATED world, trading platforms).
 * When the Sentinel desktop app isn't running, Sentinel enforces nothing (unless a lock is being kept from memory,
 * which has its own banner). Without a word on screen a trader can believe their limits are on. This shows one small
 * strip at the top of the page while that's the case and removes it the moment the app connects. It never covers the
 * order buttons (top centre, narrow) and can be hidden for this tab; it reappears after a reload while still off.
 */
(function () {
  'use strict';
  if (window.top !== window || window.__sentinelProtectionStatus) return;
  window.__sentinelProtectionStatus = true;
  let host = null, hidden = false, offSince = null, checkT = 0;
  const GRACE_MS = 8000;   // the app connects within a few seconds of the page opening: don't flash the notice meanwhile

  function show() {
    if (host || hidden || !document.documentElement) return;
    host = document.createElement('div');
    host.setAttribute('data-sentinel-notice', '');
    host.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483646;pointer-events:none';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>
      .n{pointer-events:auto;display:flex;align-items:center;gap:10px;padding:7px 8px 7px 12px;border-radius:10px;background:rgba(17,18,24,.94);
        border:1px solid #f59e0b;color:#f3f4f6;font:600 12.5px/1.3 system-ui,-apple-system,"Segoe UI",sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.7)}
      .d{width:8px;height:8px;border-radius:50%;background:#f59e0b;flex:none}
      small{display:block;font-weight:500;color:#9ca3af}
      button{border:0;border-radius:7px;padding:5px 9px;background:rgba(255,255,255,.08);color:#e5e7eb;font:600 11.5px system-ui,sans-serif;cursor:pointer}
      button:hover{background:rgba(255,255,255,.14)}
    </style><div class="n" role="status"><span class="d"></span><span>Sentinel isn't protecting you<small>The Sentinel app isn't running, so your limits are off. Open it to turn them back on.</small></span><button type="button">Hide</button></div>`;
    root.querySelector('button').onclick = () => { hidden = true; hide(); };
    document.documentElement.appendChild(host);
  }
  function hide() { if (host) { host.remove(); host = null; } }

  function update(connected, locked) {
    clearTimeout(checkT);
    if (connected || locked) { offSince = null; hide(); return; }      // protected (or a lock is enforced from memory: its own banner)
    if (offSince === null) offSince = Date.now();
    const left = GRACE_MS - (Date.now() - offSince);
    if (left > 0) { checkT = setTimeout(ask, left + 50); return; }       // look again once the grace period is over
    show();
  }
  function ask() {
    try { chrome.runtime.sendMessage({ type: 'GET_CONNECTION_STATUS' }, (r) => { void chrome.runtime.lastError; if (r) update(!!r.connected, !!r.locked); }); } catch {}
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'PROTECTION_STATUS') update(!!msg.connected, false);
    if (msg && msg.type === 'EMERGENCY_FALLBACK') update(false, true);
  });
  ask();
  setInterval(ask, 20000);   // the background can sleep and miss telling us: check now and then (cheap)
})();
