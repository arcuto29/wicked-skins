/**
 * SENTINEL VOICE COACH — MAIN WORLD (DEPRECATED)
 * 
 * TTS has been moved to the Electron desktop renderer.
 * This file only tracks behavioral state for the __sentinelBehavioralState global.
 * Speech synthesis no longer executes in the browser.
 */
(function() {
  'use strict';

  // Track behavioral state (used by other scripts that read window.__sentinelBehavioralState)
  window.addEventListener('message', function(event) {
    if (event.source !== window || !event.data) return;
    if (event.data.type === 'TRL_STATE_TRANSITION') {
      window.__sentinelBehavioralState = event.data.to || 'NORMAL';
    }
  });

  console.log('[Sentinel] Voice Coach: TTS runs on desktop. Browser-side state tracking only.');
})();
