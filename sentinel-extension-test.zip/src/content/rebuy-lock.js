/**
 * Sentinel Rebuy Lock
 * Blocks impulsive evaluation purchases / account resets while the persisted
 * cooldown is active. Runs only on explicitly supported prop-firm websites.
 *
 * This is intentionally separate from live-order interception:
 * - trading exits are unaffected
 * - normal prop-firm dashboard/support access remains available
 * - only purchase/reset flows are blocked
 */
(function () {
  'use strict';

  var state = { isActive: false, expiresAt: null, strikeCount: 0, reason: null };
  var lastUrl = location.href;
  var overlayId = 'sentinel-rebuy-lock-overlay';

  var blockedPathTokens = [
    '/checkout', '/cart', '/payment', '/payments', '/purchase', '/billing',
    '/pricing', '/plans', '/subscribe', '/subscription', '/order', '/shop',
    '/new-account', '/add-account', '/new-evaluation', '/start-evaluation',
    '/start-combine', '/buy-evaluation', '/account-reset', '/reset-account'
  ];

  var blockedTextPhrases = [
    'buy evaluation', 'buy an evaluation', 'purchase evaluation',
    'start evaluation', 'start an evaluation', 'new evaluation',
    'add evaluation', 'get evaluation', 'buy account', 'purchase account',
    'new account', 'add account', 'start combine', 'new combine',
    'buy combine', 'purchase combine', 'reset account', 'reset evaluation',
    'reset combine', 'purchase reset', 'buy reset', 'choose plan',
    'select plan', 'get funded', 'checkout', 'complete purchase'
  ];

  function activeNow() {
    if (!state || state.isActive !== true) return false;
    if (!state.expiresAt) return true; // fail-safe: active state without expiry stays blocked
    var expiry = Date.parse(state.expiresAt);
    return !Number.isFinite(expiry) || expiry > Date.now();
  }

  function normalizedUrl(url) {
    try {
      var u = new URL(url, location.href);
      return (u.pathname + ' ' + u.search + ' ' + u.hash).toLowerCase();
    } catch (_) {
      return String(url || '').toLowerCase();
    }
  }

  function looksLikePurchaseUrl(url) {
    var value = normalizedUrl(url);
    // Password/account-recovery pages must never be mistaken for an eval reset.
    if (value.includes('password') || value.includes('forgot')) return false;

    if (blockedPathTokens.some(function (token) { return value.includes(token); })) return true;

    // Query-string purchase/reset signals.
    return /(?:[?&#]|\b)(?:checkout|purchase|plan|pricing|reset|subscribe|cart)=/i.test(value);
  }

  function cleanText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function elementLooksLikePurchase(el) {
    if (!el) return false;
    var target = el.closest ? el.closest('a,button,[role="button"],input[type="submit"],input[type="button"]') : null;
    if (!target) return false;

    var text = cleanText(target.innerText || target.textContent || target.value || target.getAttribute('aria-label') || '');
    var href = target.href || target.getAttribute('href') || '';

    if (looksLikePurchaseUrl(href)) return true;
    if (text.includes('reset password') || text.includes('forgot password')) return false;

    return blockedTextPhrases.some(function (phrase) { return text.includes(phrase); });
  }

  function formatExpiry() {
    if (!state || !state.expiresAt) return 'the cooldown expires';
    var d = new Date(state.expiresAt);
    if (Number.isNaN(d.getTime())) return 'the cooldown expires';
    return d.toLocaleString();
  }

  function reportBlock(reason) {
    try {
      chrome.runtime.sendMessage({
        type: 'REPORT_BYPASS_ATTEMPT',
        details: 'REBUY LOCK: ' + reason + ' on ' + location.hostname
      });
    } catch (_) {}
  }

  function showOverlay(reason) {
    if (!activeNow()) return;
    if (document.getElementById(overlayId)) return;

    function mount() {
      if (!activeNow() || document.getElementById(overlayId)) return;
      var host = document.body || document.documentElement;
      if (!host) return;

      var overlay = document.createElement('div');
      overlay.id = overlayId;
      overlay.style.cssText = [
        'position:fixed','inset:0','z-index:2147483647','display:flex',
        'align-items:center','justify-content:center','background:#080a0f',
        'font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif',
        'padding:24px','box-sizing:border-box'
      ].join(';');

      var card = document.createElement('div');
      card.style.cssText = [
        'width:min(520px,100%)','border:1px solid rgba(255,255,255,.12)',
        'border-radius:18px','background:#10141c','padding:28px',
        'box-shadow:0 24px 80px rgba(0,0,0,.55)','text-align:center',
        'color:#f8fafc'
      ].join(';');

      var badge = document.createElement('div');
      badge.textContent = 'SENTINEL';
      badge.style.cssText = 'font-size:11px;font-weight:800;letter-spacing:2.5px;color:#ef4444;margin-bottom:14px;';

      var title = document.createElement('div');
      title.textContent = 'REBUY LOCK ACTIVE';
      title.style.cssText = 'font-size:24px;font-weight:900;letter-spacing:.5px;margin-bottom:12px;';

      var copy = document.createElement('div');
      copy.textContent = 'Buying another evaluation or resetting an account is blocked until ' + formatExpiry() + '.';
      copy.style.cssText = 'font-size:14px;line-height:1.6;color:rgba(255,255,255,.62);margin-bottom:10px;';

      var why = document.createElement('div');
      why.textContent = state.reason || reason || 'Cooldown active after an account failure.';
      why.style.cssText = 'font-size:12px;line-height:1.5;color:rgba(255,255,255,.32);margin-bottom:22px;';

      var back = document.createElement('button');
      back.textContent = 'BACK TO SITE';
      back.style.cssText = [
        'border:1px solid rgba(255,255,255,.12)','background:rgba(255,255,255,.05)',
        'color:#fff','border-radius:10px','padding:11px 18px','font-size:11px',
        'font-weight:800','letter-spacing:1.4px','cursor:pointer'
      ].join(';');
      back.addEventListener('click', function () {
        location.href = location.origin + '/';
      });

      card.appendChild(badge);
      card.appendChild(title);
      card.appendChild(copy);
      card.appendChild(why);
      card.appendChild(back);
      overlay.appendChild(card);
      host.appendChild(overlay);
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', mount, { once: true });
      setTimeout(mount, 250);
    } else {
      mount();
    }
  }

  function enforceCurrentUrl() {
    if (!activeNow()) {
      var old = document.getElementById(overlayId);
      if (old) old.remove();
      return;
    }
    if (looksLikePurchaseUrl(location.href)) {
      showOverlay('Purchase/reset page blocked');
    }
  }

  // Block same-page buttons/links before the site can start checkout.
  document.addEventListener('click', function (event) {
    if (!activeNow()) return;
    if (!elementLooksLikePurchase(event.target)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    reportBlock('Purchase/reset action blocked');
    showOverlay('Purchase/reset action blocked');
  }, true);

  // Also stop purchase/reset form submissions that do not navigate through a link.
  document.addEventListener('submit', function (event) {
    if (!activeNow()) return;
    var form = event.target;
    var action = form && form.action ? form.action : location.href;
    var text = cleanText(form && form.innerText);
    var purchaseText = blockedTextPhrases.some(function (phrase) { return text.includes(phrase); });
    if (!looksLikePurchaseUrl(action) && !purchaseText) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    reportBlock('Purchase/reset form blocked');
    showOverlay('Purchase/reset form blocked');
  }, true);

  chrome.runtime.sendMessage({ type: 'GET_REBUY_LOCK_STATE' }, function (response) {
    if (response) state = response;
    enforceCurrentUrl();
  });

  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === 'REBUY_LOCK_UPDATE') {
      state = msg.state || { isActive: false };
      enforceCurrentUrl();
    }
  });

  // SPA routes can change without a page reload. Poll only the URL, not the DOM.
  setInterval(function () {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      enforceCurrentUrl();
    } else if (activeNow() && looksLikePurchaseUrl(location.href)) {
      enforceCurrentUrl();
    } else if (!activeNow()) {
      var old = document.getElementById(overlayId);
      if (old) old.remove();
    }
  }, 500);

  enforceCurrentUrl();
})();
